-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2025 at 05:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digidaw`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `log_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `target_id` int(11) DEFAULT NULL,
  `target_type` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `email`, `password_hash`, `created_at`, `updated_at`) VALUES
(1, 'eroladmin', 'admin@gmail.com', '$2y$10$dOA4VdF.IWKU4cB2k3Oz4.pbA96lHiNxWtWkaY8EsQ9oz6KxEXfJa', '2025-06-29 17:36:58', '2025-06-29 17:36:58');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL CHECK (`quantity` >= 1),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `description`, `created_at`) VALUES
(4, 'Gift Card', 'Kartu hadiah untuk berbagai platform', '2025-04-13 09:59:06'),
(5, 'Voucher Game', 'Voucher untuk top-up game online', '2025-04-13 13:14:29'),
(7, 'Top-Up Saldo', 'Top-up saldo untuk berbagai platform', '2025-04-13 13:14:29'),
(8, 'Paket Data', 'Paket data internet untuk berbagai operator', '2025-04-13 13:14:29'),
(9, 'Pulsa', 'Pulsa untuk berbagai operator', '2025-04-13 13:14:29'),
(15, 'Skin', NULL, '2025-07-16 10:40:06'),
(16, 'In-Game Currency', NULL, '2025-07-16 10:40:06'),
(17, 'Account', NULL, '2025-07-16 10:40:06'),
(18, 'Boosting Services', NULL, '2025-07-16 10:40:06'),
(19, 'Vouchers', NULL, '2025-07-16 10:40:06');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `complaint_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `status` enum('open','in_progress','resolved','closed') DEFAULT 'open',
  `resolved_by` int(11) DEFAULT NULL,
  `resolution_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_message_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `type` enum('order','verification','complaint','promo','other') NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `admin_id`, `type`, `message`, `is_read`, `created_at`, `updated_at`) VALUES
(12, 1, 1, '', 'Produk \"Voucher Mobile Legends 100 Diamonds\" telah dihapus oleh admin.', 1, '2025-06-30 17:44:26', '2025-07-01 00:44:44'),
(16, 1, NULL, 'order', 'Pesanan #14 telah dibayar oleh pembeli.', 0, '2025-07-16 06:25:28', '2025-07-16 13:25:28'),
(18, 1, NULL, 'order', 'Pesanan #11 telah dibatalkan oleh pembeli.', 0, '2025-07-16 06:25:33', '2025-07-16 13:25:33'),
(21, 1, NULL, 'order', 'Pesanan #16 telah dibayar oleh pembeli.', 0, '2025-07-16 07:27:23', '2025-07-16 14:27:23'),
(24, 1, NULL, 'order', 'Pesanan #17 telah dibayar oleh pembeli.', 0, '2025-07-16 09:45:52', '2025-07-16 16:45:52'),
(27, 1, 1, '', 'Produk \"Gift Card iTunes 100K\" telah dihapus oleh admin.', 1, '2025-07-16 16:33:01', '2025-07-16 23:33:49'),
(35, 27, NULL, 'verification', 'Pengguna akuaku telah mengunggah verifikasi penjual.', 0, '2025-07-16 17:09:59', '2025-07-17 00:09:59'),
(36, 27, 1, 'verification', 'Selamat! Akun penjual Anda telah disetujui dan diaktifkan.', 1, '2025-07-16 17:20:16', '2025-07-17 00:46:46'),
(42, 28, NULL, '', 'Permintaan deposit sebesar Rp500.000 telah diajukan. Menunggu persetujuan admin.', 1, '2025-07-17 03:48:23', '2025-07-17 10:53:48'),
(43, 28, 1, '', 'Transaksi dompet Anda (ID #13) telah disetujui. Saldo sebesar Rp 500.000 telah ditambahkan.', 1, '2025-07-17 03:48:45', '2025-07-17 10:53:48'),
(44, 28, NULL, '', 'Permintaan deposit sebesar Rp100.000 telah diajukan. Menunggu persetujuan admin.', 1, '2025-07-17 03:53:42', '2025-07-17 10:53:48');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `promo_id` int(11) DEFAULT NULL,
  `total_price` decimal(15,2) NOT NULL CHECK (`total_price` >= 0),
  `status` enum('pending','paid','delivered','completed','cancelled') DEFAULT 'pending',
  `payment_method` enum('bank_transfer','ewallet','credit_card') DEFAULT NULL,
  `payment_status` enum('pending','confirmed','failed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `seller_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_detail_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL CHECK (`quantity` > 0),
  `price` decimal(15,2) NOT NULL CHECK (`price` >= 0),
  `delivery_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `phone_number` varchar(20) DEFAULT NULL,
  `game_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_proofs`
--

CREATE TABLE `payment_proofs` (
  `payment_proof_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `proof_url` varchar(255) NOT NULL,
  `status` enum('pending','verified','rejected') DEFAULT 'pending',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified_by` int(11) DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_proofs`
--

INSERT INTO `payment_proofs` (`payment_proof_id`, `order_id`, `proof_url`, `status`, `submitted_at`, `verified_by`, `verified_at`, `notes`, `updated_at`) VALUES
(5, NULL, '', 'pending', '2025-06-23 15:18:27', NULL, NULL, '{\"user_id\":\"23\",\"amount\":\"111111\"}', '2025-06-23 15:18:27'),
(6, NULL, '', 'pending', '2025-07-16 16:31:30', NULL, NULL, '{\"user_id\":\"23\",\"amount\":\"900000\"}', '2025-07-16 16:31:30'),
(7, NULL, '', 'pending', '2025-07-17 03:48:23', NULL, NULL, '{\"user_id\":\"28\",\"amount\":\"500000\"}', '2025-07-17 03:48:23'),
(8, NULL, '', 'pending', '2025-07-17 03:53:42', NULL, NULL, '{\"user_id\":\"28\",\"amount\":\"100000\"}', '2025-07-17 03:53:42');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` decimal(15,2) NOT NULL CHECK (`price` >= 0),
  `stock` int(11) NOT NULL CHECK (`stock` >= 0),
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','out_of_stock') DEFAULT 'active',
  `view_count` int(11) DEFAULT 0 CHECK (`view_count` >= 0),
  `sold_count` int(11) DEFAULT 0 CHECK (`sold_count` >= 0),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `seller_id`, `category_id`, `name`, `price`, `stock`, `description`, `image_url`, `status`, `view_count`, `sold_count`, `created_at`, `updated_at`) VALUES
(60, 1, 4, 'Voucher Valorant 500 Points', 80000.00, 49, 'Voucher untuk top-up 500 Points di Valorant.', '/uploads/products/1752661818_b0cf827e4533e0bd770f.jpg', 'active', 120, 41, '2025-04-13 06:14:29', '2025-07-16 15:11:05'),
(61, 1, 5, 'Voucher Genshin Impact 300 Crystals', 60000.00, 60, 'Voucher untuk top-up 300 Crystals di Genshin Impact.', 'https://example.com/images/genshin-300-crystals.jpg', 'active', 140, 45, '2025-04-13 06:14:29', NULL),
(66, 3, 8, 'Paket Data Telkomsel 5GB', 50000.00, 50, 'Paket data Telkomsel 5GB untuk 30 hari.', 'https://example.com/images/telkomsel-5gb.jpg', 'active', 60, 15, '2025-04-13 06:14:29', NULL),
(67, 3, 8, 'Paket Data Indosat 10GB', 75000.00, 30, 'Paket data Indosat 10GB untuk 30 hari.', 'https://example.com/images/indosat-10gb.jpg', 'active', 50, 10, '2025-04-13 06:14:29', NULL),
(68, 3, 8, 'Paket Data XL 15GB', 90000.00, 20, 'Paket data XL 15GB untuk 30 hari.', 'https://example.com/images/xl-15gb.jpg', 'active', 41, 8, '2025-04-13 06:14:29', '2025-06-01 08:13:50'),
(70, 3, 9, 'Pulsa Telkomsel 50K', 52000.00, 100, 'Pulsa Telkomsel senilai Rp50.000.', 'https://example.com/images/telkomsel-50k.jpg', 'active', 100, 40, '2025-04-13 06:14:29', NULL),
(71, 3, 9, 'Pulsa Indosat 100K', 102000.00, 80, 'Pulsa Indosat senilai Rp100.000.', 'https://example.com/images/indosat-100k.jpg', 'active', 90, 35, '2025-04-13 06:14:29', NULL),
(72, 3, 9, 'Pulsa XL 25K', 26000.00, 120, 'Pulsa XL senilai Rp25.000.', 'https://example.com/images/xl-25k.jpg', 'active', 110, 50, '2025-04-13 06:14:29', NULL),
(73, 1, 4, 'Gift Card Google Play 50K', 55000.00, 33, 'Gift Card Google Play senilai Rp50.000.', 'https://example.com/images/googleplay-50k.jpg', 'active', 148, 63, '2025-04-13 06:14:29', '2025-07-16 09:45:45'),
(79, 1, 5, 'Mobile Legends 1', 1111111.00, 1111, 'afafawfwafaaf', '/uploads/products/1752663645_fd868cd2af206ef5ef3c.jpeg', 'out_of_stock', 0, 0, '2025-07-16 11:00:45', '2025-07-16 16:24:50');

--
-- Triggers `products`
--
DELIMITER $$
CREATE TRIGGER `update_product_status_after_stock_change` AFTER UPDATE ON `products` FOR EACH ROW BEGIN
    IF NEW.stock = 0 AND OLD.stock > 0 THEN
        UPDATE products SET status = 'out_of_stock' WHERE product_id = NEW.product_id;
    ELSEIF NEW.stock > 0 AND OLD.status = 'out_of_stock' THEN
        UPDATE products SET status = 'active' WHERE product_id = NEW.product_id;
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `product_tags`
--

CREATE TABLE `product_tags` (
  `product_tag_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `promos`
--

CREATE TABLE `promos` (
  `promo_id` int(11) NOT NULL,
  `code` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `discount_type` enum('percentage','fixed') NOT NULL,
  `discount_value` decimal(15,2) NOT NULL CHECK (`discount_value` >= 0),
  `min_purchase` decimal(15,2) DEFAULT NULL CHECK (`min_purchase` >= 0 or `min_purchase` is null),
  `max_discount` decimal(15,2) DEFAULT NULL CHECK (`max_discount` >= 0 or `max_discount` is null),
  `category_id` int(11) DEFAULT NULL,
  `valid_from` timestamp NOT NULL DEFAULT current_timestamp(),
  `valid_until` timestamp NULL DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `usage_limit_per_user` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `promos`
--

INSERT INTO `promos` (`promo_id`, `code`, `description`, `discount_type`, `discount_value`, `min_purchase`, `max_discount`, `category_id`, `valid_from`, `valid_until`, `status`, `created_at`, `usage_limit_per_user`) VALUES
(1, 'DIGIDAW20', NULL, 'percentage', 20.00, NULL, NULL, NULL, '2025-03-31 17:00:00', '2025-12-31 16:59:59', 'active', '2025-04-13 09:59:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `promo_usages`
--

CREATE TABLE `promo_usages` (
  `promo_usage_id` int(11) NOT NULL,
  `promo_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `discount_applied` decimal(15,2) NOT NULL CHECK (`discount_applied` >= 0),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `promo_usages`
--
DELIMITER $$
CREATE TRIGGER `restrict_promo_usage` BEFORE INSERT ON `promo_usages` FOR EACH ROW BEGIN
    DECLARE usage_count INT;
    DECLARE limit_per_user INT;
    SELECT usage_limit_per_user INTO limit_per_user FROM promos WHERE promo_id = NEW.promo_id;
    SELECT COUNT(*) INTO usage_count FROM promo_usages WHERE promo_id = NEW.promo_id AND user_id = NEW.user_id;
    IF usage_count >= limit_per_user THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Promo usage limit exceeded for this user';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `report_id` int(11) NOT NULL,
  `report_type` enum('sales','transactions','products','users','complaints') NOT NULL,
  `generated_by` int(11) DEFAULT NULL,
  `start_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `end_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `data` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `review_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` between 1 and 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `tag_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL CHECK (`amount` >= 0),
  `status` enum('pending','held','released','refunded') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('pembeli','penjual') NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `verification_status` enum('non_verified','pending','verified','rejected') DEFAULT NULL,
  `balance` decimal(15,2) DEFAULT 0.00 CHECK (`balance` >= 0),
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `referral_code` varchar(10) DEFAULT NULL,
  `referred_by` int(11) DEFAULT NULL,
  `seller_rating` decimal(3,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `remember_token_expiry` datetime DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT 0,
  `verification_photo` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `role`, `status`, `verification_status`, `balance`, `phone`, `address`, `referral_code`, `referred_by`, `seller_rating`, `created_at`, `updated_at`, `remember_token`, `remember_token_expiry`, `is_enabled`, `verification_photo`) VALUES
(1, 'seller1', 'seller1@example.com', '$2y$10$9osRNskE1L1zOuGhqJMES.LpBrjLVbAzKnej7JNtpH7bHCUj6.J3a', 'penjual', 'active', 'verified', 0.00, NULL, NULL, NULL, NULL, 4.50, '2025-04-13 02:59:06', '2025-06-29 18:47:36', NULL, NULL, 1, 'uploads/seller_photos/seller_1_1750696063.jpg'),
(3, 'seller3', 'seller3@example.com', '$2y$10$6Ta5ybu7Tl7lq2wehdEsrO4iAJU8tR5Z2GhXyTwuZJCcb7/y8R7Pq', 'penjual', 'active', 'verified', 0.00, NULL, NULL, NULL, NULL, 4.00, '2025-04-13 02:59:06', '2025-06-29 18:47:40', NULL, NULL, 1, NULL),
(22, 'erol', 'erol.gavrila@gmail.com', '$2y$10$YCde1hYxJ7zZrVuMxDeToupC5/3MrOK63lphzWokN8dLosIToeYYm', 'penjual', 'active', 'verified', 0.00, NULL, NULL, NULL, NULL, 0.00, '2025-06-16 15:44:14', '2025-06-29 18:47:41', NULL, NULL, 1, NULL),
(24, 'seller4', 'seller4@gmail.com', '$2y$10$gl2eNJPpYALOfa.aybjiqOPWe769.93DnBQJeka9YmRBAUe2TtP8e', 'penjual', 'active', 'verified', 0.00, NULL, NULL, NULL, NULL, 0.00, '2025-06-17 06:39:22', '2025-06-29 18:47:41', NULL, NULL, 1, 'uploads/seller_photos/seller_24_1750142376.png'),
(27, 'akuaku', 'akuaku@gmail.com', '$2y$10$OiiP9ToAvK0tosYyR4s2Y.HdbluOlArx3wwroNEZmnm7j2zqkTkCS', 'penjual', 'active', 'verified', 0.00, NULL, NULL, NULL, NULL, 0.00, '2025-07-16 16:52:51', '2025-07-16 17:20:16', NULL, NULL, 1, 'seller_photos/seller_27_1752685799_document.png'),
(28, 'erol1', 'erol@gmail.com', '$2y$10$NHl9nb0nyPpPLRFYCUM0rOEj.0EN8I013yCobMgtQ/vxwozfhwZdK', 'pembeli', 'active', NULL, 500000.00, NULL, NULL, NULL, NULL, 0.00, '2025-07-17 03:47:48', '2025-07-17 03:48:45', NULL, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_bans`
--

CREATE TABLE `user_bans` (
  `ban_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `reason` text NOT NULL,
  `banned_by` int(11) NOT NULL,
  `start_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `end_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_logs`
--

CREATE TABLE `user_logs` (
  `user_log_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `verification_documents`
--

CREATE TABLE `verification_documents` (
  `verification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_type` enum('ktp','bank_account','other') NOT NULL,
  `document_url` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `wallet_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `type` enum('deposit','withdrawal','payment','refund','referral') NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` enum('pending','verified','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`wallet_id`, `user_id`, `amount`, `type`, `description`, `status`, `created_at`) VALUES
(13, 28, 500000.00, 'deposit', 'Deposit via ewallet (Akun: 2)', '', '2025-07-17 03:48:23'),
(14, 28, 100000.00, 'deposit', 'Deposit via ewallet (Akun: 3)', 'pending', '2025-07-17 03:53:42');

--
-- Triggers `wallets`
--
DELIMITER $$
CREATE TRIGGER `update_user_balance` AFTER INSERT ON `wallets` FOR EACH ROW BEGIN
    IF NEW.status = 'verified' THEN
        UPDATE users
        SET balance = balance + NEW.amount
        WHERE user_id = NEW.user_id;
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_user_balance_after_delete` AFTER DELETE ON `wallets` FOR EACH ROW BEGIN
    UPDATE users
    SET balance = balance - OLD.amount
    WHERE user_id = OLD.user_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_user_balance_after_update` AFTER UPDATE ON `wallets` FOR EACH ROW BEGIN
    UPDATE users
    SET balance = balance - OLD.amount + NEW.amount
    WHERE user_id = NEW.user_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `wishlist_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_activity_logs_admin` (`admin_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`cart_id`),
  ADD UNIQUE KEY `unique_cart` (`user_id`,`product_id`),
  ADD KEY `idx_carts_user` (`user_id`),
  ADD KEY `idx_carts_product` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`complaint_id`),
  ADD KEY `resolved_by` (`resolved_by`),
  ADD KEY `idx_complaints_order` (`order_id`),
  ADD KEY `idx_complaints_user` (`user_id`),
  ADD KEY `idx_complaints_status` (`status`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `idx_messages_sender` (`sender_id`),
  ADD KEY `idx_messages_receiver` (`receiver_id`),
  ADD KEY `idx_messages_order` (`order_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_notifications_user` (`user_id`),
  ADD KEY `idx_notifications_admin` (`admin_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `idx_orders_buyer` (`buyer_id`),
  ADD KEY `idx_orders_status` (`status`),
  ADD KEY `idx_orders_promo` (`promo_id`),
  ADD KEY `idx_orders_seller` (`seller_id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`order_detail_id`),
  ADD KEY `idx_order_details_order` (`order_id`),
  ADD KEY `idx_order_details_product` (`product_id`);

--
-- Indexes for table `payment_proofs`
--
ALTER TABLE `payment_proofs`
  ADD PRIMARY KEY (`payment_proof_id`),
  ADD KEY `verified_by` (`verified_by`),
  ADD KEY `idx_payment_proofs_order` (`order_id`),
  ADD KEY `idx_payment_proofs_status` (`status`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `idx_products_seller` (`seller_id`),
  ADD KEY `idx_products_category` (`category_id`),
  ADD KEY `idx_products_status` (`status`),
  ADD KEY `idx_products_view_count` (`view_count`),
  ADD KEY `idx_products_sold_count` (`sold_count`),
  ADD KEY `idx_products_name` (`name`);

--
-- Indexes for table `product_tags`
--
ALTER TABLE `product_tags`
  ADD PRIMARY KEY (`product_tag_id`),
  ADD KEY `idx_product_tags_product` (`product_id`),
  ADD KEY `idx_product_tags_tag` (`tag_id`);

--
-- Indexes for table `promos`
--
ALTER TABLE `promos`
  ADD PRIMARY KEY (`promo_id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `idx_promos_code` (`code`),
  ADD KEY `idx_promos_status` (`status`);

--
-- Indexes for table `promo_usages`
--
ALTER TABLE `promo_usages`
  ADD PRIMARY KEY (`promo_usage_id`),
  ADD KEY `idx_promo_usages_promo` (`promo_id`),
  ADD KEY `idx_promo_usages_order` (`order_id`),
  ADD KEY `idx_promo_usages_user` (`user_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `idx_reports_type` (`report_type`),
  ADD KEY `idx_reports_generated_by` (`generated_by`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `idx_reviews_order` (`order_id`),
  ADD KEY `idx_reviews_product` (`product_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tag_id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `idx_transactions_order` (`order_id`),
  ADD KEY `idx_transactions_status` (`status`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `referral_code` (`referral_code`),
  ADD KEY `referred_by` (`referred_by`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `idx_users_verification` (`verification_status`),
  ADD KEY `idx_users_seller_rating` (`seller_rating`),
  ADD KEY `idx_users_role_status` (`role`,`status`);

--
-- Indexes for table `user_bans`
--
ALTER TABLE `user_bans`
  ADD PRIMARY KEY (`ban_id`),
  ADD KEY `banned_by` (`banned_by`),
  ADD KEY `idx_user_bans_user` (`user_id`);

--
-- Indexes for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD PRIMARY KEY (`user_log_id`),
  ADD KEY `idx_user_logs_user` (`user_id`);

--
-- Indexes for table `verification_documents`
--
ALTER TABLE `verification_documents`
  ADD PRIMARY KEY (`verification_id`),
  ADD KEY `reviewed_by` (`reviewed_by`),
  ADD KEY `idx_verification_user` (`user_id`),
  ADD KEY `idx_verification_status` (`status`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`wallet_id`),
  ADD KEY `idx_wallets_user` (`user_id`),
  ADD KEY `idx_wallets_type` (`type`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`wishlist_id`),
  ADD KEY `idx_wishlists_user` (`user_id`),
  ADD KEY `idx_wishlists_product` (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `complaint_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `order_detail_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `payment_proofs`
--
ALTER TABLE `payment_proofs`
  MODIFY `payment_proof_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `product_tags`
--
ALTER TABLE `product_tags`
  MODIFY `product_tag_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `promos`
--
ALTER TABLE `promos`
  MODIFY `promo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `promo_usages`
--
ALTER TABLE `promo_usages`
  MODIFY `promo_usage_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `tag_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_bans`
--
ALTER TABLE `user_bans`
  MODIFY `ban_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_logs`
--
ALTER TABLE `user_logs`
  MODIFY `user_log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `verification_documents`
--
ALTER TABLE `verification_documents`
  MODIFY `verification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `wallet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `wishlist_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `complaints`
--
ALTER TABLE `complaints`
  ADD CONSTRAINT `complaints_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaints_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `complaints_ibfk_3` FOREIGN KEY (`resolved_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_3` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notifications_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`promo_id`) REFERENCES `promos` (`promo_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_proofs`
--
ALTER TABLE `payment_proofs`
  ADD CONSTRAINT `payment_proofs_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_proofs_ibfk_2` FOREIGN KEY (`verified_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE CASCADE;

--
-- Constraints for table `product_tags`
--
ALTER TABLE `product_tags`
  ADD CONSTRAINT `product_tags_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`tag_id`) ON DELETE CASCADE;

--
-- Constraints for table `promos`
--
ALTER TABLE `promos`
  ADD CONSTRAINT `promos_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`) ON DELETE SET NULL;

--
-- Constraints for table `promo_usages`
--
ALTER TABLE `promo_usages`
  ADD CONSTRAINT `promo_usages_ibfk_1` FOREIGN KEY (`promo_id`) REFERENCES `promos` (`promo_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `promo_usages_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `promo_usages_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`referred_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `user_bans`
--
ALTER TABLE `user_bans`
  ADD CONSTRAINT `user_bans_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_bans_ibfk_2` FOREIGN KEY (`banned_by`) REFERENCES `admins` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_logs`
--
ALTER TABLE `user_logs`
  ADD CONSTRAINT `user_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `verification_documents`
--
ALTER TABLE `verification_documents`
  ADD CONSTRAINT `verification_documents_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `verification_documents_ibfk_2` FOREIGN KEY (`reviewed_by`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL;

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
