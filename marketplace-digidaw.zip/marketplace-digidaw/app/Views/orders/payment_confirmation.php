<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px 0 rgba(31, 38, 135, 0.5);
        }

        .neon-effect {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .neon-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }

        .neon-effect:hover::before {
            left: 100%;
        }

        .neon-effect:hover {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(102, 126, 234, 0.6);
        }

        .floating-animation {
            animation: floating 3s ease-in-out infinite;
        }

        @keyframes floating {

            0%,
            100% {
                transform: translateY(0px);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .pulse-animation {
            animation: pulse-glow 2s infinite;
        }

        @keyframes pulse-glow {
            0% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            }

            50% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.8), 0 0 30px rgba(118, 75, 162, 0.6);
            }

            100% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            }
        }

        .notification-badge {
            background: linear-gradient(45deg, #ff6b6b, #ee5a24);
            animation: bounce 1s infinite;
        }

        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-10px);
            }

            60% {
                transform: translateY(-5px);
            }
        }

        .sidebar-nav {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nav-item {
            transition: all 0.3s ease;
            border-radius: 10px;
            margin: 4px 0;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .nav-item.active {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }

        .gradient-text {
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .loading-spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .dropdown-menu {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transform: translateY(-10px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0;
            visibility: hidden;
        }

        .dropdown-menu.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .toast-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 20px;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .toast-notification.show {
            transform: translateX(0);
        }

        .action-button {
            transition: all 0.3s ease;
            border-radius: 8px;
        }

        .action-button:hover {
            transform: scale(1.05);
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="p-4 glass-card mx-4 mt-4" data-aos="fade-down">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-2xl font-bold gradient-text flex items-center floating-animation">
                <span class="mr-2 text-3xl">🎮</span> DigiAw
            </a>
            <div class="flex items-center space-x-6">
                <?php if ($isLoggedIn): ?>
                    <div class="relative">
                        <button class="text-white hover:text-yellow-300 transition-colors duration-300 pulse-animation">
                            <i class="fas fa-bell text-xl"></i>
                            <?php if ($stats['notification_count'] > 0): ?>
                                <span class="notification-badge absolute -top-2 -right-2 text-xs rounded-full px-2 py-1 text-white font-bold">
                                    <?= $stats['notification_count'] ?>
                                </span>
                            <?php endif; ?>
                        </button>
                    </div>
                    <div class="relative dropdown">
                        <button class="flex items-center text-white hover:text-yellow-300 transition-colors duration-300">
                            <div class="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center mr-2">
                                <i class="fas fa-user text-sm"></i>
                            </div>
                            <span class="font-medium"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2 transition-transform duration-300"></i>
                        </button>
                        <div class="dropdown-menu absolute right-0 mt-2 w-48 py-2 z-10">
                            <a href="/profile/edit" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-user-edit mr-2"></i>Profil
                            </a>
                            <a href="/auth/logout" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-red-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                    <button onclick="toggleDarkMode()" class="text-white hover:text-yellow-300">
                        <i class="fas fa-moon"></i>
                    </button>
                <?php else: ?>
                    <a href="/auth/login" class="text-white hover:text-yellow-300 transition-colors duration-300">Login</a>
                    <a href="/auth/register" class="neon-effect px-6 py-2 rounded-full font-medium">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container mx-auto px-4 py-8">
        <h2 class="text-xl font-bold text-white mb-6 flex items-center" data-aos="fade-down">
            <i class="fas fa-credit-card mr-2 text-blue-400"></i>Konfirmasi Pembayaran
        </h2>
        <div class="glass-card p-8 max-w-lg mx-auto">
            <div class="text-center mb-6">
                <h3 class="text-lg font-bold text-white mb-2">Detail Pesanan</h3>
                <p class="text-white text-opacity-70">Pastikan detail pesanan Anda benar sebelum melakukan pembayaran.</p>
            </div>
            <div class="space-y-4 mb-6">
                <div class="flex justify-between">
                    <span class="text-white font-medium">ID Pesanan:</span>
                    <span class="text-white"><?= esc($order['order_id']) ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-white font-medium">Produk:</span>
                    <span class="text-white"><?= esc($order['product_name']) ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-white font-medium">Toko:</span>
                    <span class="text-white"><?= esc($order['seller_name']) ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-white font-medium">Total Harga:</span>
                    <span class="text-white font-bold">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-white font-medium">Saldo Anda:</span>
                    <span class="text-white <?= ($user['balance'] >= $order['total_price']) ? 'text-green-400' : 'text-red-400' ?>">Rp <?= number_format($user['balance'], 0, ',', '.') ?></span>
                </div>
            </div>
            <?php if ($user['balance'] >= $order['total_price']): ?>
                <button onclick="confirmPayment(<?= $order['order_id'] ?>)" class="action-button bg-blue-500 text-white w-full py-2 rounded-full neon-effect">
                    <i class="fas fa-check mr-2"></i>Konfirmasi Pembayaran
                </button>
            <?php else: ?>
                <p class="text-center text-red-400 mb-4">Saldo Anda tidak cukup. Silakan isi saldo terlebih dahulu.</p>
                <a href="/deposit" class="action-button bg-yellow-500 text-white w-full py-2 rounded-full neon-effect">
                    <i class="fas fa-wallet mr-2"></i>Isi Saldo
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toastTemplate" class="toast-notification" style="display: none;">
        <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                <i class="fas fa-check text-white text-sm"></i>
            </div>
            <div>
                <p class="font-medium text-gray-800" id="toastTitle">Success!</p>
                <p class="text-sm text-gray-600" id="toastMessage">Action completed successfully.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });

        let csrfToken = '<?= csrf_hash() ?>';

        function confirmPayment(orderId) {
            Swal.fire({
                title: 'Konfirmasi Pembayaran',
                text: 'Apakah Anda yakin ingin membayar dengan saldo akun Anda?',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'Bayar',
                cancelButtonText: 'Batal',
                customClass: {
                    confirmButton: 'bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600',
                    cancelButton: 'bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    showLoading();
                    fetch(`/orders/pay/${orderId}`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-Token': csrfToken,
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            hideLoading();
                            if (data.status === 'success') {
                                csrfToken = data.csrf_token || csrfToken;
                                showToast('Berhasil', data.message, 'success');
                                setTimeout(() => {
                                    window.location.href = '/orders';
                                }, 1000);
                            } else {
                                showToast('Error', data.message, 'error');
                            }
                        })
                        .catch(() => {
                            hideLoading();
                            showToast('Error', 'Terjadi kesalahan server.', 'error');
                        });
                }
            });
        }

        function showToast(title, message, type = 'success') {
            const toast = document.getElementById('toastTemplate').cloneNode(true);
            toast.id = 'toast-' + Date.now();
            toast.style.display = 'block';

            const icon = toast.querySelector('i');
            const iconContainer = toast.querySelector('.w-8');

            if (type === 'warning') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-exclamation text-white text-sm';
            } else if (type === 'error') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-times text-white text-sm';
            }

            toast.querySelector('#toastTitle').textContent = title;
            toast.querySelector('#toastMessage').textContent = message;

            document.body.appendChild(toast);

            setTimeout(() => toast.classList.add('show'), 100);
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        function showLoading() {
            const loading = document.createElement('div');
            loading.id = 'loadingOverlay';
            loading.style = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; display: flex; justify-content: center; align-items: center;';
            loading.innerHTML = '<div class="loading-spinner"></div>';
            document.body.appendChild(loading);
        }

        function hideLoading() {
            const loading = document.getElementById('loadingOverlay');
            if (loading) loading.remove();
        }

        document.querySelector('.dropdown button')?.addEventListener('click', function() {
            const menu = document.querySelector('.dropdown-menu');
            const chevron = this.querySelector('.fa-chevron-down');
            menu.classList.toggle('active');
            chevron.style.transform = menu.classList.contains('active') ? 'rotate(180deg)' : 'rotate(0deg)';
        });

        document.addEventListener('click', function(event) {
            const dropdown = document.querySelector('.dropdown');
            if (!dropdown.contains(event.target)) {
                document.querySelector('.dropdown-menu').classList.remove('active');
                document.querySelector('.fa-chevron-down').style.transform = 'rotate(0deg)';
            }
        });

        function toggleDarkMode() {
            document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', document.body.classList.contains('dark') ? 'enabled' : 'disabled');
        }
        if (localStorage.getItem('darkMode') === 'enabled') {
            document.body.classList.add('dark');
        }
    </script>
</body>

</html>