<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px 0 rgba(31, 38, 135, 0.5);
        }

        .neon-effect {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .neon-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }

        .neon-effect:hover::before {
            left: 100%;
        }

        .neon-effect:hover {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(102, 126, 234, 0.6);
        }

        .floating-animation {
            animation: floating 3s ease-in-out infinite;
        }

        @keyframes floating {

            0%,
            100% {
                transform: translateY(0px);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .pulse-animation {
            animation: pulse-glow 2s infinite;
        }

        @keyframes pulse-glow {
            0% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            }

            50% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.8), 0 0 30px rgba(118, 75, 162, 0.6);
            }

            100% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            }
        }

        .notification-badge {
            background: linear-gradient(45deg, #ff6b6b, #ee5a24);
            animation: bounce 1s infinite;
        }

        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-10px);
            }

            60% {
                transform: translateY(-5px);
            }
        }

        .sidebar-nav {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nav-item {
            transition: all 0.3s ease;
            border-radius: 10px;
            margin: 4px 0;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .nav-item.active {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }

        .gradient-text {
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .loading-spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .dropdown-menu {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transform: translateY(-10px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0;
            visibility: hidden;
        }

        .dropdown-menu.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            backdrop-filter: blur(15px);
            border-radius: 16px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .stat-card:hover::before {
            transform: scaleX(1);
        }

        .stat-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        }

        .toast-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 20px;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .toast-notification.show {
            transform: translateX(0);
        }

        .filter-input {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            color: white;
            padding: 10px;
        }

        .filter-input:hover,
        .filter-input:focus {
            background: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.4);
        }

        .filter-select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 0.75rem center;
            background-size: 1em;
        }

        .order-row {
            transition: all 0.3s ease;
        }

        .order-row:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }

        .action-button {
            transition: all 0.3s ease;
            border-radius: 8px;
        }

        .action-button:hover {
            transform: scale(1.05);
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="p-4 glass-card mx-4 mt-4" data-aos="fade-down">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-2xl font-bold gradient-text flex items-center floating-animation">
                <span class="mr-2 text-3xl">🎮</span> DigiAw
            </a>
            <div class="flex items-center space-x-6">
                <?php if ($isLoggedIn): ?>
                    <div class="relative">
                        <button class="text-white hover:text-yellow-300 transition-colors duration-300 pulse-animation">
                            <i class="fas fa-bell text-xl"></i>
                            <?php if ($stats['notification_count'] > 0): ?>
                                <span class="notification-badge absolute -top-2 -right-2 text-xs rounded-full px-2 py-1 text-white font-bold">
                                    <?= $stats['notification_count'] ?>
                                </span>
                            <?php endif; ?>
                        </button>
                    </div>
                    <div class="relative dropdown">
                        <button class="flex items-center text-white hover:text-yellow-300 transition-colors duration-300">
                            <div class="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center mr-2">
                                <i class="fas fa-user text-sm"></i>
                            </div>
                            <span class="font-medium"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2 transition-transform duration-300"></i>
                        </button>
                        <div class="dropdown-menu absolute right-0 mt-2 w-48 py-2 z-10">
                            <a href="/profile/edit" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-user-edit mr-2"></i>Profil
                            </a>
                            <a href="/auth/logout" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-red-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                    <button onclick="toggleDarkMode()" class="text-white hover:text-yellow-300">
                        <i class="fas fa-moon"></i>
                    </button>
                <?php else: ?>
                    <a href="/auth/login" class="text-white hover:text-yellow-300 transition-colors duration-300">Login</a>
                    <a href="/auth/register" class="neon-effect px-6 py-2 rounded-full font-medium">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container mx-auto px-4 py-8 flex gap-8">
        <!-- Sidebar -->
        <aside class="w-64 hidden md:block" data-aos="fade-right">
            <div class="sidebar-nav p-6">
                <h3 class="text-xl font-bold text-white mb-6 gradient-text">Navigasi</h3>
                <ul class="space-y-2">
                    <li><a href="/dashboard" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-home mr-3"></i> Dashboard</a></li>
                    <li><a href="/orders" class="nav-item active block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-shopping-bag mr-3"></i> Pesanan</a></li>
                    <li><a href="/cart" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-shopping-cart mr-3"></i> Keranjang <?php if ($stats['cart_count'] > 0): ?><span class="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1"><?= $stats['cart_count'] ?></span><?php endif; ?></a></li>
                    <li><a href="/wishlist" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-heart mr-3"></i> Wishlist</a></li>
                    <li><a href="/transactions" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-wallet mr-3"></i> Riwayat Transaksi</a></li>
                    <li><a href="/notifications" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-bell mr-3"></i> Notifikasi <?php if ($stats['notification_count'] > 0): ?><span class="ml-auto notification-badge text-white text-xs rounded-full px-2 py-1"><?= $stats['notification_count'] ?></span><?php endif; ?></a></li>
                    <li><a href="/promos" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-tags mr-3"></i> Promo</a></li>
                    <li><a href="/referral" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-user-plus mr-3"></i> Referral</a></li>
                    <li><a href="/profile/edit" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-cog mr-3"></i> Pengaturan</a></li>
                </ul>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="flex-1">
            <h2 class="text-3xl font-bold text-white mb-8 flex items-center" data-aos="fade-down">
                <i class="fas fa-shopping-bag mr-3 text-blue-400"></i>Pesanan Saya
            </h2>

            <!-- Statistik -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Total Pesanan</h3>
                            <p class="text-2xl font-bold text-white mt-2"><?= esc($stats['total_orders']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center floating-animation">
                            <i class="fas fa-shopping-bag text-white text-xl"></i>
                        </div>
                    </div>
                </div>
                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Pesanan Tertunda</h3>
                            <p class="text-2xl font-bold text-white mt-2"><?= esc($stats['pending_orders']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center floating-animation">
                            <i class="fas fa-hourglass-half text-white text-xl"></i>
                        </div>
                    </div>
                </div>
                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Pesanan Selesai</h3>
                            <p class="text-2xl font-bold text-white mt-2"><?= esc($stats['completed_orders']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center floating-animation">
                            <i class="fas fa-check-circle text-white text-xl"></i>
                        </div>
                    </div>
                </div>
                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Pesanan Dibatalkan</h3>
                            <p class="text-2xl font-bold text-white mt-2"><?= esc($stats['cancelled_orders']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center floating-animation">
                            <i class="fas fa-times-circle text-white text-xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filter -->
            <div class="mb-8 flex flex-col sm:flex-row sm:space-x-4 space-y-4 sm:space-y-0" data-aos="fade-up">
                <select id="orderFilter" class="filter-input filter-select p-3 rounded w-full sm:w-auto text-white">
                    <option value="" selected>Semua Status</option>
                    <option value="pending">Tertunda</option>
                    <option value="completed">Selesai</option>
                    <option value="cancelled">Dibatalkan</option>
                </select>
                <input type="text" id="orderDate" class="filter-input p-3 rounded w-full sm:w-auto" placeholder="Pilih Tanggal">
                <input type="text" id="productFilter" class="filter-input p-3 rounded w-full sm:w-auto" placeholder="Cari Nama Produk">
                <input type="text" id="sellerFilter" class="filter-input p-3 rounded w-full sm:w-auto" placeholder="Cari Nama Toko">
            </div>

            <!-- Tabel Pesanan -->
            <div class="glass-card p-8" data-aos="fade-up">
                <h3 class="text-xl font-bold text-white mb-6 flex items-center">
                    <i class="fas fa-list mr-3 text-purple-400"></i>Daftar Pesanan
                </h3>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="border-b border-white border-opacity-20">
                                <th class="py-3 px-4 text-white opacity-80">No</th>
                                <th class="py-3 px-4 text-white opacity-80">ID Pesanan</th>
                                <th class="py-3 px-4 text-white opacity-80">Produk</th>
                                <th class="py-3 px-4 text-white opacity-80">Toko</th>
                                <th class="py-3 px-4 text-white opacity-80">Total</th>
                                <th class="py-3 px-4 text-white opacity-80">Status</th>
                                <th class="py-3 px-4 text-white opacity-80">Tanggal</th>
                                <th class="py-3 px-4 text-white opacity-80">Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="orderTable">
                            <?php $no = 1;
                            foreach ($orders as $order): ?>
                                <tr class="order-row border-b border-white border-opacity-10">
                                    <td class="py-3 px-4 text-white"><?= $no++ ?></td>
                                    <td class="py-3 px-4 text-white"><?= esc($order['order_id']) ?></td>
                                    <td class="py-3 px-4 text-white"><?= esc($order['product_name']) ?></td>
                                    <td class="py-3 px-4 text-white"><?= esc($order['seller_name']) ?></td>
                                    <td class="py-3 px-4 text-white">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></td>
                                    <td class="py-3 px-4">
                                        <span class="px-3 py-1 rounded-full text-sm <?= $order['status'] === 'completed' ? 'bg-green-500 text-white' : ($order['status'] === 'pending' ? 'bg-yellow-500 text-white' : 'bg-red-500 text-white') ?>">
                                            <?= ucfirst($order['status']) ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-white"><?= date('d M Y', strtotime($order['created_at'])) ?></td>
                                    <td class="py-3 px-4 text-white flex flex-wrap gap-2">
                                        <?php if ($order['status'] === 'pending'): ?>
                                            <a href="/orders/payment/<?= $order['order_id'] ?>" class="action-button bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600">
                                                <i class="fas fa-money-bill-wave mr-1"></i>Bayar
                                            </a>
                                            <button onclick="cancelOrder(<?= $order['order_id'] ?>)" class="action-button bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600">
                                                <i class="fas fa-times mr-1"></i>Batalkan
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($orders)): ?>
                                <tr>
                                    <td colspan="8" class="py-8 px-4 text-white opacity-70 text-center">Belum ada pesanan.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast Notification Template -->
    <div id="toastTemplate" class="toast-notification" style="display: none;">
        <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                <i class="fas fa-check text-white text-sm"></i>
            </div>
            <div>
                <p class="font-medium text-gray-800" id="toastTitle">Success!</p>
                <p class="text-sm text-gray-600" id="toastMessage">Action completed successfully.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr@4.6.13/dist/flatpickr.min.js"></script>
    <script>
        // In orders/index.php, update contactSeller function
        function contactSeller(orderId) {
            // if (!orderId) {
            //     console.error('contactSeller: orderId is undefined');
            //     showToast('Error', 'Order ID tidak valid.', 'error');
            //     return;
            // }
            // console.log('Sending order_id:', orderId);
            // showLoading();
            // const formData = new FormData();
            // formData.append('order_id', orderId);
            // formData.append('csrf_token', document.getElementById('csrf_token').value);

            // fetch('/chat/startChatWithSeller', {
            //         method: 'POST',
            //         headers: {
            //             'X-CSRF-Token': document.getElementById('csrf_token').value,
            //             'X-Requested-With': 'XMLHttpRequest'
            //         },
            //         body: formData
            //     })
            //     .then(response => {
            //         if (!response.ok) {
            //             throw new Error(`HTTP error! status: ${response.status}`);
            //         }
            //         return response.json();
            //     })
            //     .then(data => {
            //         hideLoading();
            //         console.log('Response data:', data);
            //         if (data.success) {
            //             // Update CSRF token
            //             if (data.csrf_token) {
            //                 document.getElementById('csrf_token').value = data.csrf_token;
            //                 csrfToken = data.csrf_token; // Update global csrfToken variable
            //             }
            //             showToast('Berhasil', 'Memulai chat dengan seller.', 'success');
            //             window.location.href = '/chat';
            //         } else {
            //             showToast('Gagal', data.message, 'error');
            //         }
            //     })
            //     .catch(error => {
            //         hideLoading();
            //         console.error('Fetch error:', error);
            //         showToast('Error', 'Terjadi kesalahan server: ' + error.message, 'error');
            //     });
        }
        // popup sederhana (gunakan modal dashboard jika sudah ada)
        function openChatPopup(orderId, sellerId, sellerName) {
            // jika kamu sudah punya modal di dashboard, tinggal panggil:
            // startChat(orderId);
            // kalau belum, pakai alert dulu
            Swal.fire({
                title: `Chat dengan ${sellerName}`,
                html: `<iframe src="/chat/${orderId}" width="100%" height="400" frameborder="0"></iframe>`,
                width: 600,
                showCloseButton: true,
                showConfirmButton: false
            });
        }
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });

        flatpickr("#orderDate", {
            dateFormat: "Y-m-d",
            enableTime: false,
            locale: {
                firstDayOfWeek: 1,
                weekdays: {
                    shorthand: ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'],
                    longhand: ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu']
                },
                months: {
                    shorthand: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'],
                    longhand: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
                }
            }
        });

        document.querySelector('.dropdown button')?.addEventListener('click', function() {
            const menu = document.querySelector('.dropdown-menu');
            const chevron = this.querySelector('.fa-chevron-down');
            menu.classList.toggle('active');
            chevron.style.transform = menu.classList.contains('active') ? 'rotate(180deg)' : 'rotate(0deg)';
        });

        document.addEventListener('click', function(event) {
            const dropdown = document.querySelector('.dropdown');
            if (!dropdown.contains(event.target)) {
                document.querySelector('.dropdown-menu').classList.remove('active');
                document.querySelector('.fa-chevron-down').style.transform = 'rotate(0deg)';
            }
        });

        function toggleDarkMode() {
            document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', document.body.classList.contains('dark') ? 'enabled' : 'disabled');
        }
        if (localStorage.getItem('darkMode') === 'enabled') {
            document.body.classList.add('dark');
        }

        let csrfToken = '<?= csrf_hash() ?>';

        const orderFilter = document.getElementById('orderFilter');
        const orderDate = document.getElementById('orderDate');
        const productFilter = document.getElementById('productFilter');
        const sellerFilter = document.getElementById('sellerFilter');

        [orderFilter, orderDate, productFilter, sellerFilter].forEach(input => {
            input?.addEventListener('change', filterOrders);
        });

        function filterOrders() {
            const status = orderFilter.value;
            const date = orderDate.value;
            const product = productFilter.value.toLowerCase();
            const seller = sellerFilter.value.toLowerCase();
            const orders = <?= json_encode($orders) ?>;
            let filtered = orders;

            if (status) {
                filtered = filtered.filter(order => order.status === status);
            }
            if (date) {
                filtered = filtered.filter(order => order.created_at.split(' ')[0] === date);
            }
            if (product) {
                filtered = filtered.filter(order => order.product_name.toLowerCase().includes(product));
            }
            if (seller) {
                filtered = filtered.filter(order => order.seller_name.toLowerCase().includes(seller));
            }

            const tableBody = document.getElementById('orderTable');
            tableBody.innerHTML = '';
            if (filtered.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="8" class="py-8 px-4 text-white opacity-70 text-center">Tidak ada pesanan.</td></tr>';
            } else {
                filtered.forEach((order, index) => {
                    let actions = `
                    `;
                    if (order.status === 'pending') {
                        actions = `
                            <a href="/orders/payment/${order.order_id}" class="action-button bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 mr-2">
                                <i class="fas fa-money-bill-wave mr-1"></i>Bayar
                            </a>
                            <button onclick="cancelOrder(${order.order_id})" class="action-button bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 mr-2">
                                <i class="fas fa-times mr-1"></i>Batalkan
                            </button>
                            ${actions}
                        `;
                    }

                    tableBody.innerHTML += `
                        <tr class="order-row border-b border-white border-opacity-10">
                            <td class="py-3 px-4 text-white">${index + 1}</td>
                            <td class="py-3 px-4 text-white">${order.order_id}</td>
                            <td class="py-3 px-4 text-white">${order.product_name}</td>
                            <td class="py-3 px-4 text-white">${order.seller_name}</td>
                            <td class="py-3 px-4 text-white">Rp ${Number(order.total_price).toLocaleString('id-ID', { minimumFractionDigits: 0 })}</td>
                            <td class="py-3 px-4">
                                <span class="px-3 py-1 rounded-full text-sm ${order.status === 'completed' ? 'bg-green-500 text-white' : (order.status === 'pending' ? 'bg-yellow-500 text-white' : 'bg-red-500 text-white')}">
                                    ${order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                                </span>
                            </td>
                            <td class="py-3 px-4 text-white">${new Date(order.created_at).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                            <td class="py-3 px-4 text-white flex flex-wrap gap-2">${actions}</td>
                        </tr>
                    `;
                });
            }
            AOS.refresh();
        }

        function cancelOrder(orderId) {
            Swal.fire({
                title: 'Batalkan Pesanan?',
                text: 'Pesanan ini akan dibatalkan dan tidak dapat dikembalikan.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Batalkan',
                cancelButtonText: 'Tidak',
                customClass: {
                    confirmButton: 'bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600',
                    cancelButton: 'bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    showLoading();
                    fetch(`/orders/cancel/${orderId}`, {
                            method: 'POST',
                            headers: {
                                'X-CSRF-Token': csrfToken,
                                'X-Requested-With': 'XMLHttpRequest'
                            }
                        })
                        .then(response => response.json())
                        .then(data => {
                            hideLoading();
                            if (data.status === 'success') {
                                csrfToken = data.csrf_token || csrfToken;
                                showToast('Berhasil', data.message, 'success');
                                filterOrders();
                            } else {
                                showToast('Gagal', data.message, 'error');
                            }
                        })
                        .catch(() => {
                            hideLoading();
                            showToast('Error', 'Terjadi kesalahan server.', 'error');
                        });
                }
            });
        }

        function contactSeller(orderId) {
            showLoading();
            fetch('/chat/startChatWithSeller', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-Token': csrfToken,
                        'X-Requested-With': 'XMLHttpRequest',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        order_id: orderId
                    })
                })
                .then(response => response.json())
                .then(data => {
                    hideLoading();
                    if (data.success) {
                        showToast('Berhasil', 'Memulai chat dengan seller.', 'success');
                        window.location.href = '/chat'; // Ganti dengan URL halaman chat
                    } else {
                        showToast('Gagal', data.message, 'error');
                    }
                })
                .catch(() => {
                    hideLoading();
                    showToast('Error', 'Terjadi kesalahan server.', 'error');
                });
        }

        function showToast(title, message, type = 'success') {
            const toast = document.getElementById('toastTemplate').cloneNode(true);
            toast.id = 'toast-' + Date.now();
            toast.style.display = 'block';

            const icon = toast.querySelector('i');
            const iconContainer = toast.querySelector('.w-8');

            if (type === 'warning') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-exclamation text-white text-sm';
            } else if (type === 'error') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-times text-white text-sm';
            }

            toast.querySelector('#toastTitle').textContent = title;
            toast.querySelector('#toastMessage').textContent = message;

            document.body.appendChild(toast);

            setTimeout(() => toast.classList.add('show'), 100);
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        function showLoading() {
            const loading = document.createElement('div');
            loading.id = 'loadingOverlay';
            loading.style = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999; display: flex; justify-content: center; align-items: center;';
            loading.innerHTML = '<div class="loading-spinner"></div>';
            document.body.appendChild(loading);
        }

        function hideLoading() {
            const loading = document.getElementById('loadingOverlay');
            if (loading) loading.remove();
        }

        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            });
        });

        let ticking = false;

        function updateParallax() {
            const scrolled = window.pageYOffset;
            const speed = scrolled * 0.5;
            document.body.style.backgroundPosition = `center ${speed}px`;
            ticking = false;
        }
        window.addEventListener('scroll', function() {
            if (!ticking) {
                requestAnimationFrame(updateParallax);
                ticking = true;
            }
        });
    </script>
    <script>
        const csrfToken = '<?= csrf_hash() ?>'; // Ensure CSRF token is correctly set
    </script>
</body>

</html>