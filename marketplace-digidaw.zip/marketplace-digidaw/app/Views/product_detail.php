<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= csrf_hash() ?>">
    <title><?= esc($product['name']) ?> - DigiDaw</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/howler/2.2.3/howler.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            background: linear-gradient(135deg, #e0f2fe 0%, #d1fae5 100%);
        }

        .dark body {
            background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
        }

        /* Navbar */
        .navbar {
            backdrop-filter: blur(10px);
            background: rgba(163, 191, 250, 0.2);
            border-bottom: 1px solid rgba(163, 191, 250, 0.3);
            transition: background 0.3s ease;
            position: sticky;
            top: 0;
            z-index: 50;
        }

        .dark .navbar {
            background: rgba(45, 55, 72, 0.2);
            border-bottom: 1px solid rgba(198, 232, 215, 0.3);
        }

        .navbar a,
        .navbar button {
            color: #2d3748;
            transition: color 0.3s ease;
        }

        .dark .navbar a,
        .dark .navbar button {
            color: #e0e7ff;
        }

        .navbar a:hover,
        .navbar button:hover {
            color: #4a90e2;
        }

        .dark .navbar a:hover,
        .dark .navbar button:hover {
            color: #c6e8d7;
        }

        /* Dropdown */
        .dropdown-menu {
            transition: opacity 0.3s ease, transform 0.3s ease;
            transform: translateY(10px);
        }

        .dropdown:hover .dropdown-menu {
            opacity: 1;
            transform: translateY(0);
            visibility: visible;
        }

        /* Glassmorphism Card */
        .glass-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            padding: 2rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .dark .glass-card {
            background: rgba(74, 85, 104, 0.2);
            border-color: rgba(198, 232, 215, 0.2);
        }

        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        /* Product Image with Zoom */
        .card-3d {
            border-radius: 15px;
            overflow: hidden;
            transition: transform 0.3s ease;
        }

        .card-3d:hover {
            transform: translateY(-5px);
        }

        .image-zoom-container {
            position: relative;
            overflow: hidden;
        }

        .image-zoom-container:hover #main-image {
            transform: scale(1.5);
        }

        #main-image {
            width: 100%;
            height: auto;
            transition: transform 0.3s ease;
        }

        .thumbnail-gallery {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0.75rem;
            margin-top: 1.5rem;
        }

        .thumbnail {
            cursor: pointer;
            border-radius: 8px;
            overflow: hidden;
            border: 2px solid transparent;
            transition: border-color 0.3s ease, transform 0.3s ease;
        }

        .thumbnail:hover,
        .thumbnail.active {
            border-color: #4a90e2;
            transform: scale(1.05);
        }

        /* Tabs */
        .tab-buttons {
            border-bottom: 1px solid #a3bffa;
            display: flex;
            margin-bottom: 1.5rem;
        }

        .dark .tab-buttons {
            border-color: #64748b;
        }

        .tab-button {
            padding: 0.75rem 1.5rem;
            color: #4a5568;
            transition: color 0.3s ease;
        }

        .dark .tab-button {
            color: #d1d5db;
        }

        .tab-button.active {
            color: #4a90e2;
            border-bottom: 2px solid #4a90e2;
        }

        .dark .tab-button.active {
            color: #c6e8d7;
            border-color: #c6e8d7;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        /* Carousel */
        .carousel {
            position: relative;
            overflow: hidden;
        }

        .carousel-container {
            display: flex;
            transition: transform 0.5s ease;
        }

        .carousel-item {
            flex: 0 0 25%;
            padding: 0 0.5rem;
        }

        .carousel-button {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0, 0, 0, 0.2);
            color: white;
            border: none;
            padding: 0.75rem;
            border-radius: 50%;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .carousel-button:hover {
            background: rgba(0, 0, 0, 0.4);
        }

        /* Form */
        .input-field {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 0.75rem;
            transition: border-color 0.3s ease;
        }

        .dark .input-field {
            border-color: #4a5568;
            background: #4a5568;
            color: #e0e7ff;
        }

        .input-field:focus {
            border-color: #4a90e2;
            outline: none;
        }

        .dark .input-field:focus {
            border-color: #c6e8d7;
        }

        /* Neon Effect Button */
        .neon-effect {
            background: none;
            color: #4a90e2;
            border: 2px solid #4a90e2;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
        }

        .dark .neon-effect {
            color: #c6e8d7;
            border-color: #c6e8d7;
        }

        .neon-effect:hover {
            background: #4a90e2;
            color: white;
        }

        .dark .neon-effect:hover {
            background: #c6e8d7;
            color: #2d3748;
        }

        /* Share Button */
        .share-button {
            background: none;
            color: #4a90e2;
            border: 2px solid #4a90e2;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
        }

        .dark .share-button {
            color: #c6e8d7;
            border-color: #c6e8d7;
        }

        .share-button:hover {
            background: #4a90e2;
            color: white;
        }

        .dark .share-button:hover {
            background: #c6e8d7;
            color: #2d3748;
        }

        /* Recently Viewed */
        .recently-viewed-item {
            transition: transform 0.3s ease;
        }

        .recently-viewed-item:hover {
            transform: translateY(-5px);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .glass-card {
                padding: 1.5rem;
            }

            .thumbnail-gallery {
                grid-template-columns: repeat(2, 1fr);
            }

            .carousel-item {
                flex: 0 0 50%;
            }
        }

        @media (max-width: 480px) {
            .carousel-item {
                flex: 0 0 100%;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-4a90e2 to-c6e8d7 flex items-center">
                <span class="mr-2">🎮</span> DigiDaw
            </a>
            <div class="flex items-center space-x-6">
                <a href="/cart/checkout" class="relative">
                    <i class="fas fa-shopping-cart text-xl"></i>
                    <span id="cart-count" class="cart-badge" style="display: <?= array_sum(array_column($cartItems, 'quantity')) > 0 ? 'inline-block' : 'none' ?>;">
                        <?= array_sum(array_column($cartItems, 'quantity')) ?>
                    </span>
                </a>
                <?php if ($isLoggedIn): ?>
                    <div class="relative dropdown">
                        <button class="flex items-center text-2d3748 dark:text-e0e7ff hover:text-4a90e2 transition-all duration-300">
                            <i class="fas fa-user-circle mr-2 text-2xl"></i>
                            <span class="font-semibold"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2 text-sm"></i>
                        </button>
                        <div class="dropdown-menu absolute right-0 mt-2 w-48 bg-white dark:bg-4a5568 rounded-lg shadow-lg py-2 opacity-0 invisible">
                            <a href="/profile" class="block px-4 py-2 text-2d3748 dark:text-e0e7ff hover:bg-4a90e2 hover:text-white">Profil</a>
                            <a href="/dashboard" class="block px-4 py-2 text-2d3748 dark:text-e0e7ff hover:bg-4a90e2 hover:text-white">Dashboard</a>
                            <a href="/auth/logout" class="block px-4 py-2 text-2d3748 dark:text-e0e7ff hover:bg-ef4444 hover:text-white">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="/auth/login" class="text-2d3748 dark:text-e0e7ff hover:text-4a90e2 font-medium">Masuk</a>
                    <a href="/auth/register" class="bg-4a90e2 hover:bg-c6e8d7 text-white px-4 py-2 rounded-full hover:shadow transition-all duration-300 font-semibold">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Breadcrumb -->
    <div class="container mx-auto px-4 mt-4">
        <ol class="flex space-x-2 text-sm text-4a5568 dark:text-d1d5db">
            <li><a href="/" class="hover:text-4a90e2">Beranda</a></li>
            <li>/</li>
            <li><a href="/products?category=<?= esc($product['category_id']) ?>" class="hover:text-4a90e2"><?= esc($product['category_name']) ?></a></li>
            <li>/</li>
            <li class="text-4a5568 dark:text-d1d5db"><?= esc($product['name']) ?></li>
        </ol>
    </div>

    <!-- Product Detail -->
    <div class="container mx-auto px-4 mt-6 mb-12">
        <div class="glass-card">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Product Image -->
                <div class="card-3d">
                    <div class="image-zoom-container rounded-lg">
                        <img id="main-image" src="<?= esc($product['image_url']) ?: 'https://via.placeholder.com/600x400?text=' . urlencode($product['name']) ?>" alt="<?= esc($product['name']) ?>" class="w-full h-96 object-cover">
                    </div>
                    <div class="thumbnail-gallery">
                        <?php for ($i = 1; $i <= 4; $i++): ?>
                            <img src="<?= esc($product['image_url']) ?: 'https://via.placeholder.com/100x100?text=Thumb+' . $i ?>" class="thumbnail object-cover <?= $i === 1 ? 'active' : '' ?>" alt="Thumbnail <?= $i ?>">
                        <?php endfor; ?>
                    </div>
                </div>
                <!-- Product Info -->
                <div>
                    <h2 class="text-3xl font-bold text-2d3748 dark:text-e0e7ff mb-4"><?= esc($product['name']) ?></h2>
                    <p class="text-2xl font-semibold text-4a90e2 dark:text-c6e8d7 mb-4">Rp <?= number_format($product['price'], 2, ',', '.') ?></p>
                    <div class="flex items-center mb-4">
                        <div class="flex text-yellow-500">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star text-lg <?= $i <= 4.5 ? '' : 'fa-star-half-alt' ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <span class="text-4a5568 dark:text-d1d5db ml-2">(4.5/5)</span>
                    </div>
                    <div class="space-y-2 mb-6">
                        <p class="text-4a5568 dark:text-d1d5db"><strong>Kategori:</strong> <?= esc($product['category_name']) ?></p>
                        <p class="text-4a5568 dark:text-d1d5db"><strong>Stok:</strong> <span class="text-green-600"><?= esc($product['stock'] ?? 500) ?>+ Tersedia</span></p>
                    </div>

                    <form id="addToCartForm" class="space-y-6">
                        <input type="hidden" name="product_id" value="<?= esc($product['product_id']) ?>">
                        <?= csrf_field() ?>
                        <?php if ($form_type === 'pulsa'): ?>
                            <div>
                                <label for="phone_number" class="block text-4a5568 dark:text-d1d5db font-medium mb-2">Nomor HP</label>
                                <input type="text" id="phone_number" name="phone_number" class="input-field w-full max-w-md" placeholder="Contoh: 081234567890" required>
                                <div id="phone_number_error" class="text-red-500 text-sm mt-1 hidden"></div>
                                <div id="phone_operator" class="text-4a5568 dark:text-d1d5db text-sm mt-1"></div>
                            </div>
                        <?php elseif ($form_type === 'voucher_game'): ?>
                            <div>
                                <label for="game_name" class="block text-4a5568 dark:text-d1d5db font-medium mb-2">Pilih Game</label>
                                <select id="game_name" name="game_name" class="input-field w-full max-w-md" required>
                                    <option value="" disabled selected>Pilih game</option>
                                    <option value="mobile_legends">Mobile Legends</option>
                                    <option value="free_fire">Free Fire</option>
                                    <option value="pubg">PUBG</option>
                                    <option value="valorant">Valorant</option>
                                </select>
                            </div>
                            <div>
                                <label for="game_id" class="block text-4a5568 dark:text-d1d5db font-medium mb-2">ID Game</label>
                                <input type="text" id="game_id" name="game_id" class="input-field w-full max-w-md" placeholder="Pilih game terlebih dahulu" required>
                                <div id="game_id_error" class="text-red-500 text-sm mt-1 hidden"></div>
                            </div>
                        <?php endif; ?>
                        <div class="flex items-center">
                            <label for="quantity" class="text-4a5568 dark:text-d1d5db font-medium mr-4">Jumlah:</label>
                            <input type="number" id="quantity" name="quantity" class="input-field w-20" value="1" min="1" max="<?= esc($product['stock'] ?? 10) ?>">
                        </div>
                        <div class="flex space-x-4 flex-wrap gap-y-4">
                            <button type="button" id="addToCartButton" class="neon-effect flex items-center">
                                <i class="fas fa-cart-plus mr-2"></i> Tambah ke Keranjang
                            </button>
                            <button type="button" id="buyNowButton" class="neon-effect flex items-center">
                                <i class="fas fa-shopping-bag mr-2"></i> Beli Sekarang
                            </button>
                            <button type="button" id="shareButton" class="share-button flex items-center">
                                <i class="fas fa-share-alt mr-2"></i> Bagikan
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabs -->
            <div class="mt-8">
                <div class="tab-buttons">
                    <button class="tab-button active" data-tab="description">Deskripsi</button>
                    <button class="tab-button" data-tab="reviews">Ulasan</button>
                    <button class="tab-button" data-tab="specifications">Spesifikasi</button>
                </div>
                <div id="description" class="tab-content active">
                    <p class="text-4a5568 dark:text-d1d5db"><?= esc($product['description'] ?? 'Tidak ada deskripsi tersedia.') ?></p>
                </div>
                <div id="reviews" class="tab-content">
                    <p class="text-4a5568 dark:text-d1d5db">Belum ada ulasan untuk produk ini. Jadilah yang pertama mengulas!</p>
                </div>
                <div id="specifications" class="tab-content">
                    <p class="text-4a5568 dark:text-d1d5db">Spesifikasi: <?= esc($product['specifications'] ?? 'Tidak ada spesifikasi tersedia.') ?></p>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <div class="mt-12">
            <h2 class="text-2xl font-bold text-2d3748 dark:text-e0e7ff mb-4">Produk Serupa</h2>
            <?php if (empty($related_products)): ?>
                <p class="text-4a5568 dark:text-d1d5db">Tidak ada produk serupa saat ini.</p>
            <?php else: ?>
                <div class="carousel">
                    <button class="carousel-button left"><i class="fas fa-chevron-left"></i></button>
                    <div class="carousel-container">
                        <?php foreach ($related_products as $related): ?>
                            <div class="carousel-item card-3d">
                                <img src="<?= esc($related['image_url']) ?: 'https://via.placeholder.com/300' ?>" alt="<?= esc($related['name']) ?>" class="w-full h-48 object-cover rounded-t-lg">
                                <div class="p-3 bg-white dark:bg-4a5568 rounded-b-lg">
                                    <h3 class="text-lg font-semibold text-2d3748 dark:text-e0e7ff truncate"><?= esc($related['name']) ?></h3>
                                    <p class="text-4a90e2 dark:text-c6e8d7 font-medium mt-2">Rp <?= number_format($related['price'], 2, ',', '.') ?></p>
                                    <a href="/product/<?= $related['product_id'] ?>" class="text-4a90e2 dark:text-c6e8d7 hover:underline mt-2 block">Lihat Detail</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button class="carousel-button right"><i class="fas fa-chevron-right"></i></button>
                </div>
            <?php endif; ?>
        </div>

        <!-- Recently Viewed Products -->
        <div class="mt-12">
            <h2 class="text-2xl font-bold text-2d3748 dark:text-e0e7ff mb-4">Baru Dilihat</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6" id="recently-viewed">
                <!-- Populated via JavaScript -->
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-2d3748 text-e0e7ff py-8 mt-12">
        <div class="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-6 px-4">
            <div>
                <h3 class="text-xl font-bold mb-3">DigiDaw</h3>
                <p class="text-d1d5db leading-relaxed">Marketplace terpercaya untuk item digital dan kebutuhan gaming Anda.</p>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-3">Link Cepat</h4>
                <ul class="space-y-2">
                    <li><a href="/" class="text-d1d5db hover:text-4a90e2 transition">Beranda</a></li>
                    <li><a href="/products" class="text-d1d5db hover:text-4a90e2 transition">Produk</a></li>
                    <li><a href="/cart/checkout" class="text-d1d5db hover:text-4a90e2 transition">Keranjang</a></li>
                    <li><a href="/dashboard" class="text-d1d5db hover:text-4a90e2 transition">Dashboard</a></li>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-3">Kontak Kami</h4>
                <ul class="space-y-2">
                    <li><a href="mailto:support@digidaw.com" class="text-d1d5db hover:text-4a90e2 transition">support@digidaw.com</a></li>
                    <li><a href="tel:+6281234567890" class="text-d1d5db hover:text-4a90e2 transition">+62 812-3456-7890</a></li>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-3">Ikuti Kami</h4>
                <div class="flex space-x-4">
                    <a href="#" class="text-d1d5db hover:text-4a90e2 text-xl transition"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-d1d5db hover:text-4a90e2 text-xl transition"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-d1d5db hover:text-4a90e2 text-xl transition"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
        <div class="text-center mt-4 text-d1d5db">
            © 2025 DigiDaw. All Rights Reserved.
        </div>
    </footer>

    <script>
        // Dark Mode Toggle
        function toggleDarkMode() {
            const isDark = document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', isDark ? 'enabled' : 'disabled');
        }
        if (localStorage.getItem('darkMode') === 'enabled') {
            document.body.classList.add('dark');
        }

        // Thumbnail Gallery
        const thumbnails = document.querySelectorAll('.thumbnail');
        const mainImage = document.querySelector('#main-image');
        thumbnails.forEach(thumbnail => {
            thumbnail.addEventListener('click', function() {
                thumbnails.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                const newSrc = this.src.replace('100x100', '600x400');
                mainImage.src = newSrc;
            });
        });

        // Tabs
        const tabButtons = document.querySelectorAll('.tab-button');
        const tabContents = document.querySelectorAll('.tab-content');
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(tab => tab.classList.remove('active'));
                this.classList.add('active');
                document.getElementById(this.dataset.tab).classList.add('active');
            });
        });

        // Carousel
        const carouselContainer = document.querySelector('.carousel-container');
        const carouselItems = document.querySelectorAll('.carousel-item');
        const carouselButtons = document.querySelectorAll('.carousel-button');
        let currentIndex = 0;

        function updateCarousel() {
            if (!carouselContainer || carouselItems.length === 0) return;
            const itemWidth = carouselItems[0].offsetWidth + 8;
            carouselContainer.style.transform = `translateX(-${currentIndex * itemWidth}px)`;
        }

        if (carouselButtons.length > 0) {
            carouselButtons.forEach(button => {
                button.addEventListener('click', function() {
                    if (this.classList.contains('right')) {
                        currentIndex = Math.min(currentIndex + 1, carouselItems.length - 4);
                    } else {
                        currentIndex = Math.max(currentIndex - 1, 0);
                    }
                    updateCarousel();
                });
            });
            window.addEventListener('resize', updateCarousel);
            updateCarousel();
        }

        // Form Validation
        function validateForm() {
            let isValid = true;
            const phoneNumber = document.querySelector('#phone_number');
            const gameId = document.querySelector('#game_id');
            const quantity = document.querySelector('#quantity');

            // Reset error messages
            if (phoneNumber) document.getElementById('phone_number_error').classList.add('hidden');
            if (gameId) document.getElementById('game_id_error').classList.add('hidden');

            if (phoneNumber) {
                const phonePattern = /^08[0-9]{8,13}$/;
                if (!phonePattern.test(phoneNumber.value)) {
                    document.getElementById('phone_number_error').textContent = 'Nomor HP tidak valid.';
                    document.getElementById('phone_number_error').classList.remove('hidden');
                    isValid = false;
                }
            }

            if (gameId) {
                const game = document.querySelector('#game_name').value;
                let gameIdPattern;
                switch (game) {
                    case 'mobile_legends':
                        gameIdPattern = /^[0-9]{6,10}\([0-9]{4}\)$/;
                        break;
                    case 'free_fire':
                        gameIdPattern = /^[0-9]{9,12}$/;
                        break;
                    case 'pubg':
                        gameIdPattern = /^[0-9]{8,10}$/;
                        break;
                    case 'valorant':
                        gameIdPattern = /^[a-zA-Z0-9]+#[0-9]{4}$/;
                        break;
                    default:
                        isValid = false;
                }
                if (game && !gameIdPattern.test(gameId.value)) {
                    document.getElementById('game_id_error').textContent = 'ID Game tidak valid.';
                    document.getElementById('game_id_error').classList.remove('hidden');
                    isValid = false;
                }
            }

            if (quantity && (quantity.value < 1 || quantity.value > parseInt(quantity.max))) {
                Swal.fire({
                    icon: 'error',
                    title: 'Kesalahan',
                    text: 'Jumlah tidak valid.',
                    confirmButtonText: 'OK'
                });
                isValid = false;
            }

            return isValid;
        }

        // Phone Operator Detection
        const phoneNumberInput = document.querySelector('#phone_number');
        if (phoneNumberInput) {
            phoneNumberInput.addEventListener('input', function() {
                const prefixes = {
                    '0811': 'Telkomsel',
                    '0812': 'Telkomsel',
                    '0813': 'Telkomsel',
                    '0821': 'Telkomsel',
                    '0822': 'Indosat',
                    '0814': 'Indosat',
                    '0815': 'Indosat',
                    '0816': 'Indosat',
                    '0855': 'Indosat',
                    '0817': 'XL',
                    '0818': 'XL',
                    '0819': 'XL',
                    '0859': 'XL',
                    '0877': 'XL',
                    '0878': 'XL'
                };
                const prefix = this.value.substring(0, 4);
                document.getElementById('phone_operator').textContent = `Operator: ${prefixes[prefix] || 'Tidak dikenali'}`;
            });
        }

        // Game ID Placeholder
        const gameNameSelect = document.querySelector('#game_name');
        const gameIdInput = document.querySelector('#game_id');
        if (gameNameSelect && gameIdInput) {
            gameNameSelect.addEventListener('change', function() {
                const placeholders = {
                    'mobile_legends': 'Contoh: 12345678(1234)',
                    'free_fire': 'Contoh: 1234567890',
                    'pubg': 'Contoh: 512345678',
                    'valorant': 'Contoh: player#1234'
                };
                gameIdInput.placeholder = placeholders[this.value] || 'Pilih game terlebih dahulu';
                gameIdInput.value = '';
            });
        }

        // Add to Cart
        document.getElementById('addToCartButton').addEventListener('click', function(e) {
            e.preventDefault();
            if (!<?= $isLoggedIn ? 'true' : 'false' ?>) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Belum Login',
                    text: 'Silakan login untuk menambahkan produk ke keranjang!',
                    confirmButtonText: 'Login Sekarang',
                    showCancelButton: true,
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) window.location.href = '/auth/login';
                });
                return;
            }
            if (!validateForm()) return;

            const formData = new FormData(document.getElementById('addToCartForm'));
            fetch('/cart/add', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: 'Produk ditambahkan ke keranjang!',
                            timer: 1500,
                            showConfirmButton: false
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: data.message || 'Terjadi kesalahan.',
                            confirmButtonText: 'OK'
                        });
                        if (data.redirect) window.location.href = data.redirect;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Kesalahan',
                        text: 'Gagal menambahkan ke keranjang.',
                        confirmButtonText: 'OK'
                    });
                });
        });

        // Buy Now
        document.getElementById('buyNowButton').addEventListener('click', function(e) {
            e.preventDefault();
            if (!<?= $isLoggedIn ? 'true' : 'false' ?>) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Belum Login',
                    text: 'Silakan login untuk melanjutkan pembelian!',
                    confirmButtonText: 'Login Sekarang',
                    showCancelButton: true,
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) window.location.href = '/auth/login';
                });
                return;
            }
            if (!validateForm()) return;

            const formData = new FormData(document.getElementById('addToCartForm'));
            fetch('/cart/add', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(data => {
                    if (data.status === 'success') {
                        window.location.href = '/cart/checkout';
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: data.message || 'Terjadi kesalahan.',
                            confirmButtonText: 'OK'
                        });
                        if (data.redirect) window.location.href = data.redirect;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Kesalahan',
                        text: 'Gagal menuju checkout.',
                        confirmButtonText: 'OK'
                    });
                });
        });

        // Share Button
        document.getElementById('shareButton').addEventListener('click', function() {
            const url = window.location.href;
            if (navigator.clipboard) {
                navigator.clipboard.writeText(url).then(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Link Disalin!',
                        text: 'Bagikan link ini ke teman Anda.',
                        timer: 1500,
                        showConfirmButton: false
                    });
                }).catch(() => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal',
                        text: 'Tidak dapat menyalin link.',
                        confirmButtonText: 'OK'
                    });
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal',
                    text: 'Fitur ini tidak didukung di perangkat Anda.',
                    confirmButtonText: 'OK'
                });
            }
        });

        // Recently Viewed Products
        function updateRecentlyViewed() {
            const product = {
                id: '<?= esc($product['product_id']) ?>',
                name: '<?= esc($product['name']) ?>',
                price: '<?= number_format($product['price'], 2, ',', '.') ?>',
                image: '<?= esc($product['image_url']) ?: 'https://via.placeholder.com/300' ?>'
            };
            let recentlyViewed = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
            recentlyViewed = recentlyViewed.filter(item => item.id !== product.id);
            recentlyViewed.unshift(product);
            recentlyViewed = recentlyViewed.slice(0, 4);
            localStorage.setItem('recentlyViewed', JSON.stringify(recentlyViewed));

            const container = document.getElementById('recently-viewed');
            container.innerHTML = recentlyViewed.length > 0 ? '' : '<p class="text-4a5568 dark:text-d1d5db col-span-full">Belum ada produk yang dilihat.</p>';
            recentlyViewed.forEach(item => {
                container.innerHTML += `
                    <div class="recently-viewed-item card-3d">
                        <img src="${item.image}" alt="${item.name}" class="w-full h-48 object-cover rounded-t-lg">
                        <div class="p-3 bg-white dark:bg-4a5568 rounded-b-lg">
                            <h3 class="text-lg font-semibold text-2d3748 dark:text-e0e7ff truncate">${item.name}</h3>
                            <p class="text-4a90e2 dark:text-c6e8d7 font-medium mt-2">Rp ${item.price}</p>
                            <a href="/product/${item.id}" class="text-4a90e2 dark:text-c6e8d7 hover:underline mt-2 block">Lihat Detail</a>
                        </div>
                    </div>
                `;
            });
        }
        updateRecentlyViewed();

        // GSAP Animations
        gsap.from('.glass-card', {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power2.out',
            scrollTrigger: '.glass-card'
        });
        gsap.from('.carousel', {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power2.out',
            scrollTrigger: '.carousel'
        });
        gsap.from('#recently-viewed', {
            opacity: 0,
            y: 20,
            duration: 0.8,
            ease: 'power2.out',
            scrollTrigger: '#recently-viewed'
        });

        // Show Flash Messages
        <?php if (session()->getFlashdata('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?= session()->getFlashdata('error') ?>',
                timer: 2000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: '<?= session()->getFlashdata('success') ?>',
                timer: 2000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        <?php endif; ?>
    </script>
</body>

</html>