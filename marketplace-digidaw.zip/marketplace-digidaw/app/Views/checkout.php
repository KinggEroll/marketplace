<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .neon-effect {
            background: linear-gradient(90deg, #3b82f6, #22c55e);
            color: white;
            transition: all 0.3s;
        }

        .neon-effect:hover {
            box-shadow: 0 0 15px #3b82f6, 0 0 25px #22c55e;
            transform: scale(1.05);
        }

        .dark .glass-card {
            background: rgba(31, 41, 55, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .dark .text-gray-600 {
            color: #d1d5db;
        }

        .dropdown-menu {
            transform: translateY(-10px);
            transition: all 0.3s ease;
            opacity: 0;
            visibility: hidden;
        }

        .dropdown-menu.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
    </style>
</head>

<body class="bg-gray-100 dark:bg-gray-900 min-h-screen">
    <!-- Navbar -->
    <nav class="p-4 bg-white dark:bg-gray-800 shadow">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-2xl font-bold text-blue-500 dark:text-green-300 flex items-center">
                <span class="mr-2">🎮</span> DigiAw
            </a>
            <div class="flex items-center space-x-4">
                <?php if ($isLoggedIn): ?>
                    <div class="relative dropdown">
                        <button class="flex items-center text-gray-800 dark:text-gray-200 hover:text-blue-500">
                            <i class="fas fa-user-circle mr-2 text-xl"></i>
                            <span class="font-medium"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2"></i>
                        </button>
                        <div class="dropdown-menu absolute right-0 mt-2 w-48 bg-white dark:bg-gray-700 rounded-lg shadow-lg py-2 z-10">
                            <a href="/profile/edit" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white">Profil</a>
                            <a href="/auth/logout" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-red-500 hover:text-white">Logout</a>
                        </div>
                    </div>
                    <button onclick="toggleDarkMode()" class="text-gray-800 dark:text-gray-200">
                        <i class="fas fa-moon"></i>
                    </button>
                <?php else: ?>
                    <a href="/auth/login" class="text-gray-800 dark:text-gray-200 hover:text-blue-500">Login</a>
                    <a href="/auth/register" class="neon-effect px-4 py-2 rounded-full">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container mx-auto px-4 py-8 flex">
        <!-- Sidebar -->
        <aside class="w-64 hidden md:block" data-aos="fade-right">
            <div class="glass-card p-4">
                <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">Navigasi</h3>
                <ul class="space-y-2">
                    <li><a href="/dashboard" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-home mr-2"></i> Dashboard</a></li>
                    <li><a href="/orders" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-shopping-bag mr-2"></i> Pesanan</a></li>
                    <li><a href="/cart" class="block px-4 py-2 text-gray-800 dark:text-gray-200 bg-blue-500 text-white rounded flex items-center"><i class="fas fa-shopping-cart mr-2"></i> Keranjang</a></li>
                    <li><a href="/wishlist" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-heart mr-2"></i> Wishlist</a></li>
                    <li><a href="/transactions" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-wallet mr-2"></i> Riwayat Transaksi</a></li>
                    <li><a href="/notifications" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-bell mr-2"></i> Notifikasi <?php if ($stats['notification_count'] > 0): ?><span class="ml-2 bg-red-500 text-white text-xs rounded-full px-2"><?= $stats['notification_count'] ?></span><?php endif; ?></a></li>
                    <li><a href="/promos" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-tags mr-2"></i> Promo</a></li>
                    <li><a href="/referral" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-user-plus mr-2"></i> Referral</a></li>
                    <li><a href="/profile/edit" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white rounded flex items-center"><i class="fas fa-cog mr-2"></i> Pengaturan</a></li>
                </ul>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="flex-1 md:ml-8">
            <h2 class="text-3xl font-bold text-gray-800 dark:text-gray-200 mb-8" data-aos="fade-down">Checkout</h2>
            <div class="glass-card p-6" data-aos="fade-up">
                <?php if (session()->getFlashdata('error')): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('success')): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>

                <form action="/cart/complete" method="post" id="checkoutForm">
                    <?= csrf_field() ?>
                    <div class="mb-6">
                        <h3 class="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-4">Detail Pesanan</h3>
                        <table class="w-full text-left mb-4">
                            <thead>
                                <tr class="border-b dark:border-gray-600">
                                    <th class="py-2 px-4 text-gray-600 dark:text-gray-300">Produk</th>
                                    <th class="py-2 px-4 text-gray-600 dark:text-gray-300">Kategori</th>
                                    <th class="py-2 px-4 text-gray-600 dark:text-gray-300">Jumlah</th>
                                    <th class="py-2 px-4 text-gray-600 dark:text-gray-300">Harga</th>
                                    <th class="py-2 px-4 text-gray-600 dark:text-gray-300">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cartItems as $item): ?>
                                    <tr class="border-b dark:border-gray-600">
                                        <td class="py-2 px-4 text-gray-800 dark:text-gray-200"><?= esc($item['name'] ?? 'Tidak ada nama') ?></td>
                                        <td class="py-2 px-4 text-gray-800 dark:text-gray-200"><?= esc($item['category_name']) ?></td>
                                        <td class="py-2 px-4 text-gray-800 dark:text-gray-200"><?= esc($item['quantity'] ?? 0) ?></td>
                                        <td class="py-2 px-4 text-gray-800 dark:text-gray-200">Rp <?= number_format($item['price'] ?? 0, 0, ',', '.') ?></td>
                                        <td class="py-2 px-4 text-gray-800 dark:text-gray-200">Rp <?= number_format(($item['price'] ?? 0) * ($item['quantity'] ?? 0), 0, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Input Dinamis -->
                    <?php
                    $hasPulsa = false;
                    $hasGame = false;
                    $games = [];
                    foreach ($cartItems as $item) {
                        if ($item['category_name'] === 'Pulsa' || $item['category_name'] === 'Paket Data') {
                            $hasPulsa = true;
                        }
                        if ($item['category_name'] === 'Voucher Game') {
                            $hasGame = true;
                            preg_match('/Voucher (.*?)( \d+)/', $item['name'], $matches);
                            $gameName = $matches[1] ?? str_replace('Voucher ', '', $item['name']);
                            $games[$gameName] = $gameName;
                        }
                    }
                    ?>
                    <?php if ($hasPulsa): ?>
                        <div class="mb-4">
                            <label for="phone_number" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Nomor Telepon</label>
                            <input type="text" name="phone_number" id="phone_number" class="mt-1 p-2 border rounded w-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200" placeholder="Masukkan nomor telepon (contoh: 081234567890)" pattern="08[0-9]{8,11}" title="Nomor telepon harus diawali 08 dan 10-13 digit">
                        </div>
                    <?php endif; ?>
                    <?php if ($hasGame): ?>
                        <?php foreach ($games as $gameName): ?>
                            <div class="mb-4">
                                <label for="game_id_<?= esc(strtolower(str_replace(' ', '_', $gameName))) ?>" class="block text-sm font-medium text-gray-700 dark:text-gray-300">ID Game (<?= esc($gameName) ?>)</label>
                                <input type="text" name="game_id[<?= esc($gameName) ?>]" id="game_id_<?= esc(strtolower(str_replace(' ', '_', $gameName))) ?>" class="mt-1 p-2 border rounded w-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200" placeholder="Masukkan ID untuk <?= esc($gameName) ?>" required>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <!-- Promo Code -->
                    <div class="mb-4">
                        <label for="promo_code" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Kode Promo</label>
                        <input type="text" name="promo_code" id="promo_code" class="mt-1 p-2 border rounded w-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200" placeholder="Masukkan kode promo (contoh: DIGIDAW20)">
                    </div>

                    <!-- Payment Method -->
                    <div class="mb-4">
                        <label for="payment_method" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Metode Pembayaran</label>
                        <select name="payment_method" id="payment_method" class="mt-1 p-2 border rounded w-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200" required>
                            <option value="">Pilih metode pembayaran</option>
                            <option value="ewallet">E-Wallet (Saldo: Rp <?= number_format($user['balance'], 0, ',', '.') ?>)</option>
                            <option value="bank_transfer">Bank Transfer</option>
                            <option value="credit_card">Kartu Kredit</option>
                        </select>
                    </div>

                    <div class="text-right mt-6">
                        <h4 class="text-lg font-bold text-gray-800 dark:text-gray-200">Total: Rp <?= number_format($totalAmount, 0, ',', '.') ?></h4>
                        <button type="submit" class="neon-effect px-6 py-3 rounded mt-4">Selesaikan Pembayaran</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true
        });

        document.querySelector('.dropdown button')?.addEventListener('click', () => {
            document.querySelector('.dropdown-menu').classList.toggle('active');
        });

        function toggleDarkMode() {
            document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', document.body.classList.contains('dark') ? 'enabled' : 'disabled');
        }
        if (localStorage.getItem('darkMode') === 'enabled') document.body.classList.add('dark');

        document.getElementById('checkoutForm').addEventListener('submit', function(e) {
            const phoneInput = document.getElementById('phone_number');
            const gameInputs = document.querySelectorAll('input[name^="game_id"]');
            const paymentMethod = document.getElementById('payment_method');

            if (phoneInput && !phoneInput.value.match(/^08[0-9]{8,11}$/)) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Oops!',
                    text: 'Nomor telepon harus diawali 08 dan berisi 10-13 digit.',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }

            gameInputs.forEach(input => {
                if (!input.value.trim()) {
                    e.preventDefault();
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops!',
                        text: `ID game untuk ${input.placeholder.split('untuk ')[1]} harus diisi.`,
                        timer: 2000,
                        showConfirmButton: false
                    });
                }
            });

            if (!paymentMethod.value) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Oops!',
                    text: 'Pilih metode pembayaran terlebih dahulu.',
                    timer: 2000,
                    showConfirmButton: false
                });
            }
        });
    </script>
</body>

</html>