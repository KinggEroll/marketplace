<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            z-index: 10;
        }

        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px 0 rgba(31, 38, 135, 0.5);
        }

        .neon-effect {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .neon-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }

        .neon-effect:hover::before {
            left: 100%;
        }

        .neon-effect:hover {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(102, 126, 234, 0.6);
        }

        .chat-popup {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 400px;
            height: 600px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            transform: translateY(100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            display: flex;
            flex-direction: column;
        }

        .chat-popup.active {
            transform: translateY(0);
        }

        @media (max-width: 640px) {
            .chat-popup {
                width: 100%;
                height: 100%;
                bottom: 0;
                right: 0;
                border-radius: 0;
            }
        }

        .chat-header {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            padding: 15px 20px;
            border-radius: 20px 20px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .chat-conversations {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
        }

        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 15px;
            display: none;
        }

        .conversation-item {
            background: rgba(102, 126, 234, 0.1);
            border-radius: 12px;
            padding: 12px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(102, 126, 234, 0.2);
        }

        .conversation-item:hover {
            background: rgba(102, 126, 234, 0.2);
            transform: translateX(5px);
        }

        .conversation-item.unread {
            border-left: 4px solid #667eea;
            animation: pulse-border 2s infinite;
        }

        .message-item {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-end;
        }

        .message-item.own {
            justify-content: flex-end;
        }

        .message-bubble {
            max-width: 70%;
            padding: 10px 15px;
            border-radius: 18px;
            position: relative;
        }

        .message-bubble.own {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border-bottom-right-radius: 5px;
        }

        .message-bubble.other {
            background: rgba(102, 126, 234, 0.1);
            color: #333;
            border-bottom-left-radius: 5px;
        }

        .message-bubble img {
            max-width: 100%;
            border-radius: 10px;
            margin-top: 5px;
        }

        .chat-input {
            padding: 15px;
            border-top: 1px solid rgba(102, 126, 234, 0.2);
            display: none;
        }

        .chat-fab {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            transition: all 0.3s ease;
            z-index: 999;
            animation: pulse-glow 2s infinite;
        }

        @media (max-width: 640px) {
            .chat-fab {
                bottom: 20px;
                right: 20px;
            }
        }

        .chat-fab:hover {
            transform: scale(1.1);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.6);
        }

        .chat-fab.has-unread {
            animation: bounce 1s infinite;
        }

        .chat-fab .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: #ff4757;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }

        @keyframes pulse-glow {
            0% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            }

            50% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.8), 0 0 30px rgba(118, 75, 162, 0.6);
            }

            100% {
                box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
            }
        }

        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-10px);
            }

            60% {
                transform: translateY(-5px);
            }
        }

        @keyframes pulse-border {
            0% {
                border-left-color: #667eea;
            }

            50% {
                border-left-color: #764ba2;
            }

            100% {
                border-left-color: #667eea;
            }
        }

        .stat-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.3), rgba(255, 255, 255, 0.1));
            backdrop-filter: blur(15px);
            border-radius: 16px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            position: relative;
            z-index: 10;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .stat-card:hover::before {
            transform: scaleX(1);
        }

        .stat-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        }

        .floating-animation {
            animation: floating 3s ease-in-out infinite;
        }

        @keyframes floating {

            0%,
            100% {
                transform: translateY(0px);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .pulse-animation {
            animation: pulse-glow 2s infinite;
        }

        .notification-badge {
            background: linear-gradient(45deg, #ff6b6b, #ee5a24);
            animation: bounce 1s infinite;
        }

        .sidebar-nav {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            z-index: 10;
        }

        .nav-item {
            transition: all 0.3s ease;
            border-radius: 10px;
            margin: 4px 0;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .nav-item.active {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }

        .product-card {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            transition: all 0.3s ease;
            overflow: hidden;
            z-index: 10;
        }

        .product-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        .gradient-text {
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .loading-spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .dropdown-menu {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transform: translateY(-10px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0;
            visibility: hidden;
            z-index: 9999;
            position: absolute;
            right: 0;
            top: calc(100% + 15px);
            min-width: 200px;
            padding: 0.5rem;
        }

        .dropdown-menu.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .chart-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(15px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 20px;
            z-index: 10;
        }

        .notification-item {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            margin: 8px 0;
            z-index: 10;
        }

        .notification-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .notification-item.unread {
            border-left: 4px solid #667eea;
            animation: pulse-border 2s infinite;
        }

        .progress-bar {
            background: linear-gradient(90deg, #667eea, #764ba2);
            height: 6px;
            border-radius: 3px;
            transition: width 1s ease-in-out;
        }

        .toast-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 20px;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .toast-notification.show {
            transform: translateX(0);
        }

        .chart-wrapper {
            position: relative;
            height: 300px;
            width: 100%;
        }

        .chart-wrapper canvas {
            position: absolute;
            top: 0;
            left: 0;
        }

        .referral-card {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
            backdrop-filter: blur(15px);
            border-radius: 16px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            z-index: 10;
        }

        .referral-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #10b981, #059669);
            transform: scaleX(0);
            transition: transform 0.3s ease;
        }

        .referral-card:hover::before {
            transform: scaleX(1);
        }

        .referral-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
        }

        nav.glass-card {
            padding-right: 60px;
            z-index: 50;
        }
    </style>
</head>

<body>

    <nav class="p-4 glass-card mx-4 mt-4 relative" data-aos="fade-down">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-2xl font-bold gradient-text flex items-center floating-animation">
                <span class="mr-2 text-3xl">🎮</span> DigiAw
            </a>
            <div class="flex items-center space-x-6">
                <?php if ($isLoggedIn): ?>
                    <div class="relative">
                        <button class="text-white hover:text-yellow-300 transition-colors duration-300 pulse-animation">
                            <i class="fas fa-bell text-xl"></i>
                            <?php if ($stats['notification_count'] > 0): ?>
                                <span class="notification-badge absolute -top-2 -right-2 text-xs rounded-full px-2 py-1 text-white font-bold">
                                    <?= $stats['notification_count'] ?>
                                </span>
                            <?php endif; ?>
                        </button>
                    </div>
                    <div class="relative dropdown">
                        <button class="flex items-center text-white hover:text-yellow-300 transition-colors duration-300">
                            <div class="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center mr-2">
                                <i class="fas fa-user text-sm"></i>
                            </div>
                            <span class="font-medium"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2 transition-transform duration-300"></i>
                        </button>
                        <div class="dropdown-menu absolute right-0 mt-2 w-48 py-2 z-9999">
                            <a href="/profile/edit" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-user-edit mr-2"></i>Profil
                            </a>
                            <a href="/auth/logout" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-red-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="/auth/login" class="text-white hover:text-yellow-300 transition-colors duration-300">Login</a>
                    <a href="/auth/register" class="neon-effect px-6 py-2 rounded-full font-medium">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8 flex gap-8">
        <aside class="w-64 hidden md:block" data-aos="fade-right">
            <div class="sidebar-nav p-6">
                <h3 class="text-xl font-bold text-white mb-6 gradient-text">Navigasi</h3>
                <ul class="space-y-2">
                    <li><a href="/dashboard" class="nav-item active block px-4 py-3 text-white rounded-lg flex items-center font-medium"><i class="fas fa-home mr-3"></i> Dashboard</a></li>
                    <li><a href="/orders" class="nav-item block px-4 py-3 text-white hover:text-white rounded-lg flex items-center"><i class="fas fa-shopping-bag mr-3"></i> Pesanan</a></li>
                    <li><a href="/cart" class="nav-item block px-4 py-3 text-white hover:text-white rounded-lg flex items-center"><i class="fas fa-shopping-cart mr-3"></i> Keranjang <?php if ($stats['cart_count'] > 0): ?><span class="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1"><?= $stats['cart_count'] ?></span><?php endif; ?></a></li>
                    <li><a href="/wishlist" class="nav-item block px-4 py-3 text-white hover:text-white rounded-lg flex items-center"><i class="fas fa-heart mr-3"></i> Wishlist</a></li>
                    <li><a href="/transactions" class="nav-item block px-4 py-3 text-white hover:text-white rounded-lg flex items-center"><i class="fas fa-wallet mr-3"></i> Riwayat Transaksi</a></li>
                    <li><a href="/notifications" class="nav-item block px-4 py-3 text-white hover:text-white rounded-lg flex items-center"><i class="fas fa-bell mr-3"></i> Notifikasi <?php if ($stats['notification_count'] > 0): ?><span class="ml-auto notification-badge text-white text-xs rounded-full px-2 py-1"><?= $stats['notification_count'] ?></span><?php endif; ?></a></li>
                    <li><a href="/promos" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-tags mr-3"></i> Promo</a></li>
                    <li><a href="/referral" class="nav-item block px-4 py-3 text-white hover:text-white rounded-lg flex items-center"><i class="fas fa-user-plus mr-3"></i> Referral</a></li>
                    <li><a href="/profile/edit" class="nav-item block px-4 py-3 text-white hover:text-white rounded-lg flex items-center"><i class="fas fa-cog mr-3"></i> Pengaturan</a></li>
                </ul>
            </div>
        </aside>

        <div class="flex-1">
            <div class="glass-card p-8 mb-8" data-aos="fade-up">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-4xl font-bold text-white mb-2">Selamat Datang, <?= esc($username) ?>! 👋</h1>
                        <p class="text-white opacity-80 text-lg">Kelola akun dan pesanan Anda dengan mudah</p>
                    </div>
                    <div class="floating-animation">
                        <div class="w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                            <i class="fas fa-crown text-white text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Saldo Dompet</h3>
                            <p class="text-2xl font-bold text-white mt-2">Rp <?= number_format($stats['wallet_balance'], 0, ',', '.') ?></p>
                            <a href="/dashboard/deposit" class="neon-effect mt-4 inline-block px-4 py-2 rounded-lg text-sm">Isi Saldo</a>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                            <i class="fas fa-wallet text-white text-xl"></i>
                        </div>
                    </div>
                </div>

                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="200">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Total Pesanan</h3>
                            <p class="text-2xl font-bold text-white mt-2"><?= esc($stats['total_orders']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full flex items-center justify-center">
                            <i class="fas fa-shopping-bag text-white text-xl"></i>
                        </div>
                    </div>
                </div>

                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="300">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Pesanan Selesai</h3>
                            <p class="text-2xl font-bold text-white mt-2"><?= esc($stats['completed_orders']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                            <i class="fas fa-check-circle text-white text-xl"></i>
                        </div>
                    </div>
                </div>

                <div class="stat-card p-6" data-aos="fade-up" data-aos-delay="400">
                    <div class="flex items-center justify-between">
                        <div>
                            <h3 class="text-sm font-medium text-white opacity-80 uppercase tracking-wide">Total Pengeluaran</h3>
                            <p class="text-2xl font-bold text-white mt-2">Rp <?= number_format($stats['total_spent'], 0, ',', '.') ?></p>
                        </div>
                        <div class="w-12 h-12 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center">
                            <i class="fas fa-chart-line text-white text-xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div class="chart-container" data-aos="fade-right">
                    <h3 class="text-xl font-bold text-white mb-4">📊 Pengeluaran 6 Bulan Terakhir</h3>
                    <div class="chart-wrapper">
                        <canvas id="expenseChart"></canvas>
                    </div>
                </div>

                <div class="chart-container" data-aos="fade-left">
                    <h3 class="text-xl font-bold text-white mb-4">🎯 Kategori Pembelian Favorit</h3>
                    <div class="chart-wrapper">
                        <canvas id="categoryChart"></canvas>
                    </div>
                </div>
            </div>

            <div class="glass-card p-6 mb-8" data-aos="fade-up">
                <h3 class="text-2xl font-bold text-white mb-6 flex items-center">
                    <i class="fas fa-fire text-orange-500 mr-3"></i> Produk Trending
                </h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($trending_products as $index => $product): ?>
                        <div class="product-card p-4" data-aos="zoom-in" data-aos-delay="<?= $index * 100 ?>">
                            <div class="relative">
                                <img src="<?= esc($product['image_url']) ?>" alt="<?= esc($product['name']) ?>" class="w-full h-32 object-cover rounded-lg mb-3">
                                <div class="absolute top-2 right-2 bg-gradient-to-r from-orange-400 to-red-500 text-white text-xs px-2 py-1 rounded-full">
                                    🔥 Hot
                                </div>
                            </div>
                            <h4 class="text-white font-semibold mb-2"><?= esc($product['name']) ?></h4>
                            <p class="text-white opacity-70 text-sm mb-2"><?= esc($product['category_name']) ?></p>
                            <div class="flex justify-between items-center">
                                <span class="text-white font-bold">Rp <?= number_format($product['price'], 0, ',', '.') ?></span>
                                <button class="neon-effect px-3 py-1 rounded-lg text-sm">
                                    <i class="fas fa-cart-plus mr-1"></i>Beli
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div class="glass-card p-6" data-aos="fade-right">
                    <h3 class="text-xl font-bold text-white mb-4 flex items-center">
                        <i class="fas fa-user-circle mr-3 text-blue-400"></i>Status Profil
                    </h3>
                    <?php
                    $profileComplete = !empty($user['username']) && !empty($user['phone']) && !empty($user['address']);
                    $completionPercentage = 0;
                    if (!empty($user['username'])) $completionPercentage += 33;
                    if (!empty($user['phone'])) $completionPercentage += 33;
                    if (!empty($user['address'])) $completionPercentage += 34;
                    ?>
                    <div class="mb-4">
                        <div class="flex justify-between text-white mb-2">
                            <span>Kelengkapan Profil</span>
                            <span><?= $completionPercentage ?>%</span>
                        </div>
                        <div class="w-full bg-white bg-opacity-20 rounded-full h-2">
                            <div class="progress-bar h-2 rounded-full" style="width: <?= $completionPercentage ?>%"></div>
                        </div>
                    </div>
                    <div class="flex items-center space-x-4">
                        <div class="w-16 h-16 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-white text-2xl"></i>
                        </div>
                        <div>
                            <p class="text-white font-semibold text-lg"><?= esc($user['username']) ?></p>
                            <p class="text-white opacity-70"><?= esc($user['email']) ?></p>
                            <?php if (!$profileComplete): ?>
                                <a href="/profile/edit" class="text-yellow-300 hover:text-yellow-100 text-sm underline">
                                    Lengkapi profil untuk pengalaman terbaik
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="referral-card p-6" data-aos="fade-left">
                    <h3 class="text-xl font-bold text-white mb-4 flex items-center">
                        <i class="fas fa-users mr-3 text-green-400"></i>Program Referral
                    </h3>
                    <p class="text-white opacity-80 mb-4">Ajak teman dan dapatkan bonus menarik! 🎁</p>
                    <div class="mb-4">
                        <label class="block text-white opacity-70 text-sm mb-2">Kode Referral Anda:</label>
                        <div class="flex items-center space-x-2">
                            <input type="text" id="referralCode" value="<?= esc($user['referral_code'] ?? 'Belum ada kode') ?>" class="flex-1 p-3 rounded-lg bg-white bg-opacity-20 text-white placeholder-white placeholder-opacity-50 border border-white border-opacity-30" readonly>
                            <button onclick="copyReferralCode()" class="neon-effect px-4 py-3 rounded-lg <?= empty($user['referral_code']) ? 'opacity-50 cursor-not-allowed' : '' ?>" <?= empty($user['referral_code']) ? 'disabled' : '' ?>>
                                <i class="fas fa-copy"></i>
                            </button>
                            <?php if (empty($user['referral_code'])): ?>
                                <button onclick="generateReferralCode()" class="neon-effect px-4 py-3 rounded-lg">
                                    <i class="fas fa-plus"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="flex justify-between items-center">
                        <div class="text-center">
                            <p class="text-2xl font-bold text-white"><?= esc($stats['referred_count']) ?></p>
                            <p class="text-white opacity-70 text-sm">Teman Direfer</p>
                        </div>
                        <div class="text-center">
                            <p class="text-2xl font-bold text-green-400">Rp <?= number_format($stats['referral_earnings'] ?? 0, 0, ',', '.') ?></p>
                            <p class="text-white opacity-70 text-sm">Bonus Earned</p>
                        </div>
                    </div>
                    <a href="/referral" class="neon-effect inline-block mt-4 px-6 py-2 rounded-lg w-full text-center">
                        Kelola Referral
                    </a>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div class="glass-card p-6" data-aos="fade-up">
                    <h3 class="text-xl font-bold text-white mb-4 flex items-center">
                        <i class="fas fa-clock mr-3 text-blue-400"></i>Pesanan Terbaru
                    </h3>
                    <?php if (!empty($recent_orders)): ?>
                        <div class="space-y-3">
                            <?php foreach ($recent_orders as $order): ?>
                                <div class="notification-item p-4">
                                    <div class="flex items-center space-x-3">
                                        <img src="<?= esc($order['image_url']) ?>" alt="<?= esc($order['product_name']) ?>" class="w-12 h-12 object-cover rounded-lg">
                                        <div class="flex-1">
                                            <p class="text-white font-medium"><?= esc($order['product_name']) ?></p>
                                            <p class="text-white opacity-70 text-sm">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></p>
                                        </div>
                                        <span class="px-3 py-1 rounded-full text-xs font-medium <?= $order['status'] === 'completed' ? 'bg-green-500 text-white' : ($order['status'] === 'pending' ? 'bg-yellow-500 text-white' : 'bg-red-500 text-white') ?>">
                                            <?= ucfirst($order['status']) ?>
                                        </span>
                                        <?php if ($order['status'] === 'paid' || $order['status'] === 'delivered'): ?>
                                            <button onclick="startChat(<?= $order['order_id'] ?>)" class="text-blue-400 hover:text-blue-300 transition-colors">
                                                <i class="fas fa-comment text-lg"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <a href="/orders" class="neon-effect inline-block mt-4 px-6 py-2 rounded-lg">Lihat Semua Pesanan</a>
                    <?php else: ?>
                        <div class="text-center py-8">
                            <i class="fas fa-shopping-bag text-white opacity-50 text-4xl mb-4"></i>
                            <p class="text-white opacity-70">Belum ada pesanan</p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="glass-card p-6" data-aos="fade-up" data-aos-delay="100">
                    <h3 class="text-xl font-bold text-white mb-4 flex items-center">
                        <i class="fas fa-bell mr-3 text-yellow-400"></i>Notifikasi Terbaru
                    </h3>
                    <?php if (!empty($notifications)): ?>
                        <div class="space-y-3 max-h-64 overflow-y-auto">
                            <?php foreach ($notifications as $notif): ?>
                                <div class="notification-item <?= !$notif['is_read'] ? 'unread' : '' ?> p-4">
                                    <div class="flex items-start space-x-3">
                                        <div class="w-8 h-8 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full flex items-center justify-center flex-shrink-0">
                                            <i class="fas fa-<?= $notif['type'] === 'order' ? 'shopping-bag' : ($notif['type'] === 'promo' ? 'tags' : 'bell') ?> text-white text-sm"></i>
                                        </div>
                                        <div class="flex-1">
                                            <p class="text-white text-sm"><?= esc($notif['message']) ?></p>
                                            <p class="text-white opacity-50 text-xs mt-1"><?= date('d M Y, H:i', strtotime($notif['created_at'])) ?></p>
                                        </div>
                                        <?php if (!$notif['is_read']): ?>
                                            <div class="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <a href="/notifications" class="neon-effect inline-block mt-4 px-6 py-2 rounded-lg">Lihat Semua Notifikasi</a>
                    <?php else: ?>
                        <div class="text-center py-8">
                            <i class="fas fa-bell-slash text-white opacity-50 text-4xl mb-4"></i>
                            <p class="text-white opacity-70">Tidak ada notifikasi</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="glass-card p-6" data-aos="fade-up">
                <h3 class="text-xl font-bold text-white mb-6 flex items-center">
                    <i class="fas fa-rocket mr-3 text-purple-400"></i>Akses Cepat
                </h3>
                <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <a href="/cart" class="neon-effect p-4 rounded-lg text-center transition-all duration-300 hover:scale-105">
                        <i class="fas fa-shopping-cart text-2xl mb-2"></i>
                        <p class="font-medium">Keranjang</p>
                        <?php if ($stats['cart_count'] > 0): ?>
                            <span class="text-xs opacity-80"><?= $stats['cart_count'] ?> item</span>
                        <?php endif; ?>
                    </a>
                    <a href="/wishlist" class="neon-effect p-4 rounded-lg text-center transition-all duration-300 hover:scale-105">
                        <i class="fas fa-heart text-2xl mb-2"></i>
                        <p class="font-medium">Wishlist</p>
                        <span class="text-xs opacity-80"><?= $stats['wishlist_count'] ?> item</span>
                    </a>
                    <a href="/promos" class="neon-effect p-4 rounded-lg text-center transition-all duration-300 hover:scale-105">
                        <i class="fas fa-tags text-2xl mb-2"></i>
                        <p class="font-medium">Promo</p>
                        <span class="text-xs opacity-80"><?= $stats['active_promos'] ?> aktif</span>
                    </a>
                    <a href="/dashboard/deposit" class="neon-effect p-4 rounded-lg text-center transition-all duration-300 hover:scale-105">
                        <i class="fas fa-wallet text-2xl mb-2"></i>
                        <p class="font-medium">Deposit</p>
                        <span class="text-xs opacity-80">Isi Saldo</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true,
            offset: 100
        });

        let currentOrderId = null;
        let lastMessageId = 0;
        let chatPollingInterval = null;
        let unreadCount = 0;
        const MAX_RETRIES = 3;
        const RETRY_DELAY = 5000;

        const dropdownToggle = document.querySelector('.dropdown button');
        const dropdownMenu = document.querySelector('.dropdown-menu');
        const chevron = dropdownToggle?.querySelector('.fa-chevron-down');

        if (dropdownToggle && dropdownMenu && chevron) {
            dropdownToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                const isActive = dropdownMenu.classList.contains('active');
                dropdownMenu.classList.toggle('active');
                chevron.style.transform = isActive ? 'rotate(0)' : 'rotate(180deg)';
                if (isActive) {
                    dropdownMenu.style.zIndex = '10000';
                } else {
                    dropdownMenu.style.zIndex = '9999';
                }
            });

            document.addEventListener('click', (e) => {
                if (!dropdownToggle.contains(e.target) && !dropdownMenu.contains(e.target)) {
                    dropdownMenu.classList.remove('active');
                    chevron.style.transform = 'rotate(0)';
                }
            });
        }

        function toggleChat() {
            const chatPopup = document.getElementById('chatPopup');
            if (!chatPopup) return;

            const isActive = chatPopup.classList.contains('active');
            if (isActive) {
                chatPopup.classList.remove('active');
                if (chatPollingInterval) {
                    clearInterval(chatPollingInterval);
                    chatPollingInterval = null;
                }
            } else {
                chatPopup.classList.add('active');
                loadConversations();
                updateUnreadCount();
            }
        }

        function toggleChat() {
            const popup = document.getElementById('chatPopup');
            popup.classList.toggle('active');

            if (!popup.classList.contains('active')) {
                stopChatPolling();
                backToConversations();
            }
        }

        function loadConversations(attempt = 1) {
            const container = document.getElementById('chatConversations');
            if (!container) return;

            fetch('/chat', {
                    headers: {
                        'X-CSRF-Token': document.getElementById('csrf_token').value
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayConversations(data.conversations);
                    } else if (attempt < MAX_RETRIES) {
                        setTimeout(() => loadConversations(attempt + 1), RETRY_DELAY);
                    }
                })
                .catch(() => {
                    if (attempt < MAX_RETRIES) {
                        setTimeout(() => loadConversations(attempt + 1), RETRY_DELAY);
                    }
                });
        }

        function displayConversations(conversations) {
            const container = document.getElementById('chatConversations');
            if (!container) return;

            if (conversations.length === 0) {
                container.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fas fa-comment-slash text-gray-400 text-4xl mb-4"></i>
                        <p class="text-gray-600">Belum ada percakapan</p>
                        <p class="text-gray-500 text-sm mt-2">Mulai chat dengan penjual setelah melakukan pemesanan</p>
                    </div>
                `;
                return;
            }

            let html = '';
            conversations.forEach(conv => {
                const unreadBadge = conv.unread_count > 0 ? `<span class="bg-red-500 text-white text-xs rounded-full px-2 py-1">${conv.unread_count}</span>` : '';
                const unreadClass = conv.unread_count > 0 ? 'unread' : '';
                const onlineStatus = conv.seller_online ? '<span class="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></span>' : '';

                html += `
                    <div class="conversation-item ${unreadClass}" onclick="openChat(${conv.order_id})">
                        <div class="flex items-center space-x-3">
                            <div class="relative">
                                <img src="${conv.image_url || '/assets/images/default-product.jpg'}" alt="${conv.product_name}" class="w-12 h-12 object-cover rounded">
                                ${onlineStatus}
                            </div>
                            <div class="flex-1">
                                <div class="flex items-center justify-between">
                                    <h4 class="font-semibold text-white">${conv.seller_name || conv.buyer_name}</h4>
                                    ${unreadBadge}
                                </div>
                                <p class="text-sm text-white opacity-70">${conv.product_name}</p>
                                <p class="text-xs text-white opacity-50 truncate">${conv.last_message || 'Belum ada pesan'}</p>
                                <p class="text-xs text-white opacity-50">${formatDate(conv.last_message_time)}</p>
                            </div>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = html;
        }

        function openChat(orderId) {
            currentOrderId = orderId;

            const conversations = document.getElementById('chatConversations');
            const messages = document.getElementById('chatMessages');
            const input = document.getElementById('chatInput');
            if (!conversations || !messages || !input) return;

            conversations.style.display = 'none';
            messages.style.display = 'flex';
            input.style.display = 'block';

            document.getElementById('chatTitle').textContent = 'Chat';
            document.getElementById('chatSubtitle').innerHTML = '<button onclick="backToConversations()" class="text-sm hover:underline"><i class="fas fa-arrow-left mr-1"></i>Kembali</button>';

            loadMessages(orderId);
            if (!chatPollingInterval) {
                startChatPolling();
            }
        }

        function backToConversations() {
            currentOrderId = null;
            lastMessageId = 0;
            if (chatPollingInterval) {
                clearInterval(chatPollingInterval);
                chatPollingInterval = null;
            }

            const conversations = document.getElementById('chatConversations');
            const messages = document.getElementById('chatMessages');
            const input = document.getElementById('chatInput');
            if (!conversations || !messages || !input) return;

            conversations.style.display = 'block';
            messages.style.display = 'none';
            input.style.display = 'none';

            document.getElementById('chatTitle').textContent = 'Chat dengan Penjual';
            document.getElementById('chatSubtitle').textContent = 'Pilih percakapan';

            loadConversations();
        }

        function loadMessages(orderId, attempt = 1) {
            fetch(`/chat/getMessages/${orderId}`, {
                    headers: {
                        'X-CSRF-Token': document.getElementById('csrf_token').value
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayMessages(data.messages);
                        if (data.messages.length > 0) {
                            lastMessageId = Math.max(...data.messages.map(m => m.message_id));
                        } else {
                            document.getElementById('messagesList').innerHTML = '<p class="text-gray-600 text-center">Belum ada pesan dalam percakapan ini.</p>';
                        }
                    } else if (attempt < MAX_RETRIES) {
                        setTimeout(() => loadMessages(orderId, attempt + 1), RETRY_DELAY);
                    } else {
                        showToast('Error', 'Gagal memuat pesan: ' + data.message, 'error');
                    }
                })
                .catch(() => {
                    if (attempt < MAX_RETRIES) {
                        setTimeout(() => loadMessages(orderId, attempt + 1), RETRY_DELAY);
                    } else {
                        showToast('Error', 'Terjadi kesalahan server saat memuat pesan.', 'error');
                    }
                });
        }

        function displayMessages(messages) {
            const container = document.getElementById('messagesList');
            if (!container) return;
            const currentUserId = <?= session()->get('user_id') ?>;

            let html = '';
            messages.forEach(message => {
                const isOwn = message.sender_id == currentUserId;
                const messageClass = isOwn ? 'own' : 'other';
                const content = message.file_url ? `<img src="${message.file_url}" alt="Sent image">` : `<p>${message.message}</p>`;

                html += `
                    <div class="message-item ${messageClass}">
                        <div class="message-bubble ${messageClass}">
                            ${!isOwn ? `<p class="text-xs opacity-70 mb-1">${message.sender_name}</p>` : ''}
                            ${content}
                            <p class="text-xs opacity-70 mt-1">${formatTime(message.created_at)}</p>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = html;
            container.scrollTop = container.scrollHeight;
        }

        function sendMessage() {
            const input = document.getElementById('messageInput');
            if (!input || !currentOrderId) return;

            const message = input.value.trim();
            if (!message) return;

            const formData = new FormData();
            formData.append('order_id', currentOrderId);
            formData.append('message', message);
            formData.append('csrf_token', document.getElementById('csrf_token').value);

            fetch('/chat/sendMessage', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        input.value = '';
                        appendMessage(data.data);
                        lastMessageId = data.data.message_id;
                    }
                })
                .catch(() => {});
        }

        function sendFile() {
            const fileInput = document.getElementById('fileInput');
            if (!fileInput || !currentOrderId) return;

            const file = fileInput.files[0];
            if (!file) return;

            const formData = new FormData();
            formData.append('order_id', currentOrderId);
            formData.append('file', file);
            formData.append('csrf_token', document.getElementById('csrf_token').value);

            fetch('/chat/sendFile', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        fileInput.value = '';
                        appendMessage(data.data);
                        lastMessageId = data.data.message_id;
                    }
                })
                .catch(() => {});
        }

        function appendMessage(message) {
            const container = document.getElementById('messagesList');
            if (!container) return;
            const currentUserId = <?= session()->get('user_id') ?>;
            const isOwn = message.sender_id == currentUserId;
            const messageClass = isOwn ? 'own' : 'other';
            const content = message.file_url ? `<img src="${message.file_url}" alt="Sent image">` : `<p>${message.message}</p>`;

            const messageHtml = `
                <div class="message-item ${messageClass}">
                    <div class="message-bubble ${messageClass}">
                        ${!isOwn ? `<p class="text-xs opacity-70 mb-1">${message.sender_name}</p>` : ''}
                        ${content}
                        <p class="text-xs opacity-70 mt-1">${formatTime(message.created_at)}</p>
                    </div>
                </div>
            `;

            container.insertAdjacentHTML('beforeend', messageHtml);
            container.scrollTop = container.scrollHeight;
        }

        function startChatPolling() {
            if (chatPollingInterval || !currentOrderId) return;

            chatPollingInterval = setInterval(() => {
                pollNewMessages();
            }, 5000);
        }

        function stopChatPolling() {
            if (chatPollingInterval) {
                clearInterval(chatPollingInterval);
                chatPollingInterval = null;
            }
        }

        function pollNewMessages(attempt = 1) {
            if (!currentOrderId) return;

            fetch(`/chat/pollMessages?order_id=${currentOrderId}&last_message_id=${lastMessageId}`, {
                    headers: {
                        'X-CSRF-Token': document.getElementById('csrf_token').value
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.messages.length > 0) {
                        data.messages.forEach(message => {
                            appendMessage(message);
                            lastMessageId = Math.max(lastMessageId, message.message_id);
                        });
                        updateUnreadCount();
                    }
                })
                .catch(() => {
                    if (attempt < MAX_RETRIES) {
                        setTimeout(() => pollNewMessages(attempt + 1), RETRY_DELAY);
                    }
                });
        }

        function updateUnreadCount(attempt = 1) {
            fetch('/chat/getUnreadCount', {
                    headers: {
                        'X-CSRF-Token': document.getElementById('csrf_token').value
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        unreadCount = data.unread_count;
                        const badge = document.getElementById('chatBadge');
                        const fab = document.getElementById('chatFab');
                        if (badge && fab) {
                            if (unreadCount > 0) {
                                badge.textContent = unreadCount;
                                badge.style.display = 'flex';
                                fab.classList.add('has-unread');
                            } else {
                                badge.style.display = 'none';
                                fab.classList.remove('has-unread');
                            }
                        }
                    }
                })
                .catch(() => {
                    if (attempt < MAX_RETRIES) {
                        setTimeout(() => updateUnreadCount(attempt + 1), RETRY_DELAY);
                    }
                });
        }

        function startChat(orderId) {
            // if (!orderId) {
            //     showToast('Error', 'Order ID tidak valid.', 'error');
            //     return;
            // }
            // console.log('Starting chat with orderId:', orderId);
            // showLoading();
            // const formData = new FormData();
            // formData.append('order_id', orderId);
            // formData.append('csrf_token', document.getElementById('csrf_token').value);

            // fetch('/chat/startChatWithSeller', {
            //         method: 'POST',
            //         body: formData
            //     })
            //     .then(response => {
            //         if (!response.ok) throw new Error('Request failed: ' + response.status);
            //         return response.json();
            //     })
            //     .then(data => {
            //         hideLoading();
            //         console.log('Response:', data);
            //         if (data.success) {
            //             // Update CSRF token
            //             if (data.csrf_token) {
            //                 document.getElementById('csrf_token').value = data.csrf_token;
            //             }
            //             toggleChat();
            //             setTimeout(() => openChat(orderId), 500);
            //         } else {
            //             showToast('Oops!', data.message, 'error');
            //         }
            //     })
            //     .catch(error => {
            //         hideLoading();
            //         console.error('Error:', error);
            //         showToast('Error', 'Server error: ' + error.message, 'error');
            //     });
        }

        function copyReferralCode() {
            const code = document.getElementById('referralCode').value;
            if (code === 'Belum ada kode') {
                showToast('Oops!', 'Kode referral belum tersedia.', 'warning');
                return;
            }
            navigator.clipboard.writeText(code).then(() => {
                showToast('Berhasil!', 'Kode referral berhasil disalin.', 'success');
            });
        }

        function generateReferralCode() {
            const csrfToken = document.getElementById('csrf_token').value;
            fetch('/referral/generateCode', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-Token': csrfToken
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('referralCode').value = data.referral_code;
                        showToast('Berhasil!', data.message, 'success');
                        setTimeout(() => location.reload(), 1500);
                    }
                })
                .catch(() => {});
        }

        function formatDate(dateString) {
            if (!dateString) return '';
            const date = new Date(dateString);
            const now = new Date();
            const diff = now - date;
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));

            if (days === 0) {
                return formatTime(dateString);
            } else if (days === 1) {
                return 'Kemarin';
            } else if (days < 7) {
                return `${days} hari lalu`;
            } else {
                return date.toLocaleDateString('id-ID');
            }
        }

        function formatTime(dateString) {
            if (!dateString) return '';
            const date = new Date(dateString);
            return date.toLocaleTimeString('id-ID', {
                hour: '2-digit',
                minute: '2-digit'
            });
        }

        function showToast(title, message, type = 'success') {
            const toast = document.getElementById('toastTemplate').cloneNode(true);
            toast.id = 'toast-' + Date.now();
            toast.style.display = 'block';

            const icon = toast.querySelector('i');
            const iconContainer = toast.querySelector('.w-8');

            if (type === 'warning') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-exclamation text-white text-sm';
            } else if (type === 'error') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-times text-white text-sm';
            }

            toast.querySelector('#toastTitle').textContent = title;
            toast.querySelector('#toastMessage').textContent = message;

            document.body.appendChild(toast);

            setTimeout(() => toast.classList.add('show'), 100);
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        const chatFab = document.getElementById('chatFab');
        if (chatFab && !chatFab.dataset.listener) {
            chatFab.addEventListener('click', toggleChat);
            chatFab.dataset.listener = 'true';
        }

        const messageInput = document.getElementById('messageInput');
        if (messageInput && !messageInput.dataset.listener) {
            messageInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });
            messageInput.dataset.listener = 'true';
        }

        const fileInput = document.getElementById('fileInput');
        if (fileInput && !fileInput.dataset.listener) {
            fileInput.addEventListener('change', sendFile);
            fileInput.dataset.listener = 'true';
        }

        let expenseChart = null;
        let categoryChart = null;
        let chartsInitialized = false;

        function initializeCharts() {
            if (chartsInitialized) return;

            const timeoutId = setTimeout(() => {
                console.log('Chart initialization timed out');
            }, 5000);

            try {
                const expenseCtx = document.getElementById('expenseChart');
                if (expenseCtx && !expenseChart) {
                    expenseChart = new Chart(expenseCtx.getContext('2d'), {
                        type: 'line',
                        data: {
                            labels: <?= json_encode($month_labels) ?>,
                            datasets: [{
                                label: 'Pengeluaran',
                                data: <?= json_encode($monthly_expenses) ?>,
                                borderColor: 'rgba(102, 126, 234, 1)',
                                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                                borderWidth: 3,
                                fill: true,
                                tension: 0.4,
                                pointBackgroundColor: 'rgba(102, 126, 234, 1)',
                                pointBorderColor: '#fff',
                                pointBorderWidth: 2,
                                pointRadius: 6
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    labels: {
                                        color: 'white'
                                    }
                                }
                            },
                            scales: {
                                x: {
                                    ticks: {
                                        color: 'white'
                                    },
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.1)'
                                    }
                                },
                                y: {
                                    ticks: {
                                        color: 'white'
                                    },
                                    grid: {
                                        color: 'rgba(255, 255, 255, 0.1)'
                                    },
                                    beginAtZero: true
                                }
                            }
                        }
                    });
                }

                <?php if (!empty($category_stats)): ?>
                    const categoryCtx = document.getElementById('categoryChart');
                    if (categoryCtx && !categoryChart) {
                        categoryChart = new Chart(categoryCtx.getContext('2d'), {
                            type: 'doughnut',
                            data: {
                                labels: <?= json_encode(array_column($category_stats, 'category_name')) ?>,
                                datasets: [{
                                    data: <?= json_encode(array_column($category_stats, 'total_spent')) ?>,
                                    backgroundColor: [
                                        'rgba(102, 126, 234, 0.8)',
                                        'rgba(118, 75, 162, 0.8)',
                                        'rgba(255, 107, 107, 0.8)',
                                        'rgba(255, 193, 7, 0.8)',
                                        'rgba(40, 167, 69, 0.8)'
                                    ],
                                    borderColor: [
                                        'rgba(102, 126, 234, 1)',
                                        'rgba(118, 75, 162, 1)',
                                        'rgba(255, 107, 107, 1)',
                                        'rgba(255, 193, 7, 1)',
                                        'rgba(40, 167, 69, 1)'
                                    ],
                                    borderWidth: 2
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        position: 'bottom',
                                        labels: {
                                            color: 'white',
                                            padding: 20
                                        }
                                    }
                                }
                            }
                        });
                    }
                <?php endif; ?>

                chartsInitialized = true;
            } catch (e) {
                console.error('Chart initialization error:', e);
            } finally {
                clearTimeout(timeoutId);
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(initializeCharts, 500);
            updateUnreadCount();
            setInterval(updateUnreadCount, 30000);
        });

        window.addEventListener('load', function() {
            if (!chartsInitialized) {
                setTimeout(initializeCharts, 100);
            }
        });

        document.addEventListener('click', function(event) {
            const button = event.target.closest('button, .neon-effect');
            if (button && (button.type === 'submit' || button.href)) {
                const originalContent = button.innerHTML;
                button.innerHTML = '<div class="loading-spinner inline-block mr-2"></div>Loading...';
                button.disabled = true;

                setTimeout(() => {
                    button.innerHTML = originalContent;
                    button.disabled = false;
                }, 2000);
            }
        });

        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            });
        });

        let ticking = false;

        function updateParallax() {
            const scrolled = window.pageYOffset;
            const speed = scrolled * 0.5;
            document.body.style.backgroundPosition = `center ${speed}px`;
            ticking = false;
        }

        window.addEventListener('scroll', function() {
            if (!ticking) {
                requestAnimationFrame(updateParallax);
                ticking = true;
            }
        });
    </script>
</body>

</html>