<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Deposit Saldo') ?></title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 20px;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header-title h1 {
            color: #1e293b;
            font-size: 2.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .header-title .icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(135deg, #64748b, #475569);
            color: white;
            padding: 12px 24px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(100, 116, 139, 0.3);
        }

        .back-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(100, 116, 139, 0.4);
            color: white;
            text-decoration: none;
        }

        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
        }

        .form-section {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .form-header {
            margin-bottom: 30px;
            text-align: center;
        }

        .form-header h2 {
            color: #1e293b;
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .form-header p {
            color: #64748b;
            font-size: 1rem;
        }

        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            color: #374151;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 0.95rem;
        }

        .form-group .input-icon {
            position: relative;
        }

        .form-group .input-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #9ca3af;
            font-size: 1.1rem;
            z-index: 2;
        }

        .form-control {
            width: 100%;
            padding: 15px 15px 15px 45px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.9);
            transition: all 0.3s ease;
            color: #374151;
        }

        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
            background: white;
        }

        .form-control:hover {
            border-color: #d1d5db;
        }

        .amount-input {
            position: relative;
        }

        .currency-symbol {
            position: absolute;
            left: 45px;
            top: 50%;
            transform: translateY(-50%);
            color: #667eea;
            font-weight: 600;
            z-index: 2;
            pointer-events: none;
        }

        .amount-input input {
            padding-left: 75px;
        }

        .quick-amounts {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
            gap: 10px;
            margin-top: 15px;
        }

        .quick-amount {
            padding: 12px;
            border: 2px solid #e5e7eb;
            border-radius: 8px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.8);
            font-weight: 500;
            color: #374151;
        }

        .quick-amount:hover {
            border-color: #667eea;
            background: rgba(102, 126, 234, 0.1);
            color: #667eea;
        }

        .submit-btn {
            width: 100%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px;
            border: none;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
            margin-top: 20px;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 35px rgba(102, 126, 234, 0.4);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .sidebar {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .balance-card {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 30px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(102, 126, 234, 0.3);
        }

        .balance-card h3 {
            font-size: 1.2rem;
            margin-bottom: 15px;
            opacity: 0.9;
        }

        .balance-amount {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .balance-subtitle {
            opacity: 0.8;
            font-size: 0.95rem;
        }

        .info-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .info-card h3 {
            color: #1e293b;
            font-size: 1.3rem;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-icon {
            width: 40px;
            height: 40px;
            background: rgba(102, 126, 234, 0.1);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
        }

        .info-text {
            flex: 1;
        }

        .info-text h4 {
            color: #1e293b;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .info-text p {
            color: #64748b;
            font-size: 0.9rem;
        }

        .loading {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .loading-content {
            background: white;
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .spinner {
            width: 50px;
            height: 50px;
            border: 4px solid #f3f4f6;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            
            .sidebar {
                order: -1;
            }
        }

        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .header {
                padding: 20px;
            }
            
            .header-content {
                flex-direction: column;
                text-align: center;
            }
            
            .header-title h1 {
                font-size: 2rem;
            }
            
            .form-section {
                padding: 25px;
            }
            
            .balance-amount {
                font-size: 2rem;
            }
            
            .quick-amounts {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 480px) {
            .header-title h1 {
                font-size: 1.5rem;
            }
            
            .form-section {
                padding: 20px;
            }
            
            .balance-card {
                padding: 20px;
            }
            
            .balance-amount {
                font-size: 1.8rem;
            }
        }
    </style>
</head>

<body>
    <!-- Loading Overlay -->
    <div class="loading" id="loading">
        <div class="loading-content">
            <div class="spinner"></div>
            <p>Memproses deposit Anda...</p>
        </div>
    </div>

    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="header-content">
                <div class="header-title">
                    <div class="icon">
                        <i class="fas fa-wallet"></i>
                    </div>
                    <div>
                        <h1>Deposit Saldo</h1>
                        <p style="color: #64748b; margin-top: 5px;">Tambahkan saldo ke akun Anda dengan mudah dan aman</p>
                    </div>
                </div>
                <a href="/dashboard" class="back-btn">
                    <i class="fas fa-arrow-left"></i>
                    Kembali ke Dashboard
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Form Section -->
            <div class="form-section">
                <div class="form-header">
                    <h2>Form Deposit</h2>
                    <p>Isi form di bawah ini untuk melakukan deposit saldo</p>
                </div>

                <form id="depositForm" method="POST" action="/deposit/submit">
                    <?= csrf_field() ?>
                    
                    <!-- Payment Account -->
                    <div class="form-group">
                        <label for="payment_account">Akun Pembayaran</label>
                        <div class="input-icon">
                            <i class="fas fa-university"></i>
                            <select name="payment_account" id="payment_account" class="form-control" required>
                                <option value="">Pilih akun pembayaran</option>
                                <?php foreach ($payment_accounts as $account): ?>
                                    <option value="<?= esc($account['id']) ?>"><?= esc($account['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <!-- Amount -->
                    <div class="form-group">
                        <label for="amount">Jumlah Deposit</label>
                        <div class="input-icon amount-input">
                            <i class="fas fa-money-bill-wave"></i>
                            <span class="currency-symbol">Rp</span>
                            <input type="number" name="amount" id="amount" class="form-control" min="10000" required placeholder="Masukkan jumlah deposit">
                        </div>
                        
                        <!-- Quick Amount Buttons -->
                        <div class="quick-amounts">
                            <div class="quick-amount" onclick="setAmount(50000)">50K</div>
                            <div class="quick-amount" onclick="setAmount(100000)">100K</div>
                            <div class="quick-amount" onclick="setAmount(250000)">250K</div>
                            <div class="quick-amount" onclick="setAmount(500000)">500K</div>
                            <div class="quick-amount" onclick="setAmount(1000000)">1M</div>
                            <div class="quick-amount" onclick="setAmount(2000000)">2M</div>
                        </div>
                    </div>

                    <!-- Payment Method -->
                    <div class="form-group">
                        <label for="payment_method">Metode Pembayaran</label>
                        <div class="input-icon">
                            <i class="fas fa-credit-card"></i>
                            <select name="payment_method" id="payment_method" class="form-control" required>
                                <option value="">Pilih metode pembayaran</option>
                                <?php foreach ($payment_methods as $method): ?>
                                    <option value="<?= esc($method['id']) ?>"><?= esc($method['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="submit-btn">
                        <i class="fas fa-paper-plane"></i>&nbsp;&nbsp;
                        Kirim Deposit
                    </button>
                </form>
            </div>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Balance Card -->
                <div class="balance-card">
                    <div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 15px;">
                        <i class="fas fa-wallet" style="font-size: 1.5rem;"></i>
                        <h3 style="margin: 0;">Saldo Saat Ini</h3>
                    </div>
                    <div class="balance-amount">
                        <?= 'Rp ' . number_format($stats['wallet_balance'], 0, ',', '.') ?>
                    </div>
                    <p class="balance-subtitle">Total saldo tersedia di akun Anda</p>
                </div>

                <!-- Info Card -->
                <div class="info-card">
                    <h3>
                        <i class="fas fa-info-circle"></i>
                        Informasi Penting
                    </h3>
                    
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="info-text">
                            <h4>Proses Otomatis</h4>
                            <p>Deposit akan diproses dalam 1-5 menit</p>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <div class="info-text">
                            <h4>Keamanan Terjamin</h4>
                            <p>Transaksi Anda dilindungi enkripsi SSL</p>
                        </div>
                    </div>
                    
                    <div class="info-item">
                        <div class="info-icon">
                            <i class="fas fa-headset"></i>
                        </div>
                        <div class="info-text">
                            <h4>Dukungan 24/7</h4>
                            <p>Tim support siap membantu kapan saja</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Set quick amount
        function setAmount(amount) {
            document.getElementById('amount').value = amount;
            
            // Add visual feedback
            const quickAmounts = document.querySelectorAll('.quick-amount');
            quickAmounts.forEach(btn => btn.style.background = 'rgba(255, 255, 255, 0.8)');
            quickAmounts.forEach(btn => btn.style.color = '#374151');
            
            event.target.style.background = 'rgba(102, 126, 234, 0.2)';
            event.target.style.color = '#667eea';
        }

        // Format number input
        document.getElementById('amount').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value) {
                // Remove previous formatting and reformat
                let formatted = parseInt(value).toLocaleString('id-ID');
                // Note: We don't apply formatting to input value to avoid cursor issues
            }
        });

        // Form submission
        document.getElementById('depositForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Show loading
            document.getElementById('loading').style.display = 'flex';
            
            const formData = new FormData(this);
            
            fetch('/deposit/submit', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                // Hide loading
                document.getElementById('loading').style.display = 'none';
                
                if (data.success) {
                    // Show success message
                    showNotification('Deposit berhasil disubmit!', 'success');
                    setTimeout(() => {
                        window.location.href = data.redirect;
                    }, 1500);
                } else {
                    showNotification(data.message || 'Terjadi kesalahan', 'error');
                }
            })
            .catch(error => {
                // Hide loading
                document.getElementById('loading').style.display = 'none';
                console.error('Error:', error);
                showNotification('Terjadi kesalahan jaringan', 'error');
            });
        });

        // Notification function
        function showNotification(message, type) {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 10px;
                color: white;
                font-weight: 600;
                z-index: 10000;
                animation: slideIn 0.3s ease;
                max-width: 400px;
            `;
            
            if (type === 'success') {
                notification.style.background = 'linear-gradient(135deg, #10b981, #059669)';
                notification.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
            } else {
                notification.style.background = 'linear-gradient(135deg, #ef4444, #dc2626)';
                notification.innerHTML = `<i class="fas fa-exclamation-triangle"></i> ${message}`;
            }
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => {
                    document.body.removeChild(notification);
                }, 300);
            }, 3000);
        }

        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes slideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(100%); opacity: 0; }
            }
        `;
        document.head.appendChild(style);

        // Add subtle animations on page load
        window.addEventListener('load', function() {
            const elements = document.querySelectorAll('.form-section, .balance-card, .info-card');
            elements.forEach((el, index) => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    el.style.transition = 'all 0.6s ease';
                    el.style.opacity = '1';
                    el.style.transform = 'translateY(0)';
                }, index * 100);
            });
        });
    </script>
</body>

</html>