<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?= csrf_hash() ?>">
    <title><?= $title ?></title>
    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <!-- GSAP Animation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/Draggable.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Toastify -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <script src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Particles.js -->
    <script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
    
    <style>
        /* Base Styles */
        body {
            font-family: 'Inter', sans-serif;
            overflow-x: hidden;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 25%, #f093fb 50%, #f5576c 75%, #4facfe 100%);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            color: #2d3748;
        }

        @keyframes gradientShift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .dark body {
            background: linear-gradient(135deg, #1a202c 0%, #2d3748 25%, #4a5568 50%, #718096 75%, #a0aec0 100%);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            color: #e0e7ff;
        }

        /* Header Glassmorphism */
        header {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.1);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .dark header {
            background: rgba(26, 32, 44, 0.2);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Enhanced Hero Section */
        .hero-section {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: linear-gradient(135deg, 
                rgba(102, 126, 234, 0.9) 0%, 
                rgba(118, 75, 162, 0.9) 25%, 
                rgba(240, 147, 251, 0.9) 50%, 
                rgba(245, 87, 108, 0.9) 75%, 
                rgba(79, 172, 254, 0.9) 100%);
            background-size: 400% 400%;
            animation: gradientShift 20s ease infinite;
        }

        .hero-particles {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 1;
        }

        .hero-content {
            position: relative;
            z-index: 10;
            text-align: center;
            color: white;
            max-width: 1200px;
            padding: 0 20px;
        }

        .hero-title {
            font-size: clamp(3rem, 8vw, 6rem);
            font-weight: 900;
            margin-bottom: 1.5rem;
            background: linear-gradient(45deg, #ffffff, #f0f9ff, #e0e7ff, #c7d2fe);
            background-size: 400% 400%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: gradientText 8s ease infinite;
            text-shadow: 0 0 30px rgba(255, 255, 255, 0.5);
            line-height: 1.1;
        }

        @keyframes gradientText {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .hero-subtitle {
            font-size: clamp(1.2rem, 3vw, 1.8rem);
            font-weight: 500;
            margin-bottom: 2rem;
            opacity: 0.9;
            line-height: 1.6;
        }

        .hero-buttons {
            display: flex;
            gap: 1.5rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-bottom: 3rem;
        }

        .hero-btn {
            padding: 1rem 2.5rem;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .hero-btn-primary {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border: 2px solid transparent;
        }

        .hero-btn-primary:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.4);
            background: linear-gradient(45deg, #764ba2, #667eea);
        }

        .hero-btn-secondary {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.3);
            backdrop-filter: blur(10px);
        }

        .hero-btn-secondary:hover {
            transform: translateY(-3px) scale(1.05);
            background: rgba(255, 255, 255, 0.2);
            border-color: rgba(255, 255, 255, 0.5);
            box-shadow: 0 20px 40px rgba(255, 255, 255, 0.2);
        }

        .hero-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin-top: 4rem;
        }

        .hero-stat {
            text-align: center;
            padding: 1.5rem;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
        }

        .hero-stat:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.15);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .hero-stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: linear-gradient(45deg, #ffffff, #f0f9ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .hero-stat-label {
            font-size: 1rem;
            opacity: 0.9;
            font-weight: 500;
        }

        /* Floating Elements */
        .floating-element {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            animation: float 6s ease-in-out infinite;
        }

        .floating-element:nth-child(1) {
            width: 80px;
            height: 80px;
            top: 20%;
            left: 10%;
            animation-delay: 0s;
        }

        .floating-element:nth-child(2) {
            width: 120px;
            height: 120px;
            top: 60%;
            right: 15%;
            animation-delay: 2s;
        }

        .floating-element:nth-child(3) {
            width: 60px;
            height: 60px;
            top: 80%;
            left: 80%;
            animation-delay: 4s;
        }

        .floating-element:nth-child(4) {
            width: 100px;
            height: 100px;
            top: 30%;
            right: 30%;
            animation-delay: 1s;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }

        /* Gaming Icons */
        .gaming-icons {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: 2;
        }

        .gaming-icon {
            position: absolute;
            font-size: 2rem;
            color: rgba(255, 255, 255, 0.3);
            animation: floatIcon 8s ease-in-out infinite;
        }

        .gaming-icon:nth-child(1) { top: 15%; left: 15%; animation-delay: 0s; }
        .gaming-icon:nth-child(2) { top: 25%; right: 20%; animation-delay: 1s; }
        .gaming-icon:nth-child(3) { bottom: 30%; left: 20%; animation-delay: 2s; }
        .gaming-icon:nth-child(4) { bottom: 20%; right: 15%; animation-delay: 3s; }
        .gaming-icon:nth-child(5) { top: 50%; left: 5%; animation-delay: 4s; }
        .gaming-icon:nth-child(6) { top: 40%; right: 5%; animation-delay: 5s; }

        @keyframes floatIcon {
            0%, 100% { transform: translateY(0px) scale(1); opacity: 0.3; }
            50% { transform: translateY(-30px) scale(1.2); opacity: 0.6; }
        }

        /* Scroll Indicator */
        .scroll-indicator {
            position: absolute;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateX(-50%) translateY(0); }
            40% { transform: translateX(-50%) translateY(-10px); }
            60% { transform: translateX(-50%) translateY(-5px); }
        }

        /* Ensure DigiDaw text is visible */
        h1 {
            color: #ffffff;
            -webkit-text-fill-color: #ffffff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .dark h1 {
            color: #e0e7ff;
            -webkit-text-fill-color: #e0e7ff;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        /* Cart Badge */
        .cart-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border-radius: 50%;
            padding: 4px 8px;
            font-size: 12px;
            font-weight: 600;
            animation: pulse 2s infinite;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.2); }
            100% { transform: scale(1); }
        }

        /* Product Card Enhanced */
        .product-card {
            position: relative;
            border-radius: 20px;
            overflow: hidden;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .dark .product-card {
            background: rgba(74, 85, 104, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .product-card:hover {
            transform: translateY(-15px) scale(1.02);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
        }

        .product-card .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, rgba(102, 126, 234, 0.9), rgba(118, 75, 162, 0.9));
            opacity: 0;
            transition: all 0.4s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .product-card:hover .overlay {
            opacity: 1;
        }

        /* Enhanced Neon Effect */
        .neon-effect {
            position: relative;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 12px;
            padding: 12px 24px;
            font-weight: 600;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
            overflow: hidden;
        }

        .neon-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.6s;
        }

        .neon-effect:hover::before {
            left: 100%;
        }

        .neon-effect:hover {
            transform: translateY(-2px) scale(1.05);
            box-shadow: 0 15px 35px rgba(102, 126, 234, 0.5);
            background: linear-gradient(45deg, #764ba2, #667eea);
        }

        /* Dropdown Enhanced */
        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            min-width: 220px;
            z-index: 60;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .dark .dropdown-menu {
            background: rgba(74, 85, 104, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .dropdown-menu.open {
            display: block;
            animation: slideDown 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .dropdown-menu a {
            transition: all 0.3s ease;
            padding: 12px 20px;
            display: block;
        }

        .dropdown-menu a:hover {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            transform: translateX(5px);
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px) scale(0.95);
            }
            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        /* Enhanced Skeleton Loading */
        .skeleton {
            background: linear-gradient(90deg, 
                rgba(255, 255, 255, 0.1) 25%, 
                rgba(255, 255, 255, 0.3) 50%, 
                rgba(255, 255, 255, 0.1) 75%);
            background-size: 200% 100%;
            animation: skeleton-loading 1.5s infinite;
            border-radius: 12px;
        }

        @keyframes skeleton-loading {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }

        /* Scroll to Top Enhanced */
        .scroll-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            opacity: 0;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .scroll-to-top.visible {
            opacity: 1;
            transform: scale(1);
        }

        .scroll-to-top:hover {
            transform: scale(1.1) translateY(-5px);
            box-shadow: 0 20px 40px rgba(102, 126, 234, 0.5);
        }

        /* Enhanced Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(5px);
        }

        .modal-content {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 25px;
            padding: 30px;
            max-width: 600px;
            width: 90%;
            position: relative;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
        }

        .dark .modal-content {
            background: rgba(74, 85, 104, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Enhanced Filter Section */
        .filter-section {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            padding: 20px;
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .dark .filter-section {
            background: rgba(26, 32, 44, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Enhanced Footer */
        footer {
            background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
            color: #e0e7ff;
            padding: 60px 0 30px;
            position: relative;
            overflow: hidden;
        }

        footer::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, #667eea, #764ba2, #f093fb, #f5576c, #4facfe);
            background-size: 400% 400%;
            animation: gradientShift 8s ease infinite;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .hero-title {
                font-size: 3rem;
            }
            
            .hero-subtitle {
                font-size: 1.2rem;
            }
            
            .hero-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .hero-btn {
                width: 100%;
                max-width: 300px;
            }
            
            .hero-stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 1rem;
            }
        }

        @media (max-width: 480px) {
            .hero-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
    
    <script>
        // Initialize GSAP and Plugins
        gsap.registerPlugin(ScrollTrigger, Draggable);

        // Dark Mode Toggle
        function toggleDarkMode() {
            const isDark = document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', isDark ? 'enabled' : 'disabled');
            updateTheme(isDark);
            const darkModeBtn = document.querySelector('button[onclick="toggleDarkMode()"] i');
            if (isDark) {
                darkModeBtn.classList.remove('fa-moon');
                darkModeBtn.classList.add('fa-sun');
            } else {
                darkModeBtn.classList.remove('fa-sun');
                darkModeBtn.classList.add('fa-moon');
            }
            Toastify({
                text: isDark ? "🌙 Dark Mode Aktif!" : "☀️ Light Mode Aktif!",
                duration: 2000,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: isDark ? "linear-gradient(45deg, #667eea, #764ba2)" : "linear-gradient(45deg, #f093fb, #f5576c)",
                stopOnFocus: true,
                className: "enhanced-toast"
            }).showToast();
        }

        // Dropdown Toggle
        function toggleDropdown(event) {
            event.stopPropagation();
            const dropdownMenu = document.querySelector('.dropdown-menu');
            const isOpen = dropdownMenu.classList.toggle('open');
            
            if (isOpen) {
                gsap.fromTo(dropdownMenu, {
                    opacity: 0,
                    y: -20,
                    scale: 0.95
                }, {
                    opacity: 1,
                    y: 0,
                    scale: 1,
                    duration: 0.4,
                    ease: 'power3.out'
                });
            }
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', (event) => {
            const dropdown = document.querySelector('.dropdown');
            const dropdownMenu = document.querySelector('.dropdown-menu');
            if (!dropdown.contains(event.target) && dropdownMenu.classList.contains('open')) {
                dropdownMenu.classList.remove('open');
                gsap.to(dropdownMenu, {
                    opacity: 0,
                    y: -20,
                    scale: 0.95,
                    duration: 0.3,
                    ease: 'power2.in'
                });
            }
        });

        function updateTheme(isDark) {
            document.querySelectorAll('*').forEach(el => {
                if (el.classList.contains('dark')) el.classList.toggle('dark', isDark);
            });
        }

        if (localStorage.getItem('darkMode') === 'enabled') {
            document.body.classList.add('dark');
            updateTheme(true);
            const darkModeBtn = document.querySelector('button[onclick="toggleDarkMode()"] i');
            if (darkModeBtn) {
                darkModeBtn.classList.remove('fa-moon');
                darkModeBtn.classList.add('fa-sun');
            }
        }

        function addToCart(productId, quantity = 1) {
            if (!<?= $isLoggedIn ? 'true' : 'false' ?>) {
                Swal.fire({
                    icon: 'warning',
                    title: '🔐 Belum Login',
                    text: 'Silakan login untuk menambahkan produk ke keranjang!',
                    confirmButtonText: '🚀 Login Sekarang',
                    showCancelButton: true,
                    cancelButtonText: '❌ Batal',
                    customClass: {
                        confirmButton: 'neon-effect',
                        cancelButton: 'bg-gray-400 hover:bg-gray-500 text-white px-6 py-3 rounded-lg'
                    },
                    background: 'rgba(255, 255, 255, 0.95)',
                    backdrop: 'rgba(0, 0, 0, 0.7)'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = '/auth/login?redirect=' + encodeURIComponent(window.location.pathname);
                        Toastify({
                            text: "🔄 Diarahkan ke halaman login...",
                            duration: 2000,
                            close: true,
                            gravity: "top",
                            position: "right",
                            backgroundColor: "linear-gradient(45deg, #667eea, #764ba2)"
                        }).showToast();
                    }
                });
                return;
            }

            const button = document.querySelector(`button[data-product-id="${productId}"]`);
            button.disabled = true;
            button.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Menambahkan...';
            
            gsap.to(button, {
                scale: 1.1,
                duration: 0.3,
                yoyo: true,
                repeat: 1
            });

            fetch('/cart/add', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: new URLSearchParams({
                        '<?= csrf_token() ?>': '<?= csrf_hash() ?>',
                        'product_id': productId,
                        'quantity': quantity
                    })
                })
                .then(response => response.json())
                .then(data => {
                    button.disabled = false;
                    button.innerHTML = '<i class="fas fa-cart-plus mr-2"></i>Tambah ke Keranjang';

                    if (data.csrf_token) {
                        document.querySelector('meta[name="csrf-token"]').setAttribute('content', data.csrf_token);
                    }

                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: '🎉 Berhasil!',
                            text: 'Produk berhasil ditambahkan ke keranjang!',
                            timer: 2000,
                            showConfirmButton: false,
                            toast: true,
                            position: 'top-end',
                            background: 'rgba(255, 255, 255, 0.95)',
                            customClass: {
                                popup: 'enhanced-toast'
                            }
                        });
                        
                        Toastify({
                            text: "🛒 Item ditambahkan ke keranjang!",
                            duration: 2000,
                            close: true,
                            gravity: "top",
                            position: "right",
                            backgroundColor: "linear-gradient(45deg, #10b981, #059669)",
                            stopOnFocus: true
                        }).showToast();
                        
                        const cartBadge = document.getElementById('cart-count');
                        cartBadge.innerText = data.cartCount;
                        cartBadge.style.display = data.cartCount > 0 ? 'inline-block' : 'none';
                        animateCartBadge(cartBadge);
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: '❌ Gagal',
                            text: data.message,
                            confirmButtonText: 'OK',
                            customClass: {
                                confirmButton: 'neon-effect'
                            },
                            background: 'rgba(255, 255, 255, 0.95)'
                        });
                        if (data.redirect) window.location.href = data.redirect;
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: '⚠️ Kesalahan',
                        text: 'Terjadi kesalahan saat menambahkan ke keranjang.',
                        confirmButtonText: 'OK',
                        customClass: {
                            confirmButton: 'neon-effect'
                        },
                        background: 'rgba(255, 255, 255, 0.95)'
                    });
                    button.disabled = false;
                    button.innerHTML = '<i class="fas fa-cart-plus mr-2"></i>Tambah ke Keranjang';
                });
        }

        function animateCartBadge(badge) {
            gsap.fromTo(badge, {
                scale: 1.5,
                rotation: 360
            }, {
                scale: 1,
                rotation: 0,
                duration: 0.6,
                ease: 'elastic.out(1, 0.3)'
            });
        }

        // Add to Wishlist
        function addToWishlist(productId) {
            if (!<?= $isLoggedIn ? 'true' : 'false' ?>) {
                Swal.fire({
                    icon: 'warning',
                    title: '🔐 Belum Login',
                    text: 'Silakan login untuk menambahkan ke wishlist!',
                    confirmButtonText: '🚀 Login Sekarang',
                    showCancelButton: true,
                    cancelButtonText: '❌ Batal',
                    background: 'rgba(255, 255, 255, 0.95)'
                }).then((result) => {
                    if (result.isConfirmed) window.location.href = '/auth/login';
                });
                return;
            }

            const heart = document.querySelector(`button[data-wishlist-id="${productId}"] .fa-heart`);
            gsap.to(heart, {
                scale: 1.5,
                color: '#ef4444',
                duration: 0.3,
                yoyo: true,
                repeat: 1
            });
            
            Toastify({
                text: "💖 Produk ditambahkan ke wishlist!",
                duration: 2000,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: "linear-gradient(45deg, #ef4444, #dc2626)",
                stopOnFocus: true
            }).showToast();
        }

        // Search with Autocomplete
        let allProducts = <?= json_encode($products) ?>;

        function searchProducts(event) {
            const query = event.target.value.toLowerCase();
            const suggestions = document.getElementById('search-suggestions');
            suggestions.innerHTML = '';

            if (query.length > 0) {
                const filtered = allProducts.filter(product => 
                    product.name.toLowerCase().includes(query) || 
                    product.category_name.toLowerCase().includes(query)
                );
                
                filtered.slice(0, 5).forEach(product => {
                    const li = document.createElement('li');
                    li.className = 'px-4 py-3 hover:bg-gray-100 dark:hover:bg-gray-600 cursor-pointer transition-all duration-300 text-gray-800 dark:text-gray-200 border-b border-gray-200 dark:border-gray-600 last:border-b-0';
                    li.innerHTML = `
                        <div class="flex items-center space-x-3">
                            <i class="fas fa-search text-gray-400"></i>
                            <div>
                                <div class="font-medium">${product.name}</div>
                                <div class="text-sm text-gray-500">${product.category_name}</div>
                            </div>
                        </div>
                    `;
                    li.onclick = () => {
                        event.target.value = product.name;
                        suggestions.style.display = 'none';
                        filterProducts();
                    };
                    suggestions.appendChild(li);
                });
                suggestions.style.display = filtered.length > 0 ? 'block' : 'none';
            } else {
                suggestions.style.display = 'none';
            }
        }

        document.addEventListener('click', (e) => {
            const suggestions = document.getElementById('search-suggestions');
            if (!e.target.closest('#search-input')) suggestions.style.display = 'none';
        });

        // Filter Products with Enhanced Animation
        function filterProducts() {
            const query = document.getElementById('search-input').value.toLowerCase();
            const categoryId = document.getElementById('category-filter').value;
            const priceRange = document.getElementById('price-range').value;
            const sortBy = document.getElementById('sort-by').value;
            const productContainer = document.getElementById('product-container');

            // Show enhanced skeleton loading
            productContainer.innerHTML = '';
            const skeleton = document.createElement('div');
            skeleton.className = 'grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8';
            for (let i = 0; i < 8; i++) {
                skeleton.innerHTML += `
                    <div class="product-card bg-white dark:bg-gray-700 shadow-lg rounded-xl overflow-hidden">
                        <div class="w-full h-56 skeleton"></div>
                        <div class="p-6">
                            <div class="h-6 w-3/4 skeleton mb-3"></div>
                            <div class="h-4 w-1/2 skeleton mb-3"></div>
                            <div class="h-5 w-1/3 skeleton mb-4"></div>
                            <div class="h-10 w-full skeleton"></div>
                        </div>
                    </div>
                `;
            }
            productContainer.appendChild(skeleton);

            // Filter logic with enhanced animation
            setTimeout(() => {
                skeleton.remove();
                let filteredProducts = allProducts.filter(product => {
                    const nameMatch = query ? product.name.toLowerCase().includes(query) : true;
                    const categoryMatch = categoryId && categoryId !== 'all' ? 
                        String(product.category_id) === String(categoryId) : true;
                    
                    let priceMatch = true;
                    if (priceRange) {
                        const [minPrice, maxPrice] = priceRange.split('-').map(Number);
                        const price = Number(product.price);
                        priceMatch = maxPrice ? (price >= minPrice && price <= maxPrice) : (price >= minPrice);
                    }

                    return nameMatch && categoryMatch && priceMatch;
                });

                // Sort products
                if (sortBy === 'price-asc') {
                    filteredProducts.sort((a, b) => Number(a.price) - Number(b.price));
                } else if (sortBy === 'price-desc') {
                    filteredProducts.sort((a, b) => Number(b.price) - Number(a.price));
                }

                // Render filtered products with staggered animation
                productContainer.innerHTML = '';
                if (filteredProducts.length === 0) {
                    productContainer.innerHTML = `
                        <div class="col-span-full text-center py-20">
                            <i class="fas fa-search text-6xl text-gray-400 mb-4"></i>
                            <p class="text-xl text-gray-500 mb-2">Tidak ada produk yang ditemukan</p>
                            <p class="text-gray-400">Coba ubah filter pencarian Anda</p>
                        </div>
                    `;
                } else {
                    filteredProducts.forEach((product, index) => {
                        const card = document.createElement('div');
                        card.className = 'product-card bg-white dark:bg-gray-700 shadow-lg rounded-xl overflow-hidden transform opacity-0';
                        card.setAttribute('data-category-id', product.category_id);
                        card.setAttribute('data-price', product.price);
                        card.setAttribute('data-product-id', product.product_id);
                        card.innerHTML = `
                            <div class="relative group">
                                <div class="w-full h-56 bg-gradient-to-br from-gray-200 to-gray-300 dark:from-gray-600 dark:to-gray-700 flex items-center justify-center">
                                    <i class="fas fa-image text-4xl text-gray-400"></i>
                                </div>
                                ${Math.random() > 0.7 ? '<span class="absolute top-3 left-3 bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg">🔥 Hot</span>' : ''}
                                <div class="overlay">
                                    <button onclick="openQuickView(${product.product_id})" class="bg-white text-blue-600 px-6 py-3 rounded-full hover:bg-blue-600 hover:text-white transition-all duration-300 font-semibold shadow-lg transform hover:scale-105">
                                        <i class="fas fa-eye mr-2"></i>Quick View
                                    </button>
                                </div>
                            </div>
                            <div class="p-6">
                                <h3 class="product-name text-lg font-bold mb-2 text-gray-800 dark:text-gray-100 line-clamp-2">${product.name}</h3>
                                <p class="text-gray-600 dark:text-gray-400 mb-2 flex items-center">
                                    <i class="fas fa-tag mr-2"></i>${product.category_name}
                                </p>
                                <p class="text-2xl font-bold mb-4 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                                    Rp ${Number(product.price).toLocaleString('id-ID')}
                                </p>
                                <div class="space-y-3">
                                    ${<?= $isLoggedIn ? 'true' : 'false' ?> ? `
                                        <div class="flex items-center space-x-2">
                                            <input type="number" id="quantity-${product.product_id}" min="1" max="99" value="1" 
                                                class="w-16 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-center bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200">
                                            <button onclick="addToCart(${product.product_id}, document.getElementById('quantity-${product.product_id}').value)" 
                                                data-product-id="${product.product_id}" 
                                                class="neon-effect flex-1 text-sm">
                                                <i class="fas fa-cart-plus mr-2"></i>Tambah ke Keranjang
                                            </button>
                                        </div>
                                    ` : `
                                        <a href="/auth/login" class="block bg-gray-500 hover:bg-gray-600 text-white text-center px-4 py-3 rounded-lg transition-all duration-300 font-semibold">
                                            <i class="fas fa-sign-in-alt mr-2"></i>Login untuk Beli
                                        </a>
                                    `}
                                    <div class="flex space-x-2">
                                        <a href="/product/${product.product_id}" class="flex-1 text-center border-2 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white px-4 py-2 rounded-lg transition-all duration-300 font-semibold">
                                            <i class="fas fa-info-circle mr-2"></i>Detail
                                        </a>
                                        <button onclick="addToWishlist(${product.product_id})" data-wishlist-id="${product.product_id}" 
                                            class="px-4 py-2 border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-all duration-300">
                                            <i class="fas fa-heart"></i>
                                        </button>
                                    </div>
                                    <div class="flex items-center justify-between text-sm">
                                        <div class="flex items-center space-x-1 text-yellow-500">
                                            ${Array.from({length: 5}, (_, i) => `<i class="fas fa-star${i < Math.floor(Math.random() * 2) + 4 ? '' : ' text-gray-300'}"></i>`).join('')}
                                            <span class="ml-1 text-gray-600 dark:text-gray-400">(${Math.floor(Math.random() * 100) + 10})</span>
                                        </div>
                                        <span class="text-gray-500 dark:text-gray-400">
                                            <i class="fas fa-eye mr-1"></i>${Math.floor(Math.random() * 1000) + 100}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        `;
                        productContainer.appendChild(card);
                        
                        // Staggered animation
                        gsap.fromTo(card, {
                            opacity: 0,
                            y: 50,
                            scale: 0.9
                        }, {
                            opacity: 1,
                            y: 0,
                            scale: 1,
                            duration: 0.6,
                            delay: index * 0.1,
                            ease: 'power3.out'
                        });
                    });
                }
                
                Toastify({
                    text: filteredProducts.length > 0 ? 
                        `✨ Menampilkan ${filteredProducts.length} produk` : 
                        "❌ Tidak ada produk yang cocok!",
                    duration: 2000,
                    close: true,
                    gravity: "top",
                    position: "right",
                    backgroundColor: filteredProducts.length > 0 ? 
                        "linear-gradient(45deg, #10b981, #059669)" : 
                        "linear-gradient(45deg, #ef4444, #dc2626)"
                }).showToast();
            }, 800);
        }

        // Quick View Enhanced
        function openQuickView(productId) {
            const product = allProducts.find(p => p.product_id == productId);
            if (!product) return;

            document.getElementById('quick-view-name').innerText = product.name;
            document.getElementById('quick-view-category').innerText = product.category_name;
            document.getElementById('quick-view-price').innerText = `Rp ${Number(product.price).toLocaleString('id-ID')}`;
            document.getElementById('quick-view-modal').style.display = 'flex';
            
            gsap.fromTo('#quick-view-modal .modal-content', {
                y: -100,
                opacity: 0,
                scale: 0.8
            }, {
                y: 0,
                opacity: 1,
                scale: 1,
                duration: 0.6,
                ease: 'power3.out'
            });
        }

        function closeQuickView() {
            gsap.to('#quick-view-modal .modal-content', {
                y: -100,
                opacity: 0,
                scale: 0.8,
                duration: 0.4,
                ease: 'power3.in',
                onComplete: () => document.getElementById('quick-view-modal').style.display = 'none'
            });
        }

        // Enhanced Infinite Scroll
        let page = 1;
        let isLoading = false;
        let allProductsLoaded = false;

        window.addEventListener('scroll', () => {
            if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 500 && !isLoading && !allProductsLoaded) {
                loadMoreProducts();
            }
            const scrollToTop = document.querySelector('.scroll-to-top');
            scrollToTop.classList.toggle('visible', window.scrollY > 600);
        });

        function loadMoreProducts() {
            if (allProductsLoaded) return;
            isLoading = true;
            
            const productContainer = document.getElementById('product-container');
            const loadingIndicator = document.createElement('div');
            loadingIndicator.className = 'col-span-full text-center py-8';
            loadingIndicator.innerHTML = `
                <div class="inline-flex items-center space-x-3">
                    <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                    <span class="text-lg font-medium text-gray-600 dark:text-gray-400">Memuat produk lainnya...</span>
                </div>
            `;
            productContainer.appendChild(loadingIndicator);

            setTimeout(() => {
                loadingIndicator.remove();
                const newProducts = allProducts.slice(page * 8, (page + 1) * 8);
                
                if (newProducts.length === 0) {
                    allProductsLoaded = true;
                    const endMessage = document.createElement('div');
                    endMessage.className = 'col-span-full text-center py-12';
                    endMessage.innerHTML = `
                        <i class="fas fa-check-circle text-4xl text-green-500 mb-4"></i>
                        <p class="text-lg font-medium text-gray-600 dark:text-gray-400">Semua produk telah dimuat!</p>
                        <p class="text-gray-500 dark:text-gray-500">Terima kasih telah menjelajahi koleksi kami</p>
                    `;
                    productContainer.appendChild(endMessage);
                    
                    Toastify({
                        text: "✅ Semua produk telah dimuat!",
                        duration: 2000,
                        close: true,
                        gravity: "top",
                        position: "right",
                        backgroundColor: "linear-gradient(45deg, #10b981, #059669)"
                    }).showToast();
                    return;
                }

                // Add new products with animation
                newProducts.forEach((product, index) => {
                    const card = document.createElement('div');
                    card.className = 'product-card bg-white dark:bg-gray-700 shadow-lg rounded-xl overflow-hidden transform opacity-0';
                    card.setAttribute('data-category-id', product.category_id);
                    card.setAttribute('data-price', product.price);
                    card.setAttribute('data-product-id', product.product_id);
                    card.innerHTML = `
                        <div class="relative group">
                            <div class="w-full h-56 bg-gradient-to-br from-gray-200 to-gray-300 dark:from-gray-600 dark:to-gray-700 flex items-center justify-center">
                                <i class="fas fa-image text-4xl text-gray-400"></i>
                            </div>
                            ${Math.random() > 0.7 ? '<span class="absolute top-3 left-3 bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg">🔥 Hot</span>' : ''}
                            <div class="overlay">
                                <button onclick="openQuickView(${product.product_id})" class="bg-white text-blue-600 px-6 py-3 rounded-full hover:bg-blue-600 hover:text-white transition-all duration-300 font-semibold shadow-lg transform hover:scale-105">
                                    <i class="fas fa-eye mr-2"></i>Quick View
                                </button>
                            </div>
                        </div>
                        <div class="p-6">
                            <h3 class="product-name text-lg font-bold mb-2 text-gray-800 dark:text-gray-100 line-clamp-2">${product.name}</h3>
                            <p class="text-gray-600 dark:text-gray-400 mb-2 flex items-center">
                                <i class="fas fa-tag mr-2"></i>${product.category_name}
                            </p>
                            <p class="text-2xl font-bold mb-4 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                                Rp ${Number(product.price).toLocaleString('id-ID')}
                            </p>
                            <div class="space-y-3">
                                ${<?= $isLoggedIn ? 'true' : 'false' ?> ? `
                                    <div class="flex items-center space-x-2">
                                        <input type="number" id="quantity-${product.product_id}" min="1" max="99" value="1" 
                                            class="w-16 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-center bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200">
                                        <button onclick="addToCart(${product.product_id}, document.getElementById('quantity-${product.product_id}').value)" 
                                            data-product-id="${product.product_id}" 
                                            class="neon-effect flex-1 text-sm">
                                            <i class="fas fa-cart-plus mr-2"></i>Tambah ke Keranjang
                                        </button>
                                    </div>
                                ` : `
                                    <a href="/auth/login" class="block bg-gray-500 hover:bg-gray-600 text-white text-center px-4 py-3 rounded-lg transition-all duration-300 font-semibold">
                                        <i class="fas fa-sign-in-alt mr-2"></i>Login untuk Beli
                                    </a>
                                `}
                                <div class="flex space-x-2">
                                    <a href="/product/${product.product_id}" class="flex-1 text-center border-2 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white px-4 py-2 rounded-lg transition-all duration-300 font-semibold">
                                        <i class="fas fa-info-circle mr-2"></i>Detail
                                    </a>
                                    <button onclick="addToWishlist(${product.product_id})" data-wishlist-id="${product.product_id}" 
                                        class="px-4 py-2 border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-all duration-300">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <div class="flex items-center justify-between text-sm">
                                    <div class="flex items-center space-x-1 text-yellow-500">
                                        ${Array.from({length: 5}, (_, i) => `<i class="fas fa-star${i < Math.floor(Math.random() * 2) + 4 ? '' : ' text-gray-300'}"></i>`).join('')}
                                        <span class="ml-1 text-gray-600 dark:text-gray-400">(${Math.floor(Math.random() * 100) + 10})</span>
                                    </div>
                                    <span class="text-gray-500 dark:text-gray-400">
                                        <i class="fas fa-eye mr-1"></i>${Math.floor(Math.random() * 1000) + 100}
                                    </span>
                                </div>
                            </div>
                        </div>
                    `;
                    productContainer.appendChild(card);
                    
                    gsap.fromTo(card, {
                        opacity: 0,
                        y: 50,
                        scale: 0.9
                    }, {
                        opacity: 1,
                        y: 0,
                        scale: 1,
                        duration: 0.6,
                        delay: index * 0.1,
                        ease: 'power3.out'
                    });
                });
                
                page++;
                isLoading = false;
                
                Toastify({
                    text: `📦 Memuat ${newProducts.length} produk baru!`,
                    duration: 2000,
                    close: true,
                    gravity: "top",
                    position: "right",
                    backgroundColor: "linear-gradient(45deg, #667eea, #764ba2)"
                }).showToast();
            }, 1500);
        }

        // Enhanced Scroll to Top
        function scrollToTop() {
            gsap.to(window, {
                scrollTo: 0,
                duration: 1.2,
                ease: 'power2.inOut'
            });
            
            Toastify({
                text: "🚀 Kembali ke atas!",
                duration: 1500,
                close: true,
                gravity: "top",
                position: "right",
                backgroundColor: "linear-gradient(45deg, #667eea, #764ba2)"
            }).showToast();
        }

        // Enhanced GSAP Animations
        document.addEventListener('DOMContentLoaded', () => {
            // Header animation
            gsap.fromTo('header', {
                y: -100,
                opacity: 0
            }, {
                y: 0,
                opacity: 1,
                duration: 1,
                ease: 'power3.out'
            });

            // Hero section animations
            const heroTimeline = gsap.timeline();
            
            heroTimeline
                .fromTo('.hero-title', {
                    y: 100,
                    opacity: 0,
                    scale: 0.8
                }, {
                    y: 0,
                    opacity: 1,
                    scale: 1,
                    duration: 1.2,
                    ease: 'power3.out'
                })
                .fromTo('.hero-subtitle', {
                    y: 50,
                    opacity: 0
                }, {
                    y: 0,
                    opacity: 1,
                    duration: 0.8,
                    ease: 'power2.out'
                }, '-=0.6')
                .fromTo('.hero-buttons', {
                    y: 30,
                    opacity: 0
                }, {
                    y: 0,
                    opacity: 1,
                    duration: 0.8,
                    ease: 'power2.out'
                }, '-=0.4')
                .fromTo('.hero-stats', {
                    y: 50,
                    opacity: 0
                }, {
                    y: 0,
                    opacity: 1,
                    duration: 0.8,
                    ease: 'power2.out'
                }, '-=0.2');

            // Floating elements animation
            gsap.to('.floating-element', {
                y: -20,
                rotation: 360,
                duration: 6,
                ease: 'power1.inOut',
                repeat: -1,
                yoyo: true,
                stagger: 0.5
            });

            // Gaming icons animation
            gsap.to('.gaming-icon', {
                y: -30,
                scale: 1.2,
                opacity: 0.6,
                duration: 8,
                ease: 'power1.inOut',
                repeat: -1,
                yoyo: true,
                stagger: 1
            });

            // Products section scroll trigger
            ScrollTrigger.create({
                trigger: '#products',
                start: 'top 80%',
                onEnter: () => {
                    gsap.fromTo('#product-container .product-card', {
                        opacity: 0,
                        y: 50,
                        scale: 0.9
                    }, {
                        opacity: 1,
                        y: 0,
                        scale: 1,
                        stagger: 0.1,
                        duration: 0.8,
                        ease: 'power3.out'
                    });
                }
            });

            // Initialize particles
            if (typeof particlesJS !== 'undefined') {
                particlesJS('hero-particles', {
                    particles: {
                        number: {
                            value: 80,
                            density: {
                                enable: true,
                                value_area: 800
                            }
                        },
                        color: {
                            value: '#ffffff'
                        },
                        shape: {
                            type: 'circle'
                        },
                        opacity: {
                            value: 0.3,
                            random: true
                        },
                        size: {
                            value: 3,
                            random: true
                        },
                        line_linked: {
                            enable: true,
                            distance: 150,
                            color: '#ffffff',
                            opacity: 0.2,
                            width: 1
                        },
                        move: {
                            enable: true,
                            speed: 2,
                            direction: 'none',
                            random: true,
                            straight: false,
                            out_mode: 'out',
                            bounce: false
                        }
                    },
                    interactivity: {
                        detect_on: 'canvas',
                        events: {
                            onhover: {
                                enable: true,
                                mode: 'repulse'
                            },
                            onclick: {
                                enable: true,
                                mode: 'push'
                            }
                        },
                        modes: {
                            repulse: {
                                distance: 100,
                                duration: 0.4
                            },
                            push: {
                                particles_nb: 4
                            }
                        }
                    },
                    retina_detect: true
                });
            }

            // Initialize filter
            filterProducts();
        });

        // Counter animation for hero stats
        function animateCounter(element, target) {
            gsap.to(element, {
                innerText: target,
                duration: 2,
                ease: 'power2.out',
                snap: { innerText: 1 },
                onUpdate: function() {
                    element.innerText = Math.ceil(element.innerText).toLocaleString('id-ID');
                }
            });
        }

        // Initialize counters when hero section is visible
        ScrollTrigger.create({
            trigger: '.hero-stats',
            start: 'top 80%',
            onEnter: () => {
                document.querySelectorAll('.hero-stat-number').forEach((counter, index) => {
                    const targets = [<?= count($products) + 150 ?>, <?= rand(5000, 10000) ?>, <?= rand(500, 1000) ?>, <?= rand(50, 100) ?>];
                    animateCounter(counter, targets[index] || 100);
                });
            }
        });
    </script>
</head>

<body class="relative">
    <header class="text-gray-800 dark:text-gray-200 p-4 shadow-lg sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center">
            <!-- Left Section: Logo and Sidebar Toggle -->
            <div class="flex items-center space-x-4">
                <a href="/" class="text-3xl font-black flex items-center group">
                    <span class="text-4xl mr-3 group-hover:animate-bounce">🎮</span> 
                    <span class="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">DigiDaw</span>
                </a>
                <button onclick="toggleSidebar()" class="md:hidden text-2xl hover:scale-110 transition-transform">
                    <i class="fas fa-bars"></i>
                </button>
            </div>

            <!-- Right Section: Search, Dark Mode, Cart, and User Dropdown -->
            <div class="flex items-center space-x-6">
                <!-- Enhanced Search Bar -->
                <div class="relative">
                    <input type="text" id="search-input" onkeyup="searchProducts(event)" 
                        placeholder="🔍 Cari produk, kategori..." 
                        class="px-6 py-3 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-gray-800 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-lg w-64 transition-all duration-300">
                    <ul id="search-suggestions" class="absolute top-full left-0 w-full bg-white/95 dark:bg-gray-800/95 backdrop-blur-md shadow-xl rounded-b-2xl mt-2 hidden max-h-60 overflow-y-auto z-50 border border-white/20"></ul>
                </div>

                <!-- Enhanced Dark Mode Toggle -->
                <button onclick="toggleDarkMode()" class="text-2xl hover:scale-110 transition-all duration-300 p-2 rounded-full hover:bg-white/10">
                    <i class="fas fa-moon"></i>
                </button>

                <!-- Enhanced Cart Icon -->
                <a href="/cart/checkout" class="relative group">
                    <i class="fas fa-shopping-cart text-2xl group-hover:scale-110 transition-transform"></i>
                    <span id="cart-count" class="cart-badge" style="display: <?= $cartCount > 0 ? 'inline-block' : 'none' ?>;"><?= $cartCount ?></span>
                </a>

                <!-- Enhanced User Dropdown -->
                <div class="relative dropdown">
                    <?php if ($isLoggedIn): ?>
                        <button onclick="toggleDropdown(event)" class="flex items-center space-x-3 text-gray-800 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 transition-all duration-300 group">
                            <div class="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold shadow-lg group-hover:scale-110 transition-transform">
                                <?= strtoupper(substr($username, 0, 1)) ?>
                            </div>
                            <div class="hidden md:block text-left">
                                <div class="font-bold"><?= esc($username) ?></div>
                                <div class="text-sm opacity-75"><?= ucfirst($role) ?></div>
                            </div>
                            <i class="fas fa-chevron-down text-sm group-hover:rotate-180 transition-transform"></i>
                        </button>
                        <div class="dropdown-menu right-0 mt-3 w-64 py-2">
                            <div class="px-6 py-4 border-b border-gray-200 dark:border-gray-600">
                                <div class="font-bold text-gray-800 dark:text-gray-200"><?= esc($username) ?></div>
                                <div class="text-sm text-gray-600 dark:text-gray-400"><?= ucfirst($role) ?></div>
                            </div>
                            <?php if ($role === 'pembeli'): ?>
                            <?php endif; ?>
                            <a href="/dashboard" class="flex items-center px-6 py-3 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-tachometer-alt mr-3"></i>Dashboard
                            </a>
                            <div class="border-t border-gray-200 dark:border-gray-600 mt-2 pt-2">
                                <a href="/auth/logout" class="flex items-center px-6 py-3 text-red-600 hover:bg-red-500 hover:text-white transition-all duration-300">
                                    <i class="fas fa-sign-out-alt mr-3"></i>Logout
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="flex items-center space-x-4">
                            <a href="/auth/login" class="text-gray-800 dark:text-gray-200 hover:text-blue-600 dark:hover:text-blue-400 font-semibold transition-all duration-300">
                                <i class="fas fa-sign-in-alt mr-2"></i>Masuk
                            </a>
                            <a href="/auth/register" class="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-purple-600 hover:to-blue-500 text-white px-6 py-3 rounded-full font-bold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                                <i class="fas fa-user-plus mr-2"></i>Daftar
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <!-- Enhanced Hero Section -->
    <section class="hero-section">
        <!-- Particles Background -->
        <div id="hero-particles" class="hero-particles"></div>
        
        <!-- Floating Elements -->
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        <div class="floating-element"></div>
        
        <!-- Gaming Icons -->
        <div class="gaming-icons">
            <i class="gaming-icon fas fa-gamepad"></i>
            <i class="gaming-icon fas fa-trophy"></i>
            <i class="gaming-icon fas fa-coins"></i>
            <i class="gaming-icon fas fa-gem"></i>
            <i class="gaming-icon fas fa-fire"></i>
            <i class="gaming-icon fas fa-star"></i>
        </div>

        <!-- Hero Content -->
        <div class="hero-content">
            <h1 class="hero-title">
                Selamat Datang di<br>
                <span class="block">DigiDaw</span>
            </h1>
            <p class="hero-subtitle">
                🎮 Marketplace terpercaya untuk semua kebutuhan gaming digital Anda<br>
                Temukan item premium, voucher game, dan top-up terbaik dengan harga terjangkau
            </p>
            
            <div class="hero-buttons">
                <a href="#products" class="hero-btn hero-btn-primary">
                    <i class="fas fa-shopping-cart"></i>
                    Belanja Sekarang
                </a>
                <a href="#about" class="hero-btn hero-btn-secondary">
                    <i class="fas fa-info-circle"></i>
                    Pelajari Lebih Lanjut
                </a>
            </div>

            <!-- Hero Stats -->
            <div class="hero-stats">
                <div class="hero-stat">
                    <div class="hero-stat-number">0</div>
                    <div class="hero-stat-label">Produk Tersedia</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number">0</div>
                    <div class="hero-stat-label">Pengguna Aktif</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number">0</div>
                    <div class="hero-stat-label">Transaksi Sukses</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-number">0</div>
                    <div class="hero-stat-label">Rating Kepuasan</div>
                </div>
            </div>
        </div>

        <!-- Scroll Indicator -->
        <div class="scroll-indicator">
            <div class="text-white text-center">
                <div class="text-sm mb-2 opacity-75">Scroll untuk melihat produk</div>
                <i class="fas fa-chevron-down text-2xl"></i>
            </div>
        </div>
    </section>

    <!-- Notifikasi -->
    <div class="container mx-auto mt-4">
        <?php if (session()->getFlashdata('error')): ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: '❌ Error',
                    text: '<?= session()->getFlashdata('error') ?>',
                    timer: 3000,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end',
                    background: 'rgba(255, 255, 255, 0.95)',
                    customClass: {
                        popup: 'shadow-xl'
                    }
                });
            </script>
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: '✅ Berhasil',
                    text: '<?= session()->getFlashdata('success') ?>',
                    timer: 3000,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end',
                    background: 'rgba(255, 255, 255, 0.95)',
                    customClass: {
                        popup: 'shadow-xl'
                    }
                });
            </script>
        <?php endif; ?>
    </div>

    <!-- Enhanced Filter Section -->
    <section class="container mx-auto mt-12 px-4">
        <div class="filter-section">
            <div class="flex flex-wrap items-center justify-between gap-4">
                <h3 class="text-xl font-bold text-gray-800 dark:text-gray-200 flex items-center">
                    <i class="fas fa-filter mr-3"></i>Filter Produk
                </h3>
                
                <div class="flex flex-wrap items-center gap-4">
                    <!-- Filter Kategori -->
                    <div class="flex items-center space-x-2">
                        <label for="category-filter" class="text-gray-700 dark:text-gray-300 font-medium">
                            <i class="fas fa-tags mr-2"></i>Kategori:
                        </label>
                        <select id="category-filter" onchange="filterProducts()" 
                            class="px-4 py-2 rounded-lg bg-white/20 backdrop-blur-md border border-white/30 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="all">Semua Kategori</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['category_id'] ?>"><?= esc($category['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Filter Harga -->
                    <div class="flex items-center space-x-2">
                        <label for="price-range" class="text-gray-700 dark:text-gray-300 font-medium">
                            <i class="fas fa-money-bill-wave mr-2"></i>Harga:
                        </label>
                        <select id="price-range" onchange="filterProducts()" 
                            class="px-4 py-2 rounded-lg bg-white/20 backdrop-blur-md border border-white/30 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Semua Harga</option>
                            <option value="0-25000">< Rp 25.000</option>
                            <option value="25000-75000">Rp 25.000 - Rp 75.000</option>
                            <option value="75000-150000">Rp 75.000 - Rp 150.000</option>
                            <option value="150000-300000">Rp 150.000 - Rp 300.000</option>
                            <option value="300000">> Rp 300.000</option>
                        </select>
                    </div>
                    
                    <!-- Sort -->
                    <div class="flex items-center space-x-2">
                        <label for="sort-by" class="text-gray-700 dark:text-gray-300 font-medium">
                            <i class="fas fa-sort mr-2"></i>Urutkan:
                        </label>
                        <select id="sort-by" onchange="filterProducts()" 
                            class="px-4 py-2 rounded-lg bg-white/20 backdrop-blur-md border border-white/30 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">Default</option>
                            <option value="price-asc">Harga: Rendah ke Tinggi</option>
                            <option value="price-desc">Harga: Tinggi ke Rendah</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Enhanced Products Section -->
    <section id="products" class="container mx-auto mt-16 px-4">
        <div class="text-center mb-12">
            <h2 class="text-4xl font-black mb-4 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                🛍️ Produk Unggulan Kami
            </h2>
            <p class="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                Jelajahi koleksi lengkap produk digital gaming terbaik dengan kualitas premium dan harga terjangkau
            </p>
        </div>
        
        <div id="product-container" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            <?php foreach ($products as $index => $product): ?>
                <?php if ($index < 8): ?>
                    <div class="product-card transform opacity-0" data-category-id="<?= $product['category_id'] ?>" data-price="<?= $product['price'] ?>" data-product-id="<?= $product['product_id'] ?>">
                        <div class="relative group">
                            <div class="w-full h-56 bg-gradient-to-br from-gray-200 to-gray-300 dark:from-gray-600 dark:to-gray-700 flex items-center justify-center">
                                <i class="fas fa-image text-4xl text-gray-400"></i>
                            </div>
                            <?php if (rand(0, 1)): ?>
                                <span class="absolute top-3 left-3 bg-gradient-to-r from-red-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm font-semibold shadow-lg">🔥 Hot</span>
                            <?php endif; ?>
                            <div class="overlay">
                                <button onclick="openQuickView(<?= $product['product_id'] ?>)" class="bg-white text-blue-600 px-6 py-3 rounded-full hover:bg-blue-600 hover:text-white transition-all duration-300 font-semibold shadow-lg transform hover:scale-105">
                                    <i class="fas fa-eye mr-2"></i>Quick View
                                </button>
                            </div>
                        </div>
                        <div class="p-6">
                            <h3 class="product-name text-lg font-bold mb-2 text-gray-800 dark:text-gray-100 line-clamp-2"><?= esc($product['name']) ?></h3>
                            <p class="text-gray-600 dark:text-gray-400 mb-2 flex items-center">
                                <i class="fas fa-tag mr-2"></i><?= esc($product['category_name']) ?>
                            </p>
                            <p class="text-2xl font-bold mb-4 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                                Rp <?= number_format($product['price'], 0, ',', '.') ?>
                            </p>
                            <div class="space-y-3">
                                <?php if ($isLoggedIn): ?>
                                    <div class="flex items-center space-x-2">
                                        <input type="number" id="quantity-<?= $product['product_id'] ?>" min="1" max="99" value="1" 
                                            class="w-16 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-center bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200">
                                        <button onclick="addToCart(<?= $product['product_id'] ?>, document.getElementById('quantity-<?= $product['product_id'] ?>').value)" 
                                            data-product-id="<?= $product['product_id'] ?>" 
                                            class="neon-effect flex-1 text-sm">
                                            <i class="fas fa-cart-plus mr-2"></i>Tambah ke Keranjang
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <a href="/auth/login" class="block bg-gray-500 hover:bg-gray-600 text-white text-center px-4 py-3 rounded-lg transition-all duration-300 font-semibold">
                                        <i class="fas fa-sign-in-alt mr-2"></i>Login untuk Beli
                                    </a>
                                <?php endif; ?>
                                <div class="flex space-x-2">
                                    <a href="/product/<?= $product['product_id'] ?>" class="flex-1 text-center border-2 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white px-4 py-2 rounded-lg transition-all duration-300 font-semibold">
                                        <i class="fas fa-info-circle mr-2"></i>Detail
                                    </a>
                                    <button onclick="addToWishlist(<?= $product['product_id'] ?>)" data-wishlist-id="<?= $product['product_id'] ?>" 
                                        class="px-4 py-2 border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-all duration-300">
                                        <i class="fas fa-heart"></i>
                                    </button>
                                </div>
                                <div class="flex items-center justify-between text-sm">
                                    <div class="flex items-center space-x-1 text-yellow-500">
                                        <?php for ($i = 0; $i < 5; $i++): ?>
                                            <i class="fas fa-star<?= $i < (rand(3, 5)) ? '' : ' text-gray-300' ?>"></i>
                                        <?php endfor; ?>
                                        <span class="ml-1 text-gray-600 dark:text-gray-400">(<?= rand(10, 100) ?>)</span>
                                    </div>
                                    <span class="text-gray-500 dark:text-gray-400">
                                        <i class="fas fa-eye mr-1"></i><?= rand(100, 1000) ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Quick View Modal -->
    <div id="quick-view-modal" class="modal">
        <div class="modal-content">
            <button onclick="closeQuickView()" class="absolute top-4 right-4 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 text-2xl transition-colors">
                <i class="fas fa-times"></i>
            </button>
            <div class="w-full h-64 bg-gradient-to-br from-gray-200 to-gray-300 dark:from-gray-600 dark:to-gray-700 flex items-center justify-center mb-6 rounded-xl">
                <i class="fas fa-image text-6xl text-gray-400"></i>
            </div>
            <h3 id="quick-view-name" class="text-2xl font-bold mb-3 text-gray-800 dark:text-gray-200"></h3>
            <p id="quick-view-category" class="text-gray-600 dark:text-gray-400 mb-3 flex items-center">
                <i class="fas fa-tag mr-2"></i><span></span>
            </p>
            <p id="quick-view-price" class="text-3xl font-bold mb-6 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent"></p>
            <button onclick="addToCart(1)" class="neon-effect w-full text-lg py-4">
                <i class="fas fa-cart-plus mr-3"></i>Tambah ke Keranjang
            </button>
        </div>
    </div>

    <!-- Enhanced Footer -->
    <footer class="mt-20">
        <div class="container mx-auto px-4 py-12">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div class="space-y-4">
                    <h3 class="text-2xl font-black flex items-center">
                        <span class="text-3xl mr-3">🎮</span>
                        <span class="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">DigiDaw</span>
                    </h3>
                    <p class="text-gray-400 leading-relaxed">
                        Marketplace terpercaya untuk semua kebutuhan gaming digital Anda. 
                        Bergabunglah dengan jutaan gamer di seluruh Indonesia!
                    </p>
                    <div class="flex space-x-4">
                        <a href="#" class="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="w-10 h-10 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="w-10 h-10 bg-gradient-to-r from-pink-500 to-red-500 rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="w-10 h-10 bg-gradient-to-r from-red-500 to-red-600 rounded-full flex items-center justify-center text-white hover:scale-110 transition-transform">
                            <i class="fab fa-youtube"></i>
                        </a>
                    </div>
                </div>
                
                <div class="space-y-4">
                    <h4 class="text-lg font-bold text-white">🔗 Link Cepat</h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors flex items-center"><i class="fas fa-home mr-2"></i>Beranda</a></li>
                        <li><a href="#products" class="text-gray-400 hover:text-white transition-colors flex items-center"><i class="fas fa-shopping-bag mr-2"></i>Produk</a></li>
                        <li><a href="/cart/checkout" class="text-gray-400 hover:text-white transition-colors flex items-center"><i class="fas fa-shopping-cart mr-2"></i>Keranjang</a></li>
                        <li><a href="/dashboard" class="text-gray-400 hover:text-white transition-colors flex items-center"><i class="fas fa-tachometer-alt mr-2"></i>Dashboard</a></li>
                    </ul>
                </div>
                
                <div class="space-y-4">
                    <h4 class="text-lg font-bold text-white">📞 Kontak</h4>
                    <ul class="space-y-2">
                        <li><a href="mailto:support@digidaw.com" class="text-gray-400 hover:text-white transition-colors flex items-center"><i class="fas fa-envelope mr-2"></i>support@digidaw.com</a></li>
                        <li><a href="tel:+6281234567890" class="text-gray-400 hover:text-white transition-colors flex items-center"><i class="fas fa-phone mr-2"></i>+62 812-3456-7890</a></li>
                        <li><span class="text-gray-400 flex items-center"><i class="fas fa-map-marker-alt mr-2"></i>Jakarta, Indonesia</span></li>
                        <li><a href="#" class="text-gray-400 hover:text-white transition-colors flex items-center"><i class="fas fa-headset mr-2"></i>Live Chat 24/7</a></li>
                    </ul>
                </div>
                
                <div class="space-y-4">
                    <h4 class="text-lg font-bold text-white">📱 Download App</h4>
                    <p class="text-gray-400">Dapatkan pengalaman berbelanja yang lebih baik dengan aplikasi mobile kami</p>
                    <div class="space-y-2">
                        <a href="#" class="block bg-black text-white px-4 py-2 rounded-lg hover:bg-gray-800 transition-colors">
                            <i class="fab fa-apple mr-2"></i>Download di App Store
                        </a>
                        <a href="#" class="block bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                            <i class="fab fa-google-play mr-2"></i>Download di Google Play
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="border-t border-gray-700 mt-12 pt-8 text-center">
                <p class="text-gray-400">
                    © 2025 DigiDaw. All Rights Reserved. 
                    <span class="mx-2">|</span>
                    <a href="#" class="hover:text-white transition-colors">Privacy Policy</a>
                    <span class="mx-2">|</span>
                    <a href="#" class="hover:text-white transition-colors">Terms of Service</a>
                </p>
                <p class="text-gray-500 mt-2">
                    Dibangun dengan ❤️ oleh Tim DigiDaw untuk komunitas gaming Indonesia
                </p>
            </div>
        </div>
    </footer>

    <!-- Enhanced Scroll to Top -->
    <div class="scroll-to-top" onclick="scrollToTop()">
        <i class="fas fa-rocket text-xl"></i>
    </div>
</body>

</html>