<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Detail Laporan Penjualan - DigiDaw') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            color: #1e293b;
            background-color: #fff;
            margin: 0;
            padding: 20px;
        }

        .report-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
        }

        .report-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 20px;
        }

        .report-header img {
            max-width: 100px;
            margin-bottom: 10px;
        }

        .report-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0;
        }

        .report-header p {
            font-size: 0.9rem;
            color: #64748b;
            margin: 5px 0;
        }

        .report-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .summary-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }

        .summary-card h6 {
            font-size: 0.9rem;
            color: #64748b;
            margin-bottom: 10px;
        }

        .summary-card p {
            font-size: 1.2rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .table th,
        .table td {
            border: 1px solid #e2e8f0;
            padding: 12px;
            text-align: left;
            font-size: 0.9rem;
        }

        .table th {
            background: #f8fafc;
            font-weight: 600;
            color: #1e293b;
        }

        .table td {
            vertical-align: top;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f8fafc;
        }

        .list-unstyled {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .report-footer {
            text-align: center;
            margin-top: 30px;
            border-top: 2px solid #e2e8f0;
            padding-top: 20px;
            font-size: 0.8rem;
            color: #64748b;
        }

        /* Print Styles */
        @media print {
            body {
                margin: 0;
                padding: 0;
            }

            .report-container {
                padding: 10mm;
            }

            .report-header {
                border-bottom: 1px solid #000;
            }

            .report-footer {
                position: fixed;
                bottom: 0;
                width: 100%;
                border-top: 1px solid #000;
            }

            .no-print {
                display: none;
            }

            .table th,
            .table td {
                border: 1px solid #000;
            }
        }
    </style>
</head>
<body>
    <div class="report-container">
        <!-- Report Header -->
        <div class="report-header">
            <img src="<?= base_url('assets/images/logo.png') ?>" alt="DigiDaw Logo">
            <h1>Laporan Penjualan</h1>
            <p>ID Laporan: #<?= esc($report_id) ?></p>
            <p>Penjual: <?= esc($username ?? 'Unknown') ?></p>
            <p>Periode: <?= esc(date('d M Y', strtotime($startDate))) ?> - <?= esc(date('d M Y', strtotime($endDate))) ?></p>
            <p>Dibuat pada: <?= esc($currentTime) ?></p>
        </div>

        <!-- Report Summary -->
        <div class="report-summary">
            <div class="summary-card">
                <h6>Total Pesanan</h6>
                <p><?= esc(count($reports)) ?></p>
            </div>
            <div class="summary-card">
                <h6>Total Pendapatan</h6>
                <p>Rp <?= esc(number_format(array_sum(array_column($reports, 'total_price')), 0, ',', '.')) ?></p>
            </div>
            <div class="summary-card">
                <h6>Pesanan Selesai</h6>
                <p><?= esc(count(array_filter($reports, fn($r) => $r['status'] == 'completed'))) ?></p>
            </div>
        </div>

        <!-- Report Table -->
        <?php if (empty($reports)): ?>
            <div class="alert alert-info">
                Tidak ada pesanan yang ditemukan untuk periode ini.
            </div>
        <?php else: ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Pembeli</th>
                        <th>Total Harga</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Detail Produk</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reports as $report): ?>
                        <tr>
                            <td><?= esc($report['order_id']) ?></td>
                            <td><?= esc($report['buyer_name']) ?></td>
                            <td>Rp <?= esc(number_format($report['total_price'], 0, ',', '.')) ?></td>
                            <td>
                                <span class="badge <?= $report['status'] == 'completed' ? 'bg-success' : ($report['status'] == 'pending' ? 'bg-warning' : 'bg-secondary') ?>">
                                    <?= esc(ucfirst($report['status'])) ?>
                                </span>
                            </td>
                            <td><?= esc(date('d M Y H:i', strtotime($report['created_at']))) ?></td>
                            <td>
                                <?php if (!empty($report['items'])): ?>
                                    <ul class="list-unstyled">
                                        <?php foreach ($report['items'] as $item): ?>
                                            <li>
                                                <?= esc($item['name']) ?> (x<?= esc($item['quantity']) ?>) - 
                                                Rp <?= esc(number_format($item['price'], 0, ',', '.')) ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    Tidak ada detail produk.
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <!-- Report Footer -->
        <div class="report-footer">
            <p>DigiDaw - Laporan Penjualan</p>
            <p>Dicetak pada: <?= date('d M Y H:i') ?></p>
        </div>

        <!-- Back Button (Hidden on Print) -->
        <div class="mt-4 no-print">
            <a href="<?= base_url('admin/reports') ?>" class="btn btn-primary">Kembali ke Daftar Laporan</a>
        </div>
    </div>
</body>
</html>