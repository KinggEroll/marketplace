<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'DigiDaw Admin Dashboard') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #06b6d4;
            --dark: #1e293b;
            --light: #f8fafc;
            --sidebar-width: 280px;
            --header-height: 70px;
            --border-color: #e2e8f0;
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        [data-theme="dark"] {
            --primary: #3b82f6;
            --secondary: #94a3b8;
            --dark: #0f172a;
            --light: #1e293b;
            --border-color: #334155;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--light);
            color: var(--dark);
            transition: all 0.3s ease;
        }

        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: white;
            border-right: 1px solid var(--border-color);
            z-index: 1000;
            transition: all 0.3s ease;
            overflow-y: auto;
            box-shadow: var(--shadow-lg);
        }

        .sidebar.collapsed {
            width: 80px;
        }

        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .sidebar-logo {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.2rem;
            font-weight: 700;
        }

        .sidebar-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--dark);
            transition: opacity 0.3s ease;
        }

        .sidebar.collapsed .sidebar-title {
            opacity: 0;
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item {
            margin: 0.25rem 1rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 0.75rem 1rem;
            color: var(--secondary);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-link:hover {
            background-color: #f1f5f9;
            color: var(--primary);
        }

        .nav-link.active {
            background-color: var(--primary);
            color: white;
        }

        .nav-link i {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        .nav-text {
            transition: opacity 0.3s ease;
        }

        .sidebar.collapsed .nav-text {
            opacity: 0;
        }

        .nav-badge {
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 10px;
            margin-left: auto;
        }

        /* Header Styles */
        .main-header {
            position: fixed;
            top: 0;
            left: var(--sidebar-width);
            right: 0;
            height: var(--header-height);
            background: white;
            border-bottom: 1px solid var(--border-color);
            z-index: 999;
            transition: all 0.3s ease;
            box-shadow: var(--shadow);
        }

        .sidebar.collapsed+.main-header {
            left: 80px;
        }

        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 100%;
            padding: 0 2rem;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .sidebar-toggle {
            background: none;
            border: none;
            font-size: 1.2rem;
            color: var(--secondary);
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .sidebar-toggle:hover {
            background-color: #f1f5f9;
            color: var(--primary);
        }

        .header-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--dark);
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .header-btn {
            position: relative;
            background: none;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--secondary);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .header-btn:hover {
            background-color: #f1f5f9;
            color: var(--primary);
        }

        .notification-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            background: var(--danger);
            color: white;
            font-size: 0.7rem;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }

        .user-dropdown,
        .notification-dropdown {
            position: relative;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            cursor: pointer;
        }

        .dropdown-menu,
        .notification-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            min-width: 300px;
            z-index: 1001;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }

        .dropdown-menu.show,
        .notification-menu.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: var(--secondary);
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .dropdown-item:hover {
            background-color: #f1f5f9;
            color: var(--primary);
        }

        .dropdown-divider {
            height: 1px;
            background: var(--border-color);
            margin: 0.5rem 0;
        }

        .notification-item {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            border-bottom: 1px solid var(--border-color);
            transition: all 0.3s ease;
        }

        .notification-item:last-child {
            border-bottom: none;
        }

        .notification-item.unread {
            background-color: #f0f9ff;
        }

        .notification-item:hover {
            background-color: #f1f5f9;
        }

        .notification-icon {
            font-size: 1.1rem;
            color: var(--primary);
        }

        .notification-content h6 {
            margin: 0 0 0.25rem 0;
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--dark);
        }

        .notification-content p {
            margin: 0;
            font-size: 0.8rem;
            color: var(--secondary);
        }

        .notification-time {
            font-size: 0.7rem;
            color: var(--secondary);
            margin-top: 0.25rem;
        }

        .notification-footer {
            padding: 0.75rem 1rem;
            text-align: center;
        }

        .notification-footer a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .notification-footer a:hover {
            text-decoration: underline;
        }

        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            margin-top: var(--header-height);
            padding: 2rem;
            transition: all 0.3s ease;
            min-height: calc(100vh - var(--header-height));
        }

        .sidebar.collapsed~.main-content {
            margin-left: 80px;
        }

        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--primary-dark));
        }

        .stat-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }

        .stat-icon.primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
        }

        .stat-icon.success {
            background: linear-gradient(135deg, var(--success), #059669);
        }

        .stat-icon.warning {
            background: linear-gradient(135deg, var(--warning), #d97706);
        }

        .stat-icon.danger {
            background: linear-gradient(135deg, var(--danger), #dc2626);
        }

        .stat-icon.info {
            background: linear-gradient(135deg, var(--info), #0891b2);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--secondary);
            font-size: 0.9rem;
            font-weight: 500;
        }

        .stat-change {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.8rem;
            font-weight: 600;
            margin-top: 0.5rem;
        }

        .stat-change.positive {
            color: var(--success);
        }

        .stat-change.negative {
            color: var(--danger);
        }

        .stat-change.neutral {
            color: var(--secondary);
        }

        /* Content Cards */
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .card {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--border-color);
            background: #f8fafc;
        }

        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--dark);
            margin: 0;
        }

        .card-body {
            padding: 1.5rem;
        }

        .chart-container {
            position: relative;
            height: 300px;
        }

        /* Quick Actions */
        .quick-actions {
            display: grid;
            gap: 1rem;
        }

        .quick-action {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: #f8fafc;
            border-radius: 8px;
            text-decoration: none;
            color: var(--dark);
            transition: all 0.3s ease;
        }

        .quick-action:hover {
            background: #e2e8f0;
            transform: translateX(4px);
        }

        .quick-action-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Activity Feed */
        .activity-item {
            display: flex;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 1px solid var(--border-color);
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .activity-content h6 {
            margin: 0 0 0.25rem 0;
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--dark);
        }

        .activity-content p {
            margin: 0;
            font-size: 0.8rem;
            color: var(--secondary);
        }

        .activity-time {
            font-size: 0.7rem;
            color: var(--secondary);
            margin-top: 0.25rem;
        }

        /* Toast Notifications */
        .toast-container {
            position: fixed;
            top: 2rem;
            right: 2rem;
            z-index: 1050;
        }

        .toast {
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            padding: 1rem;
            margin-bottom: 1rem;
            min-width: 300px;
            transform: translateX(400px);
            transition: all 0.3s ease;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.success {
            border-left: 4px solid var(--success);
        }

        .toast.error {
            border-left: 4px solid var(--danger);
        }

        .toast.warning {
            border-left: 4px solid var(--warning);
        }

        .toast.info {
            border-left: 4px solid var(--info);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.mobile-open {
                transform: translateX(0);
            }

            .main-header {
                left: 0;
            }

            .main-content {
                margin-left: 0;
            }

            .content-grid {
                grid-template-columns: 1fr;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .header-title {
                font-size: 1.2rem;
            }

            .notification-menu {
                min-width: 100%;
                right: 0;
                left: 0;
                margin: 0 1rem;
            }
        }

        /* Dark Theme */
        [data-theme="dark"] {
            background-color: var(--dark);
            color: white;
        }

        [data-theme="dark"] .sidebar,
        [data-theme="dark"] .main-header,
        [data-theme="dark"] .card,
        [data-theme="dark"] .stat-card,
        [data-theme="dark"] .notification-menu {
            background: var(--light);
            border-color: var(--border-color);
        }

        [data-theme="dark"] .card-header {
            background: var(--dark);
        }

        [data-theme="dark"] .nav-link:hover {
            background-color: #334155;
        }

        [data-theme="dark"] .header-btn:hover {
            background-color: #334155;
        }

        [data-theme="dark"] .quick-action {
            background: var(--dark);
        }

        [data-theme="dark"] .quick-action:hover {
            background: #334155;
        }

        [data-theme="dark"] .notification-item.unread {
            background-color: #1e40af;
        }

        [data-theme="dark"] .notification-item:hover {
            background-color: #334155;
        }

        /* Loading Animation */
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, .3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        /* Counter Animation */
        .counter {
            display: inline-block;
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo">
                <i class="fas fa-gem"></i>
            </div>
            <div class="sidebar-title">DigiDaw</div>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="<?= base_url('admin/dashboard') ?>" class="nav-link active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/sellers') ?>" class="nav-link">
                    <i class="fas fa-store"></i>
                    <span class="nav-text">Penjual</span>
                    <?php if (($pending_sellers ?? 0) > 0): ?>
                        <span class="nav-badge" id="pendingSellersBadge"><?= $pending_sellers ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/orders') ?>" class="nav-link">
                    <i class="fas fa-shopping-cart"></i>
                    <span class="nav-text">Pesanan</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/products') ?>" class="nav-link">
                    <i class="fas fa-box"></i>
                    <span class="nav-text">Produk</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/users') ?>" class="nav-link">
                    <i class="fas fa-users"></i>
                    <span class="nav-text">Pengguna</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/reports') ?>" class="nav-link">
                    <i class="fas fa-chart-bar"></i>
                    <span class="nav-text">Laporan</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/promos') ?>" class="nav-link">
                    <i class="fas fa-tags"></i>
                    <span class="nav-text">Promo</span>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/wallets') ?>" class="nav-link">
                    <i class="fas fa-wallet"></i>
                    <span class="nav-text">Dompet</span>
                    <?php if (($pending_deposits ?? 0) > 0): ?>
                        <span class="nav-badge" id="pendingDepositsBadge"><?= $pending_deposits ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/complaints') ?>" class="nav-link">
                    <i class="fas fa-exclamation-triangle"></i>
                    <span class="nav-text">Keluhan</span>
                    <?php if (($open_complaints ?? 0) > 0): ?>
                        <span class="nav-badge" id="openComplaintsBadge"><?= $open_complaints ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item">
                <a href="<?= base_url('admin/notifications') ?>" class="nav-link">
                    <i class="fas fa-bell"></i>
                    <span class="nav-text">Notifikasi</span>
                    <?php if (($unread_notifications ?? 0) > 0): ?>
                        <span class="nav-badge" id="notificationBadge"><?= $unread_notifications ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </nav>
    </div>

    <!-- Header -->
    <header class="main-header">
        <div class="header-content">
            <div class="header-left">
                <button class="sidebar-toggle" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                <h1 class="header-title">Dashboard</h1>
                <button class="btn btn-primary btn-sm ms-3" id="refreshBtn">
                    <i class="fas fa-sync-alt me-1"></i> Refresh
                </button>
            </div>

            <div class="header-right">
                <div class="notification-dropdown">
                    <button class="header-btn" id="notificationBtn">
                        <i class="fas fa-bell"></i>
                        <?php if (($unread_notifications ?? 0) > 0): ?>
                            <span class="notification-badge" id="notificationCount"><?= $unread_notifications ?></span>
                        <?php endif; ?>
                    </button>
                    <div class="notification-menu" id="notificationMenu">
                        <div id="notificationList"></div>
                        <div class="notification-footer">
                            <a href="<?= base_url('admin/notifications') ?>">Lihat Semua Notifikasi</a>
                        </div>
                    </div>
                </div>

                <button class="header-btn" id="themeToggle">
                    <i class="fas fa-moon"></i>
                </button>

                <div class="user-dropdown">
                    <div class="user-avatar" id="userDropdown">
                        <?= strtoupper(substr(session()->get('admin_username') ?? 'A', 0, 1)) ?>
                    </div>
                    <div class="dropdown-menu" id="dropdownMenu">
                        <a href="<?= base_url('admin/logout') ?>" class="dropdown-item">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Logout</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Statistics Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon primary">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <div class="stat-value counter" data-target="<?= esc($user_count ?? 0) ?>">0</div>
                <div class="stat-label">Total Pengguna</div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i>
                    <span>Terbaru: <?= date('d M Y', strtotime($latest_user['created_at'] ?? 'now')) ?></span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon success">
                        <i class="fas fa-shopping-cart"></i>
                    </div>
                </div>
                <div class="stat-value counter" data-target="<?= esc($order_count ?? 0) ?>">0</div>
                <div class="stat-label">Total Pesanan</div>
                <div class="stat-change neutral">
                    <i class="fas fa-info-circle"></i>
                    <span>Pending: <?= esc($order_statuses['pending'] ?? 0) ?></span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon warning">
                        <i class="fas fa-money-bill-wave"></i>
                    </div>
                </div>
                <div class="stat-value counter total-revenue" data-target="<?= esc($total_revenue ?? 0) ?>">0</div>
                <div class="stat-label">Total Pendapatan</div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i>
                    <span>Rp <?= number_format($total_revenue ?? 0, 0, ',', '.') ?></span>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon info">
                        <i class="fas fa-user-check"></i>
                    </div>
                </div>
                <div class="stat-value counter" data-target="<?= esc($active_users ?? 0) ?>">0</div>
                <div class="stat-label">Pengguna Aktif</div>
                <div class="stat-change positive">
                    <i class="fas fa-arrow-up"></i>
                    <span><?= round(($active_users / max($user_count, 1)) * 100, 1) ?>% dari total</span>
                </div>
            </div>
        </div>

        <!-- Content Grid -->
        <div class="content-grid">
            <!-- Chart Section -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">
                        <i class="fas fa-chart-area me-2"></i>
                        Analisis Penjualan
                    </h5>
                </div>
                <div class="card-body">
                    <div class="chart-container">
                        <canvas id="salesChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">
                        <i class="fas fa-bolt me-2"></i>
                        Aksi Cepat
                    </h5>
                </div>
                <div class="card-body">
                    <div class="quick-actions">
                        <a href="<?= base_url('admin/sellers') ?>" class="quick-action">
                            <div class="quick-action-icon warning">
                                <i class="fas fa-user-check"></i>
                            </div>
                            <div>
                                <strong>Verifikasi Penjual</strong>
                                <small class="d-block text-muted"><?= esc($pending_sellers ?? 0) ?> menunggu</small>
                            </div>
                        </a>

                        <a href="<?= base_url('admin/wallets') ?>" class="quick-action">
                            <div class="quick-action-icon success">
                                <i class="fas fa-wallet"></i>
                            </div>
                            <div>
                                <strong>Deposit Pending</strong>
                                <small class="d-block text-muted"><?= esc($pending_deposits ?? 0) ?> transaksi</small>
                            </div>
                        </a>

                        <a href="<?= base_url('admin/complaints') ?>" class="quick-action">
                            <div class="quick-action-icon danger">
                                <i class="fas fa-exclamation-triangle"></i>
                            </div>
                            <div>
                                <strong>Keluhan Terbuka</strong>
                                <small class="d-block text-muted"><?= esc($open_complaints ?? 0) ?> keluhan</small>
                            </div>
                        </a>

                        <a href="<?= base_url('admin/notifications') ?>" class="quick-action">
                            <div class="quick-action-icon primary">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div>
                                <strong>Notifikasi Baru</strong>
                                <small class="d-block text-muted"><?= esc($unread_notifications ?? 0) ?> belum dibaca</small>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Kategori Terpopuler -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-list me-2"></i>
                    Kategori Terpopuler
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($category_performance)): ?>
                    <?php foreach (array_slice($category_performance, 0, 5) as $index => $category): ?>
                        <div class="d-flex align-items-center mb-3">
                            <div class="badge bg-primary me-3"><?= $index + 1 ?></div>
                            <div class="flex-grow-1">
                                <h6 class="mb-1"><?= esc($category['name']) ?></h6>
                                <small class="text-muted"><?= esc($category['total_sold']) ?> terjual</small>
                            </div>
                            <div class="text-end">
                                <strong>Rp <?= number_format($category['avg_price'], 0, ',', '.') ?></strong>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-list fa-3x mb-3"></i>
                        <p>Belum ada data kategori</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-history me-2"></i>
                    Aktivitas Terbaru
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($recent_user_logs)): ?>
                    <?php foreach (array_slice($recent_user_logs, 0, 5) as $log): ?>
                        <div class="activity-item">
                            <div class="activity-avatar">
                                <?= strtoupper(substr($log['username'] ?? 'U', 0, 1)) ?>
                            </div>
                            <div class="activity-content">
                                <h6><?= esc($log['username'] ?? 'Unknown') ?></h6>
                                <p><?= esc($log['description'] ?? $log['action']) ?></p>
                                <div class="activity-time">
                                    <i class="fas fa-clock me-1"></i>
                                    <?= date('d M Y, H:i', strtotime($log['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-3x mb-3"></i>
                        <p>Belum ada aktivitas terbaru</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Orders Overview and Top Products -->
        <div class="row mt-4">
            <div class="col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">
                            <i class="fas fa-shopping-bag me-2"></i>
                            Status Pesanan
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="orderStatusChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">
                            <i class="fas fa-trophy me-2"></i>
                            Produk Terlaris
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($top_products)): ?>
                            <?php foreach (array_slice($top_products, 0, 5) as $index => $product): ?>
                                <div class="d-flex align-items-center mb-3">
                                    <div class="badge bg-primary me-3"><?= $index + 1 ?></div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-1"><?= esc($product['name']) ?></h6>
                                        <small class="text-muted"><?= esc($product['sold_count']) ?> terjual</small>
                                        <small class="text-muted d-block">Penjual: <?= esc($product['seller_name']) ?></small>
                                        <small class="text-muted d-block">Kategori: <?= esc($product['category_name']) ?></small>
                                    </div>
                                    <div class="text-end">
                                        <strong>Rp <?= number_format($product['price'], 0, ',', '.') ?></strong>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-box fa-3x mb-3"></i>
                                <p>Belum ada data produk</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Transaksi Terbaru -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title">
                    <i class="fas fa-money-bill-wave me-2"></i>
                    Transaksi Terbaru
                </h5>
            </div>
            <div class="card-body">
                <?php if (!empty($recent_transactions)): ?>
                    <?php foreach (array_slice($recent_transactions, 0, 5) as $trans): ?>
                        <div class="activity-item">
                            <div class="activity-avatar">
                                <?= strtoupper(substr($trans['buyer_name'] ?? 'T', 0, 1)) ?>
                            </div>
                            <div class="activity-content">
                                <h6>Pesanan #<?= esc($trans['order_id']) ?> - <?= esc($trans['buyer_name']) ?></h6>
                                <p>Rp <?= number_format($trans['total_price'], 0, ',', '.') ?> - Status: <?= esc($trans['status']) ?></p>
                                <div class="activity-time">
                                    <i class="fas fa-clock me-1"></i>
                                    <?= date('d M Y, H:i', strtotime($trans['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-money-bill fa-3x mb-3"></i>
                        <p>Belum ada transaksi terbaru</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Toast Container -->
    <div class="toast-container" id="toastContainer"></div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // DOM Elements
        const sidebar = document.getElementById('sidebar');
        const sidebarToggle = document.getElementById('sidebarToggle');
        const themeToggle = document.getElementById('themeToggle');
        const userDropdown = document.getElementById('userDropdown');
        const dropdownMenu = document.getElementById('dropdownMenu');
        const notificationBtn = document.getElementById('notificationBtn');
        const notificationMenu = document.getElementById('notificationMenu');
        const notificationList = document.getElementById('notificationList');
        const refreshBtn = document.getElementById('refreshBtn');

        // Sidebar Toggle
        sidebarToggle.addEventListener('click', () => {
            sidebar.classList.toggle('collapsed');
            localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
        });

        // Load sidebar state
        if (localStorage.getItem('sidebarCollapsed') === 'true') {
            sidebar.classList.add('collapsed');
        }

        // Theme Toggle
        themeToggle.addEventListener('click', () => {
            const isDark = document.body.dataset.theme === 'dark';
            document.body.dataset.theme = isDark ? 'light' : 'dark';
            themeToggle.querySelector('i').className = isDark ? 'fas fa-moon' : 'fas fa-sun';
            localStorage.setItem('theme', document.body.dataset.theme);
        });

        // Load theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme) {
            document.body.dataset.theme = savedTheme;
            themeToggle.querySelector('i').className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }

        // User Dropdown
        userDropdown.addEventListener('click', (e) => {
            e.stopPropagation();
            dropdownMenu.classList.toggle('show');
            notificationMenu.classList.remove('show');
        });

        // Notification Popup
        notificationBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            notificationMenu.classList.toggle('show');
            dropdownMenu.classList.remove('show');
            if (notificationMenu.classList.contains('show')) {
                fetchNotifications();
            }
        });

        // Close menus on outside click
        document.addEventListener('click', () => {
            dropdownMenu.classList.remove('show');
            notificationMenu.classList.remove('show');
        });

        // Prevent menu close on click inside
        notificationMenu.addEventListener('click', (e) => {
            e.stopPropagation();
        });

        // Debug base URL
        console.log('Base URL:', '<?= base_url() ?>');

        // Fetch Notifications
        function fetchNotifications() {
            notificationList.innerHTML = `
                <div class="text-center py-4">
                    <span class="loading"></span>
                    <p class="text-muted mt-2">Memuat notifikasi...</p>
                </div>
            `;

            const notificationUrl = '<?= base_url('admin/notifications/recent') ?>';
            console.log('Fetching notifications from:', notificationUrl);

            fetch(notificationUrl, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => {
                    console.log('Response status:', response.status);
                    if (!response.ok) {
                        return response.text().then(text => {
                            throw new Error(`HTTP error! status: ${response.status}, response: ${text}`);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Received data:', data);
                    if (data.success && data.notifications) {
                        notificationList.innerHTML = data.notifications.length > 0 ? '' : `
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-bell fa-2x mb-3"></i>
                                <p>Tidak ada notifikasi baru</p>
                            </div>
                        `;
                        data.notifications.forEach(notification => {
                            const notificationItem = document.createElement('div');
                            notificationItem.className = `notification-item ${notification.is_read ? '' : 'unread'}`;
                            notificationItem.innerHTML = `
                                <i class="notification-icon fas fa-${notification.is_read ? 'bell' : 'bell'}" style="${notification.is_read ? '' : 'color: var(--danger);'}"></i>
                                <div class="notification-content">
                                    <h6>${sanitizeHTML(notification.title)}</h6>
                                    <p>${sanitizeHTML(notification.message)}</p>
                                    <div class="notification-time">
                                        <i class="fas fa-clock me-1"></i>
                                        ${sanitizeHTML(notification.created_at)}
                                    </div>
                                </div>
                            `;
                            notificationList.appendChild(notificationItem);
                        });
                    } else {
                        notificationList.innerHTML = `
                            <div class="text-center text-muted py-4">
                                <i class="fas fa-exclamation-circle fa-2x mb-3"></i>
                                <p>Gagal memuat notifikasi: ${sanitizeHTML(data.error || 'Unknown error')}</p>
                            </div>
                        `;
                        showToast('error', 'Error', data.error || 'Gagal memuat notifikasi');
                    }
                })
                .catch(error => {
                    console.error('Error fetching notifications:', error.message);
                    notificationList.innerHTML = `
                        <div class="text-center text-muted py-4">
                            <i class="fas fa-exclamation-circle fa-2x mb-3"></i>
                            <p>Gagal menghubungkan ke server: ${sanitizeHTML(error.message)}</p>
                        </div>
                    `;
                    showToast('error', 'Error', `Gagal menghubungkan ke server: ${error.message}`);
                });
        }

        // Sanitize HTML to prevent XSS
        function sanitizeHTML(str) {
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }

        // Refresh Button
        refreshBtn.addEventListener('click', () => {
            window.location.reload();
        });

        // Mobile Sidebar
        if (window.innerWidth <= 768) {
            sidebar.classList.add('collapsed');
            sidebarToggle.addEventListener('click', () => {
                sidebar.classList.toggle('mobile-open');
            });
        }

        // Counter Animation
        function animateCounter(element) {
            const target = parseInt(element.dataset.target);
            const duration = 2000;
            const step = target / (duration / 16);
            let current = 0;

            const timer = setInterval(() => {
                current += step;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                if (element.classList.contains('total-revenue')) {
                    element.textContent = Math.floor(current).toLocaleString('id-ID', {
                        style: 'currency',
                        currency: 'IDR',
                        minimumFractionDigits: 0
                    });
                } else {
                    element.textContent = Math.floor(current).toLocaleString('id-ID');
                }
            }, 16);
        }

        // Initialize counters
        document.querySelectorAll('.counter').forEach(animateCounter);

        // Sales Chart
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        const salesChart = new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: [<?php foreach ($sales_by_month as $sale) {
                                echo "'" . date('M', strtotime($sale['month'] . '/1/' . $sale['year'])) . "',";
                            } ?>],
                datasets: [{
                    label: 'Penjualan (Juta Rupiah)',
                    data: [<?php foreach ($sales_by_month as $sale) {
                                echo $sale['total_revenue'] / 1000000 . ",";
                            } ?>],
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: '#2563eb',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });

        // Order Status Chart
        const orderCtx = document.getElementById('orderStatusChart').getContext('2d');
        const orderChart = new Chart(orderCtx, {
            type: 'doughnut',
            data: {
                labels: ['Pending', 'Dibayar', 'Dikirim', 'Selesai', 'Dibatalkan'],
                datasets: [{
                    data: [
                        <?= esc($order_statuses['pending'] ?? 0) ?>,
                        <?= esc($order_statuses['paid'] ?? 0) ?>,
                        <?= esc($order_statuses['delivered'] ?? 0) ?>,
                        <?= esc($order_statuses['completed'] ?? 0) ?>,
                        <?= esc($order_statuses['cancelled'] ?? 0) ?>
                    ],
                    backgroundColor: [
                        '#f59e0b',
                        '#3b82f6',
                        '#10b981',
                        '#059669',
                        '#ef4444'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            padding: 20
                        }
                    }
                },
                cutout: '60%'
            }
        });

        // Toast Notifications
        function showToast(type, title, message) {
            const toastContainer = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.className = `toast ${type}`;

            toast.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'} me-3"></i>
                    <div>
                        <strong>${sanitizeHTML(title)}</strong>
                        <p class="mb-0">${sanitizeHTML(message)}</p>
                    </div>
                </div>
            `;

            toastContainer.appendChild(toast);

            setTimeout(() => {
                toast.classList.add('show');
            }, 100);

            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => {
                    toastContainer.removeChild(toast);
                }, 300);
            }, 4000);
        }

        // Real-time updates
        function updateNotifications() {
            const countUrl = '<?= base_url('admin/notifications/count') ?>';
            console.log('Fetching notification count from:', countUrl);

            fetch(countUrl, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => {
                    console.log('Response status:', response.status);
                    if (!response.ok) {
                        return response.text().then(text => {
                            throw new Error(`HTTP error! status: ${response.status}, response: ${text}`);
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Received notification count data:', data);
                    if (data.success) {
                        const badge = document.getElementById('notificationCount');
                        if (badge) {
                            badge.textContent = data.unread_notifications;
                            badge.style.display = data.unread_notifications > 0 ? 'block' : 'none';
                        }
                        // Update badge di sidebar
                        const sidebarBadges = {
                            'pendingSellersBadge': data.pending_sellers,
                            'pendingDepositsBadge': data.pending_deposits,
                            'openComplaintsBadge': data.open_complaints,
                            'notificationBadge': data.unread_notifications
                        };
                        Object.keys(sidebarBadges).forEach(id => {
                            const badge = document.getElementById(id);
                            if (badge) {
                                badge.textContent = sidebarBadges[id];
                                badge.style.display = sidebarBadges[id] > 0 ? 'inline-block' : 'none';
                            }
                        });
                    } else {
                        showToast('error', 'Error', 'Gagal memuat jumlah notifikasi: ' + (data.error || 'Unknown error'));
                    }
                })
                .catch(error => {
                    console.error('Error fetching notification count:', error.message);
                    showToast('error', 'Error', `Gagal menghubungkan ke server: ${error.message}`);
                });
        }

        // Update every 30 seconds
        setInterval(updateNotifications, 30000);
        updateNotifications();

        // Flash messages
        <?php if (session()->getFlashdata('success')): ?>
            showToast('success', 'Berhasil', <?= json_encode(session()->getFlashdata('success')) ?>);
        <?php endif; ?>

        <?php if (session()->getFlashdata('error')): ?>
            showToast('error', 'Error', <?= json_encode(is_array(session()->getFlashdata('error')) ? implode(' ', session()->getFlashdata('error')) : session()->getFlashdata('error')) ?>);
        <?php endif; ?>

        // Resize handler
        window.addEventListener('resize', () => {
            if (window.innerWidth <= 768) {
                sidebar.classList.add('collapsed');
            } else {
                sidebar.classList.remove('mobile-open');
            }
        });
    </script>
</body>

</html>