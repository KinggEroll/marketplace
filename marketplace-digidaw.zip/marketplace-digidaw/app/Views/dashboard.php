    <!-- <!DOCTYPE html>
    <html lang="id">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard Pembeli - DigiDaw</title>
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
        <style>
            body {
                font-family: 'Inter', sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                position: relative;
                overflow-x: hidden;
            }

            .dark body {
                background: linear-gradient(135deg, #1a202c 0%, #2d3748 100%);
            }

            /* Animated Background */
            .bg-animated {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                z-index: -1;
                overflow: hidden;
            }

            .floating-shape {
                position: absolute;
                border-radius: 50%;
                background: linear-gradient(45deg, rgba(255, 255, 255, 0.1), rgba(255, 255, 255, 0.05));
                animation: float 6s ease-in-out infinite;
            }

            .floating-shape:nth-child(1) {
                width: 80px;
                height: 80px;
                top: 20%;
                left: 10%;
                animation-delay: 0s;
            }

            .floating-shape:nth-child(2) {
                width: 120px;
                height: 120px;
                top: 60%;
                right: 10%;
                animation-delay: 2s;
            }

            .floating-shape:nth-child(3) {
                width: 60px;
                height: 60px;
                bottom: 20%;
                left: 20%;
                animation-delay: 4s;
            }

            @keyframes float {

                0%,
                100% {
                    transform: translateY(0px) rotate(0deg);
                }

                50% {
                    transform: translateY(-20px) rotate(180deg);
                }
            }

            /* Glassmorphism */
            .glass-card {
                background: rgba(255, 255, 255, 0.25);
                backdrop-filter: blur(20px);
                border: 1px solid rgba(255, 255, 255, 0.3);
                border-radius: 20px;
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .dark .glass-card {
                background: rgba(45, 55, 72, 0.4);
                border: 1px solid rgba(255, 255, 255, 0.1);
                box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
            }

            .glass-card:hover {
                transform: translateY(-8px);
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            }

            /* Navbar */
            .navbar {
                backdrop-filter: blur(20px);
                background: rgba(255, 255, 255, 0.15);
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
                position: sticky;
                top: 0;
                z-index: 50;
                transition: all 0.3s ease;
            }

            .dark .navbar {
                background: rgba(26, 32, 44, 0.4);
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            }

            /* Stat Cards */
            .stat-card {
                background: linear-gradient(135deg, rgba(255, 255, 255, 0.2), rgba(255, 255, 255, 0.1));
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255, 255, 255, 0.3);
                border-radius: 16px;
                padding: 1.5rem;
                text-align: center;
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                position: relative;
                overflow: hidden;
            }

            .stat-card::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
                transition: left 0.5s;
            }

            .stat-card:hover::before {
                left: 100%;
            }

            .stat-card:hover {
                transform: translateY(-10px) scale(1.02);
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            }

            .dark .stat-card {
                background: linear-gradient(135deg, rgba(74, 85, 104, 0.4), rgba(74, 85, 104, 0.2));
                border-color: rgba(255, 255, 255, 0.1);
            }

            /* Gradient Text */
            .gradient-text {
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .dark .gradient-text {
                background: linear-gradient(135deg, #90cdf4 0%, #a78bfa 100%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            /* Dropdown Animation */
            .dropdown-menu {
                transform: translateY(-10px) scale(0.95);
                transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                opacity: 0;
                visibility: hidden;
            }

            .dropdown-menu.active {
                opacity: 1;
                visibility: visible;
                transform: translateY(0) scale(1);
            }

            /* Button Animations */
            .btn-animated {
                position: relative;
                overflow: hidden;
                transition: all 0.3s ease;
            }

            .btn-animated::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
                transition: left 0.5s;
            }

            .btn-animated:hover::before {
                left: 100%;
            }

            .btn-animated:hover {
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            }

            /* Table Enhancements */
            .modern-table {
                background: rgba(255, 255, 255, 0.1);
                backdrop-filter: blur(10px);
                border-radius: 12px;
                overflow: hidden;
            }

            .modern-table tr:hover {
                background: rgba(255, 255, 255, 0.1);
                transform: scale(1.01);
                transition: all 0.2s ease;
            }

            /* Promo Cards */
            .promo-card {
                background: linear-gradient(135deg, #667eea, #764ba2);
                border-radius: 16px;
                padding: 1.5rem;
                color: white;
                position: relative;
                overflow: hidden;
                transition: all 0.3s ease;
            }

            .promo-card::before {
                content: '';
                position: absolute;
                top: -50%;
                left: -50%;
                width: 200%;
                height: 200%;
                background: radial-gradient(circle, rgba(255, 255, 255, 0.1) 0%, transparent 70%);
                transform: rotate(45deg);
                transition: all 0.5s ease;
                opacity: 0;
            }

            .promo-card:hover::before {
                opacity: 1;
                transform: rotate(45deg) translate(20px, 20px);
            }

            .promo-card:hover {
                transform: translateY(-5px) scale(1.02);
                box-shadow: 0 15px 30px rgba(0, 0, 0, 0.3);
            }

            .dark .promo-card {
                background: linear-gradient(135deg, #4a5568, #2d3748);
            }

            /* Wishlist Cards */
            .wishlist-card {
                background: rgba(255, 255, 255, 0.2);
                backdrop-filter: blur(15px);
                border: 1px solid rgba(255, 255, 255, 0.3);
                border-radius: 16px;
                overflow: hidden;
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .wishlist-card:hover {
                transform: translateY(-10px) scale(1.03);
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            }

            .wishlist-card img {
                transition: transform 0.4s ease;
            }

            .wishlist-card:hover img {
                transform: scale(1.1);
            }

            /* Loading Animation */
            .loading-pulse {
                animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
            }

            @keyframes pulse {

                0%,
                100% {
                    opacity: 1;
                }

                50% {
                    opacity: 0.5;
                }
            }

            /* Scroll Animations */
            .fade-in {
                opacity: 0;
                transform: translateY(30px);
                animation: fadeInUp 0.6s ease forwards;
            }

            .fade-in:nth-child(1) {
                animation-delay: 0.1s;
            }

            .fade-in:nth-child(2) {
                animation-delay: 0.2s;
            }

            .fade-in:nth-child(3) {
                animation-delay: 0.3s;
            }

            .fade-in:nth-child(4) {
                animation-delay: 0.4s;
            }

            .fade-in:nth-child(5) {
                animation-delay: 0.5s;
            }

            @keyframes fadeInUp {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            /* Status Badges */
            .status-badge {
                padding: 0.5rem 1rem;
                border-radius: 50px;
                font-size: 0.875rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.05em;
                position: relative;
                overflow: hidden;
            }

            .status-badge::before {
                content: '';
                position: absolute;
                top: 0;
                left: -100%;
                width: 100%;
                height: 100%;
                background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
                transition: left 0.5s;
            }

            .status-badge:hover::before {
                left: 100%;
            }

            /* Custom Scrollbar */
            ::-webkit-scrollbar {
                width: 8px;
            }

            ::-webkit-scrollbar-track {
                background: rgba(255, 255, 255, 0.1);
                border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 4px;
            }

            ::-webkit-scrollbar-thumb:hover {
                background: rgba(255, 255, 255, 0.5);
            }
        </style>
    </head>

    <body>
        <!-- Animated Background -->
        <div class="bg-animated">
            <div class="floating-shape"></div>
            <div class="floating-shape"></div>
            <div class="floating-shape"></div>
        </div>

        <!-- Navbar -->
        <nav class="navbar p-4">
            <div class="container mx-auto flex justify-between items-center">
                <a href="/" class="text-3xl font-bold gradient-text flex items-center">
                    <span class="mr-3 text-4xl">🎮</span> DigiDaw
                </a>
                <div class="flex items-center space-x-6">
                    <?php if ($isLoggedIn): ?>
                        <div class="relative dropdown">
                            <button class="flex items-center text-white hover:text-blue-200 transition-all duration-300 btn-animated px-4 py-2 rounded-full bg-white bg-opacity-20">
                                <i class="fas fa-user-circle mr-2 text-2xl"></i>
                                <span class="font-semibold"><?= esc($username) ?></span>
                                <i class="fas fa-chevron-down ml-2 text-sm transition-transform duration-300" id="dropdown-icon"></i>
                            </button>
                            <div class="dropdown-menu absolute right-0 mt-2 w-56 glass-card py-2">
                                <a href="/profile/edit" class="block px-4 py-3 text-gray-800 dark:text-gray-200 hover:bg-white hover:bg-opacity-20 transition-all duration-200 flex items-center">
                                    <i class="fas fa-user mr-3"></i> Profil
                                </a>
                                <a href="/dashboard" class="block px-4 py-3 text-gray-800 dark:text-gray-200 hover:bg-white hover:bg-opacity-20 transition-all duration-200 flex items-center">
                                    <i class="fas fa-home mr-3"></i> Dashboard
                                </a>
                                <a href="/auth/logout" class="block px-4 py-3 text-red-600 hover:bg-red-500 hover:text-white transition-all duration-200 flex items-center">
                                    <i class="fas fa-sign-out-alt mr-3"></i> Logout
                                </a>
                            </div>
                        </div>
                    <?php else: ?>
                        <a href="/auth/login" class="text-white hover:text-blue-200 font-medium transition-all duration-300">Masuk</a>
                        <a href="/auth/register" class="bg-white bg-opacity-20 hover:bg-opacity-30 text-white px-6 py-2 rounded-full hover:shadow-lg transition-all duration-300 font-semibold btn-animated">Daftar</a>
                    <?php endif; ?>
                    <button onclick="toggleDarkMode()" class="text-white hover:text-blue-200 p-2 rounded-full bg-white bg-opacity-20 hover:bg-opacity-30 transition-all duration-300">
                        <i class="fas fa-moon text-lg"></i>
                    </button>
                </div>
            </div>
        </nav>

        <!-- Dashboard Content -->
        <div class="container mx-auto px-4 py-8">
            <div class="mb-12 text-center fade-in">
                <h2 class="text-5xl font-bold text-white mb-4">Dashboard Pembeli</h2>
                <p class="text-xl text-white text-opacity-80">Selamat datang kembali! Kelola semua aktivitas belanja Anda di sini.</p>
                <div class="mt-4 text-white text-opacity-60" id="current-time"></div>
            </div>

            <!-- Buyer Stats -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-12">
                <div class="stat-card fade-in">
                    <div class="flex items-center justify-center mb-4">
                        <div class="p-3 bg-green-500 bg-opacity-20 rounded-full">
                            <i class="fas fa-wallet text-2xl text-green-400"></i>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">Saldo Dompet</h3>
                    <p class="text-3xl font-bold gradient-text">Rp <?= number_format($stats['wallet_balance'], 0, ',', '.') ?></p>
                    <div class="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        <span class="loading-pulse">●</span> Aktif
                    </div>
                </div>

                <div class="stat-card fade-in">
                    <div class="flex items-center justify-center mb-4">
                        <div class="p-3 bg-blue-500 bg-opacity-20 rounded-full">
                            <i class="fas fa-shopping-bag text-2xl text-blue-400"></i>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">Total Pesanan</h3>
                    <p class="text-3xl font-bold gradient-text"><?= esc($stats['total_orders']) ?></p>
                    <div class="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        <i class="fas fa-arrow-up text-green-500"></i> +12% bulan ini
                    </div>
                </div>

                <div class="stat-card fade-in">
                    <div class="flex items-center justify-center mb-4">
                        <div class="p-3 bg-yellow-500 bg-opacity-20 rounded-full">
                            <i class="fas fa-clock text-2xl text-yellow-400"></i>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">Pesanan Tertunda</h3>
                    <p class="text-3xl font-bold gradient-text"><?= esc($stats['pending_orders']) ?></p>
                    <div class="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        <span class="loading-pulse text-yellow-500">●</span> Menunggu
                    </div>
                </div>

                <div class="stat-card fade-in">
                    <div class="flex items-center justify-center mb-4">
                        <div class="p-3 bg-pink-500 bg-opacity-20 rounded-full">
                            <i class="fas fa-heart text-2xl text-pink-400"></i>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">Item Wishlist</h3>
                    <p class="text-3xl font-bold gradient-text"><?= esc($stats['wishlist_count']) ?></p>
                    <div class="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        <i class="fas fa-heart text-pink-500"></i> Favorit
                    </div>
                </div>

                <div class="stat-card fade-in">
                    <div class="flex items-center justify-center mb-4">
                        <div class="p-3 bg-purple-500 bg-opacity-20 rounded-full">
                            <i class="fas fa-tags text-2xl text-purple-400"></i>
                        </div>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-2">Promo Aktif</h3>
                    <p class="text-3xl font-bold gradient-text"><?= esc($stats['active_promos']) ?></p>
                    <div class="mt-2 text-sm text-gray-600 dark:text-gray-400">
                        <i class="fas fa-fire text-orange-500"></i> Hot Deals
                    </div>
                </div>
            </div>

            <!-- Profile Status -->
            <div class="glass-card mb-8 fade-in">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                        <i class="fas fa-user-check mr-3 text-blue-500"></i>
                        Status Profil
                    </h3>
                    <?php
                    $profileComplete = !empty($user['username']) && !empty($user['phone']) && !empty($user['address']);
                    ?>
                    <span class="status-badge <?= $profileComplete ? 'bg-green-500 text-white' : 'bg-yellow-500 text-white' ?>">
                        <?= $profileComplete ? 'Lengkap' : 'Belum Lengkap' ?>
                    </span>
                </div>
                <p class="text-gray-600 dark:text-gray-300 text-lg">
                    <?php if ($profileComplete): ?>
                        <i class="fas fa-check-circle text-green-500 mr-2"></i>
                        Profil Anda sudah lengkap dan siap untuk bertransaksi!
                    <?php else: ?>
                        <i class="fas fa-exclamation-triangle text-yellow-500 mr-2"></i>
                        Profil Anda belum lengkap.
                        <a href="/profile/edit" class="text-blue-500 dark:text-blue-400 hover:underline font-semibold">Lengkapi sekarang</a>
                        untuk pengalaman yang lebih baik.
                    <?php endif; ?>
                </p>
            </div>

            <!-- Order History Chart -->
            <div class="glass-card mb-8 fade-in">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                        <i class="fas fa-chart-line mr-3 text-purple-500"></i>
                        Riwayat Pesanan
                    </h3>
                    <div class="flex space-x-2">
                        <button class="px-4 py-2 bg-white bg-opacity-20 rounded-lg text-sm font-medium hover:bg-opacity-30 transition-all duration-200">7 Hari</button>
                        <button class="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium">30 Hari</button>
                        <button class="px-4 py-2 bg-white bg-opacity-20 rounded-lg text-sm font-medium hover:bg-opacity-30 transition-all duration-200">90 Hari</button>
                    </div>
                </div>
                <div class="relative">
                    <canvas id="orderChart" height="100"></canvas>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="glass-card mb-8 fade-in">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                        <i class="fas fa-shopping-cart mr-3 text-green-500"></i>
                        Pesanan Terbaru
                    </h3>
                    <a href="/orders" class="text-blue-500 hover:text-blue-600 font-semibold transition-colors duration-200 flex items-center">
                        Lihat Semua <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
                <div class="overflow-hidden rounded-xl">
                    <div class="modern-table">
                        <table class="w-full text-left">
                            <thead class="bg-white bg-opacity-10">
                                <tr>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">ID Pesanan</th>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">Produk</th>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">Total</th>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">Status</th>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_orders as $order): ?>
                                    <tr class="border-b border-white border-opacity-10 hover:bg-white hover:bg-opacity-5 transition-all duration-200">
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200 font-medium">
                                            <span class="flex items-center">
                                                <span class="w-2 h-2 bg-blue-500 rounded-full mr-3 loading-pulse"></span>
                                                <?= esc($order['order_id']) ?>
                                            </span>
                                        </td>
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200"><?= esc($order['product_name']) ?></td>
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200 font-semibold">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></td>
                                        <td class="py-4 px-6">
                                            <span class="status-badge <?= $order['status'] === 'completed' ? 'bg-green-500 text-white' : ($order['status'] === 'pending' ? 'bg-yellow-500 text-white' : 'bg-red-500 text-white') ?>">
                                                <?= esc(ucfirst($order['status'])) ?>
                                            </span>
                                        </td>
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200"><?= date('d M Y H:i', strtotime($order['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($recent_orders)): ?>
                                    <tr>
                                        <td colspan="5" class="py-8 px-6 text-gray-600 dark:text-gray-300 text-center">
                                            <i class="fas fa-shopping-cart text-4xl mb-4 text-gray-400"></i>
                                            <p class="text-lg">Belum ada pesanan.</p>
                                            <a href="/products" class="text-blue-500 hover:underline">Mulai berbelanja sekarang!</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Cart Summary -->
            <div class="glass-card mb-8 fade-in">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                        <i class="fas fa-shopping-basket mr-3 text-orange-500"></i>
                        Keranjang Anda
                    </h3>
                    <a href="/cart" class="text-blue-500 hover:text-blue-600 font-semibold transition-colors duration-200 flex items-center">
                        Kelola Keranjang <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
                <div class="overflow-hidden rounded-xl">
                    <div class="modern-table">
                        <table class="w-full text-left">
                            <thead class="bg-white bg-opacity-10">
                                <tr>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">Produk</th>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">Jumlah</th>
                                    <th class="py-4 px-6 text-gray-600 dark:text-gray-300 font-semibold">Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $totalCart = 0; ?>
                                <?php foreach ($cart_items as $item): ?>
                                    <?php $subtotal = $item['quantity'] * $item['price'];
                                    $totalCart += $subtotal; ?>
                                    <tr class="border-b border-white border-opacity-10 hover:bg-white hover:bg-opacity-5 transition-all duration-200">
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200 font-medium"><?= esc($item['name']) ?></td>
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200">
                                            <span class="bg-blue-500 bg-opacity-20 px-3 py-1 rounded-full text-sm font-medium">
                                                <?= esc($item['quantity']) ?>x
                                            </span>
                                        </td>
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200 font-semibold">Rp <?= number_format($subtotal, 0, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($cart_items)): ?>
                                    <tr>
                                        <td colspan="3" class="py-8 px-6 text-gray-600 dark:text-gray-300 text-center">
                                            <i class="fas fa-shopping-cart text-4xl mb-4 text-gray-400"></i>
                                            <p class="text-lg">Keranjang kosong.</p>
                                            <a href="/products" class="text-blue-500 hover:underline">Tambahkan produk sekarang!</a>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <tr class="bg-white bg-opacity-10">
                                        <td colspan="2" class="py-4 px-6 text-gray-800 dark:text-gray-200 font-bold text-lg">Total</td>
                                        <td class="py-4 px-6 text-gray-800 dark:text-gray-200 font-bold text-lg">Rp <?= number_format($totalCart, 0, ',', '.') ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <?php if (!empty($cart_items)): ?>
                            <div class="p-6 text-right bg-white bg-opacity-5">
                                <a href="/cart/checkout" class="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-8 py-3 rounded-full hover:shadow-lg transition-all duration-300 font-semibold btn-animated inline-flex items-center">
                                    <i class="fas fa-credit-card mr-2"></i>
                                    Lanjut ke Checkout
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Wishlist -->
            <div class="glass-card mb-8 fade-in">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                        <i class="fas fa-heart mr-3 text-pink-500"></i>
                        Wishlist Anda
                    </h3>
                    <a href="/wishlist" class="text-blue-500 hover:text-blue-600 font-semibold transition-colors duration-200 flex items-center">
                        Lihat Semua <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($wishlist_items as $item): ?>
                        <div class="wishlist-card">
                            <div class="relative overflow-hidden">
                                <img src="<?= esc($item['image_url']) ?>" alt="<?= esc($item['name']) ?>" class="w-full h-48 object-cover">
                                <div class="absolute top-4 right-4">
                                    <button class="p-2 bg-white bg-opacity-20 backdrop-filter backdrop-blur-sm rounded-full text-white hover:bg-opacity-30 transition-all duration-200">
                                        <i class="fas fa-heart text-pink-500"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="p-6">
                                <h4 class="text-lg font-bold text-gray-800 dark:text-gray-200 mb-2"><?= esc($item['name']) ?></h4>
                                <p class="text-2xl font-bold gradient-text mb-4">Rp <?= number_format($item['price'], 0, ',', '.') ?></p>
                                <a href="/product/<?= esc($item['product_id']) ?>" class="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-3 px-4 rounded-xl font-semibold transition-all duration-300 btn-animated inline-flex items-center justify-center">
                                    <i class="fas fa-eye mr-2"></i>
                                    Lihat Produk
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($wishlist_items)): ?>
                        <div class="col-span-full text-center py-12">
                            <i class="fas fa-heart text-6xl text-gray-400 mb-4"></i>
                            <p class="text-xl text-gray-600 dark:text-gray-300 mb-4">Wishlist kosong.</p>
                            <a href="/products" class="text-blue-500 hover:underline font-semibold">Jelajahi produk menarik!</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Active Promotions -->
            <div class="glass-card fade-in">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-2xl font-semibold text-gray-800 dark:text-gray-200 flex items-center">
                        <i class="fas fa-fire mr-3 text-orange-500"></i>
                        Promo Aktif
                    </h3>
                    <a href="/promos" class="text-blue-500 hover:text-blue-600 font-semibold transition-colors duration-200 flex items-center">
                        Lihat Semua <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($active_promos as $promo): ?>
                        <div class="promo-card">
                            <div class="flex items-center justify-between mb-4">
                                <i class="fas fa-tags text-2xl"></i>
                                <span class="bg-white bg-opacity-20 px-3 py-1 rounded-full text-sm font-bold">
                                    <?php
                                    $discount = $promo['discount_type'] === 'percentage' ? "{$promo['discount_value']}% OFF" : "Rp " . number_format($promo['discount_value'], 0, ',', '.');
                                    echo $discount;
                                    ?>
                                </span>
                            </div>
                            <h4 class="text-xl font-bold mb-2"><?= esc($promo['code']) ?></h4>
                            <p class="text-white text-opacity-90 text-sm mb-4"><?= esc($promo['description'] ?? 'Diskon untuk pembelian') ?></p>
                            <div class="text-xs text-white text-opacity-70">
                                <p class="mb-1">
                                    <i class="fas fa-calendar mr-2"></i>
                                    Berlaku hingga: <?= date('d M Y', strtotime($promo['valid_until'])) ?>
                                </p>
                                <?php if ($promo['min_purchase']): ?>
                                    <p class="mb-1">
                                        <i class="fas fa-shopping-cart mr-2"></i>
                                        Min. Rp <?= number_format($promo['min_purchase'], 0, ',', '.') ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($promo['max_discount']): ?>
                                    <p>
                                        <i class="fas fa-star mr-2"></i>
                                        Maks. Rp <?= number_format($promo['max_discount'], 0, ',', '.') ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($active_promos)): ?>
                        <div class="col-span-full text-center py-12">
                            <i class="fas fa-tags text-6xl text-gray-400 mb-4"></i>
                            <p class="text-xl text-gray-600 dark:text-gray-300 mb-4">Tidak ada promo aktif saat ini.</p>
                            <p class="text-gray-500">Pantau terus untuk penawaran menarik!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <script>
            // Initialize animations and interactions
            document.addEventListener('DOMContentLoaded', function() {
                // Update current time
                function updateTime() {
                    const now = new Date();
                    const timeString = now.toLocaleString('id-ID', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                    });
                    document.getElementById('current-time').textContent = timeString;
                }
                updateTime();
                setInterval(updateTime, 1000);

                // Dropdown functionality
                const dropdownButton = document.querySelector('.dropdown button');
                const dropdownMenu = document.querySelector('.dropdown-menu');
                const dropdownIcon = document.getElementById('dropdown-icon');

                if (dropdownButton && dropdownMenu) {
                    dropdownButton.addEventListener('click', function(e) {
                        e.stopPropagation();
                        dropdownMenu.classList.toggle('active');
                        dropdownIcon.style.transform = dropdownMenu.classList.contains('active') ? 'rotate(180deg)' : 'rotate(0deg)';
                    });

                    document.addEventListener('click', function() {
                        dropdownMenu.classList.remove('active');
                        dropdownIcon.style.transform = 'rotate(0deg)';
                    });
                }

                // Fade in animations
                const observerOptions = {
                    threshold: 0.1,
                    rootMargin: '0px 0px -50px 0px'
                };

                const observer = new IntersectionObserver(function(entries) {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            entry.target.style.opacity = '1';
                            entry.target.style.transform = 'translateY(0)';
                        }
                    });
                }, observerOptions);

                document.querySelectorAll('.fade-in').forEach(el => {
                    observer.observe(el);
                });
            });

            // Dark Mode Toggle
            function toggleDarkMode() {
                const isDark = document.body.classList.toggle('dark');
                localStorage.setItem('darkMode', isDark ? 'enabled' : 'disabled');
                updateChartColors();

                // Smooth transition
                document.body.style.transition = 'all 0.3s ease';
                setTimeout(() => {
                    document.body.style.transition = '';
                }, 300);
            }

            if (localStorage.getItem('darkMode') === 'enabled') {
                document.body.classList.add('dark');
            }

            // Chart functionality
            function getChartColors() {
                const isDark = document.body.classList.contains('dark');
                return {
                    backgroundColor: isDark ? 'rgba(144, 205, 244, 0.2)' : 'rgba(102, 126, 234, 0.2)',
                    borderColor: isDark ? 'rgba(144, 205, 244, 1)' : 'rgba(102, 126, 234, 1)',
                    textColor: isDark ? '#e2e8f0' : '#374151',
                    gridColor: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                };
            }

            function updateChartColors() {
                if (typeof orderChart !== 'undefined') {
                    const colors = getChartColors();
                    orderChart.data.datasets[0].backgroundColor = colors.backgroundColor;
                    orderChart.data.datasets[0].borderColor = colors.borderColor;
                    orderChart.options.scales.x.ticks.color = colors.textColor;
                    orderChart.options.scales.y.ticks.color = colors.textColor;
                    orderChart.options.scales.x.grid.color = colors.gridColor;
                    orderChart.options.scales.y.grid.color = colors.gridColor;
                    orderChart.update();
                }
            }

            // Order History Chart
            const orderData = <?= json_encode($recent_orders) ?>;
            const orderMonths = [...new Set(orderData.map(item => new Date(item.created_at).toLocaleString('id-ID', {
                year: 'numeric',
                month: 'short'
            })))];
            const orderCounts = orderMonths.map(month =>
                orderData.filter(item => new Date(item.created_at).toLocaleString('id-ID', {
                    year: 'numeric',
                    month: 'short'
                }) === month).length
            );

            const orderCtx = document.getElementById('orderChart').getContext('2d');
            const colors = getChartColors();

            const orderChart = new Chart(orderCtx, {
                type: 'line',
                data: {
                    labels: orderMonths,
                    datasets: [{
                        label: 'Jumlah Pesanan',
                        data: orderCounts,
                        backgroundColor: colors.backgroundColor,
                        borderColor: colors.borderColor,
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: colors.borderColor,
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 6,
                        pointHoverRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        x: {
                            ticks: {
                                color: colors.textColor,
                                font: {
                                    family: 'Inter',
                                    size: 12
                                }
                            },
                            grid: {
                                color: colors.gridColor,
                                drawBorder: false
                            }
                        },
                        y: {
                            ticks: {
                                color: colors.textColor,
                                beginAtZero: true,
                                stepSize: 1,
                                font: {
                                    family: 'Inter',
                                    size: 12
                                }
                            },
                            grid: {
                                color: colors.gridColor,
                                drawBorder: false
                            }
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    }
                }
            });

            // Update chart on load
            updateChartColors();
        </script>
    </body>

    </html> -->