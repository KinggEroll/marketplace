<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Laporan Penjualan - DigiDaw') ?></title>
    <link href="/assets/tailwind.min.css" rel="stylesheet" onerror="this.href='https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css'">
    <link href="/assets/fontawesome.min.css" rel="stylesheet" onerror="this.href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'">
    <link href="/assets/sweetalert2.min.css" rel="stylesheet" onerror="this.href='https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css'">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="/assets/sweetalert2.min.js" onerror="this.src='https://cdn.jsdelivr.net/npm/sweetalert2@11'"></script>
    <script src="/assets/chart.umd.min.js" onerror="this.src='https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js'"></script>
    <style>
        * {
            font-family: 'Inter', sans-serif;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            overflow-x: hidden;
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 100%);
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .sidebar-hidden {
            transform: translateX(-100%);
        }

        .sidebar.show {
            transform: translateX(0);
        }

        .sidebar-brand {
            padding: 2rem 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item {
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(4px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.25rem;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.2s ease;
        }

        .nav-item:hover .nav-link,
        .nav-item.active .nav-link {
            color: white;
        }

        .nav-icon {
            width: 20px;
            height: 20px;
            margin-right: 12px;
        }

        .notification-badge {
            position: absolute;
            top: 8px;
            right: 12px;
            background: #ef4444;
            color: white;
            font-size: 0.75rem;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.1);
            }

            100% {
                transform: scale(1);
            }
        }

        .content {
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
            transition: margin-left 0.3s ease;
        }

        .content.full-width {
            margin-left: 0;
        }

        .page-header {
            margin-bottom: 2rem;
        }

        .page-title {
            font-size: 2.25rem;
            font-weight: 700;
            color: white;
            letter-spacing: -0.025em;
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.85);
            font-size: 1rem;
            font-weight: 400;
        }

        .card {
            background: rgba(255, 255, 255, 0.97);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease;
        }

        .card:hover {
            transform: translateY(-4px);
        }

        .report-card {
            background: white;
            border-radius: 12px;
            padding: 1.25rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }

        .btn {
            padding: 0.6rem 1.2rem;
            border-radius: 8px;
            font-weight: 600;
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            color: white;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.2s ease;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .flash-message {
            padding: 1rem 1.5rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            font-weight: 500;
            border-left: 4px solid;
            animation: fadeIn 0.5s ease;
        }

        .flash-error {
            background: #fef2f2;
            color: #991b1b;
            border-left-color: #ef4444;
        }

        .flash-success {
            background: #ecfdf5;
            color: #065f46;
            border-left-color: #10b981;
        }

        .flash-info {
            background: #eff6ff;
            color: #1e40af;
            border-left-color: #3b82f6;
        }

        .chart-container {
            max-width: 100%;
            height: 350px;
            padding: 1rem;
            background: white;
            border-radius: 12px;
        }

        .date-picker,
        .filter-select {
            padding: 0.6rem;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.875rem;
            background: white;
            transition: all 0.2s ease;
        }

        .date-picker:focus,
        .filter-select:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .loading-spinner {
            display: inline-block;
            width: 24px;
            height: 24px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: #3b82f6;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
            }

            .page-title {
                font-size: 1.75rem;
            }

            .chart-container {
                height: 300px;
            }
        }

        @media (max-width: 640px) {
            .content {
                padding: 1rem;
            }

            .card {
                padding: 1rem;
            }

            .page-title {
                font-size: 1.5rem;
            }

            .page-subtitle {
                font-size: 0.875rem;
            }

            .report-card {
                padding: 0.75rem;
            }

            .chart-container {
                height: 250px;
            }

            .date-picker,
            .filter-select {
                width: 100%;
                margin-bottom: 0.5rem;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>

<body>
    <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar lg:block">
        <div class="sidebar-brand">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mr-3">
                    <i class="fas fa-store text-white text-lg"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-white">DigiDaw</h2>
                    <p class="text-blue-200 text-sm">Seller Dashboard</p>
                </div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="/seller/dashboard" class="nav-link">
                    <i class="fas fa-tachometer-alt nav-icon"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/products' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-box nav-icon"></i>
                    Produk
                </a>
            </div>
            <div class="nav-item">
                <a href="/seller/orders" class="nav-link">
                    <i class="fas fa-shopping-cart nav-icon"></i>
                    Pesanan
                    <?php if (isset($newOrders) && $newOrders > 0): ?>
                        <span class="notification-badge"><?= esc($newOrders > 99 ? '99+' : $newOrders) ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item active">
                <a href="/seller/reports" class="nav-link">
                    <i class="fas fa-chart-bar nav-icon"></i>
                    Laporan
                </a>
            </div>
            <div class="nav-item">
                <a href="/seller/profile" class="nav-link">
                    <i class="fas fa-user nav-icon"></i>
                    Profil
                </a>
            </div>
            <div class="nav-item" style="margin-top: 2rem;">
                <a href="/auth/logout" class="nav-link" style="color: #fca5a5;">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    Logout
                </a>
            </div>
        </nav>
    </div>
    <!-- Content -->
    <div class="content" id="content">
        <!-- Mobile Menu Button -->
        <button id="mobile-menu-btn" class="lg:hidden fixed top-4 left-4 z-50 bg-white bg-opacity-20 text-white p-2 rounded-lg">
            <i class="fas fa-bars text-lg"></i>
        </button>
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Laporan Penjualan</h1>
            <p class="page-subtitle">Analisis performa penjualan Anda dengan mudah</p>
        </div>
        <!-- Flash Messages -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="flash-message flash-error">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= esc(session()->getFlashdata('error')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="flash-message flash-success">
                <i class="fas fa-check-circle mr-2"></i>
                <?= esc(session()->getFlashdata('success')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('info')): ?>
            <div class="flash-message flash-info">
                <i class="fas fa-info-circle mr-2"></i>
                <?= esc(session()->getFlashdata('info')) ?>
            </div>
        <?php endif; ?>
        <!-- Verification Status -->
        <?php if ($needsVerification): ?>
            <div class="card">
                <div class="flex items-start justify-between">
                    <div class="flex items-center">
                        <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                            <?php if ($verificationStatus === 'pending'): ?>
                                <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                            <?php else: ?>
                                <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                            <?php if ($verificationStatus === 'pending'): ?>
                                <p class="text-yellow-700 font-semibold">⏳ Verifikasi akun Anda sedang diproses. Tunggu persetujuan admin.</p>
                            <?php elseif ($verificationStatus === 'rejected'): ?>
                                <p class="text-red-700 font-semibold">❌ Verifikasi ditolak. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Upload ulang verifikasi</a></p>
                            <?php else: ?>
                                <p class="text-red-700 font-semibold">⚠️ Akun belum diverifikasi. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Verifikasi sekarang</a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($verificationStatus !== 'pending'): ?>
                        <a href="/seller/verify" class="btn btn-primary">
                            <i class="fas fa-camera"></i>
                            Verifikasi
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                        <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                        <p class="text-green-700 font-semibold">✅ Akun Anda sudah diverifikasi. Selamat berjualan!</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Sales Chart -->
        <div class="card">
            <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-chart-line text-blue-600 mr-2"></i>
                    Grafik Penjualan
                </h2>
                <div class="flex flex-col sm:flex-row items-start sm:items-center gap-2 mt-3 sm:mt-0">
                    <select id="chartFilter" class="filter-select">
                        <option value="weekly">Mingguan</option>
                        <option value="monthly">Bulanan</option>
                        <option value="yearly" selected>Tahunan</option>
                    </select>
                    <input type="date" id="startDate" class="date-picker" value="<?= date('Y-m-d', strtotime('-1 year')) ?>">
                    <input type="date" id="endDate" class="date-picker" value="<?= date('Y-m-d') ?>">
                    <button onclick="exportReport()" class="btn btn-primary">
                        <i class="fas fa-print"></i>
                        Cetak PDF
                    </button>
                </div>
            </div>
            <div class="chart-container">
                <canvas id="salesChart"></canvas>
            </div>
        </div>
        <!-- Sales List -->
        <div class="card">
            <h2 class="text-xl font-bold text-gray-800 flex items-center mb-4">
                <i class="fas fa-table text-blue-600 mr-2"></i>
                Daftar Penjualan
            </h2>
            <?php if (empty($reports)): ?>
                <div class="text-center py-8">
                    <i class="fas fa-chart-bar text-gray-300 text-5xl mb-3"></i>
                    <p class="text-gray-500 text-base">Belum ada data penjualan</p>
                    <p class="text-gray-400 text-sm">Data penjualan akan muncul di sini setelah ada transaksi</p>
                </div>
            <?php else: ?>
                <div class="space-y-2">
                    <?php foreach ($reports as $report): ?>
                        <div class="report-card">
                            <div class="flex items-start justify-between mb-2">
                                <div>
                                    <h3 class="font-semibold text-base text-gray-800">Order #<?= esc($report['order_id']) ?></h3>
                                    <p class="text-sm text-gray-600"><i class="fas fa-user mr-1"></i><?= esc($report['buyer_name']) ?></p>
                                    <p class="text-sm text-gray-600"><i class="fas fa-clock mr-1"></i><?= date('d M Y H:i', strtotime($report['created_at'])) ?></p>
                                </div>
                                <div class="text-right">
                                    <p class="text-lg font-bold text-green-600">Rp <?= number_format($report['total_price'], 0, ',', '.') ?></p>
                                    <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full"><?= ucfirst(esc($report['status'])) ?></span>
                                </div>
                            </div>
                            <?php if (!empty($report['items'])): ?>
                                <div class="border-t border-gray-100 pt-2">
                                    <h4 class="font-medium text-sm text-gray-700 mb-1">Item:</h4>
                                    <?php foreach ($report['items'] as $item): ?>
                                        <div class="flex justify-between text-sm text-gray-600 mb-1">
                                            <span><?= esc($item['quantity'] ?? 1) ?>x <?= esc($item['product_name'] ?? 'Produk') ?></span>
                                            <span>Rp <?= number_format($item['subtotal'] ?? ($item['price'] * ($item['quantity'] ?? 1)), 0, ',', '.') ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <script>
        // Sidebar Toggle
        const sidebar = document.getElementById('sidebar');
        const content = document.getElementById('content');
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');

        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
            sidebar.classList.toggle('sidebar-hidden');
            content.classList.toggle('full-width');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (window.innerWidth < 1024 && !sidebar.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
                sidebar.classList.remove('show');
                sidebar.classList.add('sidebar-hidden');
                content.classList.add('full-width');
            }
        });

        // Verification Alert
        function showVerificationAlert() {
            Swal.fire({
                icon: 'warning',
                title: 'Belum Diverifikasi',
                text: 'Akun Anda belum diverifikasi. Verifikasi diperlukan untuk mengakses fitur ini.',
                confirmButtonText: 'Verifikasi Sekarang',
                showCancelButton: true,
                cancelButtonText: 'Nanti',
                confirmButtonColor: '#3b82f6',
                cancelButtonColor: '#ef4444'
            }).then(result => {
                if (result.isConfirmed) {
                    window.location.href = '/seller/verify';
                }
            });
        }

        // Export Report (PDF)
        function exportReport() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            if (!startDate || !endDate) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Peringatan',
                    text: 'Harap pilih tanggal mulai dan akhir.',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            if (new Date(startDate) > new Date(endDate)) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Peringatan',
                    text: 'Tanggal mulai tidak boleh lebih besar dari tanggal akhir.',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            window.location.href = `/seller/reports/export?start_date=${startDate}&end_date=${endDate}`;
        }

        // Update Chart
        let salesChart;

        function updateChart(period) {
            const validPeriods = ['weekly', 'monthly', 'yearly'];
            if (!validPeriods.includes(period)) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Periode tidak valid.',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            const chartArea = document.getElementById('salesChart').parentElement;
            chartArea.innerHTML = '<div class="text-center py-4"><div class="loading-spinner mx-auto"></div><p class="text-gray-500 mt-2">Memuat data...</p></div>';
            fetch(`/seller/reports/data?period=${period}`, {
                    method: 'GET',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': document.querySelector('input[name="<?= csrf_token() ?>"]').value
                    }
                })
                .then(response => {
                    console.log('Fetch response status:', response.status);
                    if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                    return response.json();
                })
                .then(data => {
                    console.log('Chart data:', data);
                    if (data.status === 'error') throw new Error(data.message);
                    chartArea.innerHTML = '<canvas id="salesChart"></canvas>';
                    const ctx = document.getElementById('salesChart').getContext('2d');
                    if (salesChart) salesChart.destroy();
                    salesChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: data.labels || ['No Data'],
                            datasets: [{
                                label: 'Penjualan (Rp)',
                                data: data.data || [0],
                                borderColor: '#3b82f6',
                                backgroundColor: 'rgba(59, 130, 246, 0.2)',
                                fill: true,
                                tension: 0.4,
                                pointBackgroundColor: '#3b82f6',
                                pointBorderColor: '#ffffff',
                                pointBorderWidth: 2,
                                pointRadius: 4
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        callback: function(value) {
                                            return 'Rp ' + value.toLocaleString('id-ID');
                                        },
                                        font: {
                                            size: 12
                                        }
                                    },
                                    grid: {
                                        color: 'rgba(0, 0, 0, 0.05)'
                                    }
                                },
                                x: {
                                    ticks: {
                                        font: {
                                            size: 12
                                        }
                                    },
                                    grid: {
                                        display: false
                                    }
                                }
                            },
                            plugins: {
                                legend: {
                                    display: false
                                },
                                tooltip: {
                                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                                    titleFont: {
                                        size: 14
                                    },
                                    bodyFont: {
                                        size: 12
                                    },
                                    callbacks: {
                                        label: function(context) {
                                            return 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                                        }
                                    }
                                }
                            },
                            animation: {
                                duration: 1000,
                                easing: 'easeOutQuart'
                            }
                        }
                    });
                })
                .catch(error => {
                    console.error('Chart Error:', error.message);
                    chartArea.innerHTML = '<div class="text-center py-6"><i class="fas fa-exclamation-circle text-red-500 text-3xl mb-2"></i><p class="text-gray-500">Gagal memuat grafik</p></div>';
                    let errorMessage = 'Gagal memuat data grafik.';
                    if (error.message.includes('401')) errorMessage = 'Sesi habis. Silakan login ulang.';
                    else if (error.message.includes('403')) errorMessage = 'Akun Anda belum diverifikasi.';
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: errorMessage,
                        timer: 2000,
                        showConfirmButton: false
                    });
                    if (error.message.includes('401')) setTimeout(() => window.location.href = '/auth/login', 2000);
                    else if (error.message.includes('403')) setTimeout(() => window.location.href = '/seller/verify', 2000);
                });
        }

        // Initialize Chart
        function initChart() {
            const ctx = document.getElementById('salesChart').getContext('2d');
            const initialData = <?= json_encode($chartData ?? ['labels' => [date('Y')], 'data' => [0]]) ?>;
            console.log('Initial chart data:', initialData);
            salesChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: initialData.labels.length ? initialData.labels : ['No Data'],
                    datasets: [{
                        label: 'Penjualan (Rp)',
                        data: initialData.data.length ? initialData.data : [0],
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.2)',
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#3b82f6',
                        pointBorderColor: '#ffffff',
                        pointBorderWidth: 2,
                        pointRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'Rp ' + value.toLocaleString('id-ID');
                                },
                                font: {
                                    size: 12
                                }
                            },
                            grid: {
                                color: 'rgba(0, 0, 0, 0.05)'
                            }
                        },
                        x: {
                            ticks: {
                                font: {
                                    size: 12
                                }
                            },
                            grid: {
                                display: false
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                            titleFont: {
                                size: 14
                            },
                            bodyFont: {
                                size: 12
                            },
                            callbacks: {
                                label: function(context) {
                                    return 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                                }
                            }
                        }
                    },
                    animation: {
                        duration: 1000,
                        easing: 'easeOutQuart'
                    }
                }
            });
        }

        // Initialize on Page Load
        document.addEventListener('DOMContentLoaded', () => {
            initChart();
            document.getElementById('chartFilter').addEventListener('change', (e) => {
                console.log('Chart filter changed to:', e.target.value);
                updateChart(e.target.value);
            });
            document.querySelectorAll('.flash-message').forEach(msg => {
                setTimeout(() => {
                    msg.style.opacity = '0';
                    setTimeout(() => msg.remove(), 300);
                }, 5000);
            });
        });
    </script>
</body>

</html>