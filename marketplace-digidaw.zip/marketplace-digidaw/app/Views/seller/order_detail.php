<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Detail Pesanan - DigiDaw') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* Reuse the same styles as seller/orders.php */
        * {
            font-family: 'Inter', sans-serif;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 100%);
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .sidebar-hidden {
            transform: translateX(-100%);
        }

        .sidebar.show {
            transform: translateX(0);
        }

        .sidebar-brand {
            padding: 2rem 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item {
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(4px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.25rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-item:hover .nav-link,
        .nav-item.active .nav-link {
            color: white;
        }

        .nav-icon {
            width: 20px;
            height: 20px;
            margin-right: 12px;
            opacity: 0.8;
        }

        .nav-item:hover .nav-icon,
        .nav-item.active .nav-icon {
            opacity: 1;
        }

        .notification-badge {
            position: absolute;
            top: 8px;
            right: 12px;
            background: #ef4444;
            color: white;
            font-size: 0.75rem;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }

        .content {
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
            transition: margin-left 0.3s ease;
        }

        .page-header {
            margin-bottom: 2rem;
        }

        .page-title {
            font-size: 2.25rem;
            font-weight: 700;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 0.5rem;
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1rem;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 600;
            text-transform: capitalize;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .status-paid {
            background: #dbeafe;
            color: #1e40af;
        }

        .status-delivered {
            background: #e0e7ff;
            color: #5b21b6;
        }

        .status-completed {
            background: #d1fae5;
            color: #065f46;
        }

        .status-cancelled {
            background: #fecaca;
            color: #991b1b;
        }

        .btn {
            padding: 0.75rem 1.25rem;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
            background: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background: #e2e8f0;
        }

        .flash-message {
            padding: 1rem 1.5rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            font-weight: 500;
            border-left: 4px solid;
            animation: flashFadeIn 0.5s ease;
        }

        @keyframes flashFadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .flash-error {
            background: #fef2f2;
            color: #991b1b;
            border-left-color: #ef4444;
        }

        .flash-success {
            background: #ecfdf5;
            color: #065f46;
            border-left-color: #10b981;
        }

        .flash-info {
            background: #eff6ff;
            color: #1e40af;
            border-left-color: #3b82f6;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 16px;
            padding: 1.5rem;
            width: 90%;
            max-width: 800px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        }

        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .content {
                margin-left: 0;
            }

            .page-title {
                font-size: 1.75rem;
            }
        }

        @media (max-width: 640px) {
            .content {
                padding: 1rem;
            }

            .card {
                padding: 1rem;
            }

            .page-title {
                font-size: 1.5rem;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar sidebar-hidden lg:sidebar">
        <div class="sidebar-brand">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mr-3">
                    <i class="fas fa-store text-white text-lg"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-white">DigiDaw</h2>
                    <p class="text-blue-200 text-sm">Seller Dashboard</p>
                </div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="/seller/dashboard" class="nav-link">
                    <i class="fas fa-tachometer-alt nav-icon"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/products' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-box nav-icon"></i>
                    Produk
                </a>
            </div>
            <div class="nav-item active">
                <a href="/seller/orders" class="nav-link">
                    <i class="fas fa-shopping-cart nav-icon"></i>
                    Pesanan
                    <?php if (isset($newOrders) && $newOrders > 0): ?>
                        <span class="notification-badge"><?= $newOrders > 99 ? '99+' : $newOrders ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/reports' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-chart-bar nav-icon"></i>
                    Laporan
                </a>
            </div>
            <div class="nav-item">
                <a href="/seller/profile" class="nav-link">
                    <i class="fas fa-user nav-icon"></i>
                    Profil
                </a>
            </div>
            <div class="nav-item" style="margin-top: 2rem;">
                <a href="/auth/logout" class="nav-link" style="color: #fca5a5;">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    Logout
                </a>
            </div>
        </nav>
    </div>
    <!-- Content -->
    <div class="content">
        <!-- Mobile Menu Button -->
        <button id="mobile-menu-btn" class="lg:hidden fixed top-4 left-4 z-50 bg-white bg-opacity-20 backdrop-blur-lg text-white p-3 rounded-xl">
            <i class="fas fa-bars"></i>
        </button>
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Detail Pesanan</h1>
            <p class="page-subtitle">Informasi lengkap pesanan #<?= esc($order['order_id']) ?></p>
        </div>
        <!-- Flash Messages -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="flash-message flash-error">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= esc(session()->getFlashdata('error')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="flash-message flash-success">
                <i class="fas fa-check-circle mr-2"></i>
                <?= esc(session()->getFlashdata('success')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('info')): ?>
            <div class="flash-message flash-info">
                <i class="fas fa-info-circle mr-2"></i>
                <?= esc(session()->getFlashdata('info')) ?>
            </div>
        <?php endif; ?>
        <!-- Verification Status -->
        <?php if ($needsVerification): ?>
            <div class="card">
                <div class="flex items-start justify-between">
                    <div class="flex items-center">
                        <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                            <?php if ($verificationStatus === 'pending'): ?>
                                <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                            <?php else: ?>
                                <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                            <?php if ($verificationStatus === 'pending'): ?>
                                <p class="text-yellow-700 font-semibold">⏳ Verifikasi akun Anda sedang diproses. Tunggu persetujuan admin.</p>
                            <?php elseif ($verificationStatus === 'rejected'): ?>
                                <p class="text-red-700 font-semibold">❌ Verifikasi ditolak. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Upload ulang verifikasi</a></p>
                            <?php else: ?>
                                <p class="text-red-700 font-semibold">⚠️ Akun belum diverifikasi. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Verifikasi sekarang</a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($verificationStatus !== 'pending'): ?>
                        <a href="/seller/verify" class="btn btn-primary">
                            <i class="fas fa-camera"></i>
                            Verifikasi
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                        <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                        <p class="text-green-700 font-semibold">✅ Akun Anda sudah diverifikasi. Selamat berjualan!</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Order Details -->
        <div class="card">
            <div class="flex items-start justify-between mb-4">
                <div>
                    <h2 class="text-xl font-bold text-gray-800">Pesanan #<?= esc($order['order_id']) ?></h2>
                    <p class="text-sm text-gray-600"><i class="fas fa-user mr-1"></i>Pembeli: <?= esc($order['buyer_name']) ?></p>
                    <p class="text-sm text-gray-600"><i class="fas fa-clock mr-1"></i>Tanggal: <?= date('d M Y H:i', strtotime($order['created_at'])) ?></p>
                    <p class="text-sm text-gray-600"><i class="fas fa-credit-card mr-1"></i>Metode Pembayaran: <?= esc($order['payment_method'] ?? 'Belum dibayar') ?></p>
                </div>
                <div class="text-right">
                    <p class="text-xl font-bold text-blue-600">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></p>
                    <span class="status-badge status-<?= esc($order['status']) ?>"><?= ucfirst(esc($order['status'])) ?></span>
                </div>
            </div>
            <div class="mb-4">
                <h3 class="font-semibold text-gray-800 mb-2">Item Pesanan</h3>
                <div class="space-y-2">
                    <?php foreach ($order['items'] as $item): ?>
                        <div class="flex justify-between items-center border-b border-gray-100 pb-2">
                            <div>
                                <p class="font-medium text-gray-700"><?= esc($item['product_name'] ?? 'Produk') ?></p>
                                <p class="text-sm text-gray-500">Kuantitas: <?= esc($item['quantity'] ?? 1) ?></p>
                            </div>
                            <p class="text-gray-700">Rp <?= number_format($item['subtotal'] ?? $item['price'] ?? 0, 0, ',', '.') ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="flex items-center justify-start pt-2 border-t border-gray-100">
                <select id="statusSelect" class="status-select px-3 py-1.5 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm" data-order-id="<?= $order['order_id'] ?>" data-original-status="<?= esc($order['status']) ?>">
                    <option value="pending" <?= $order['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="paid" <?= $order['status'] === 'paid' ? 'selected' : '' ?>>Paid</option>
                    <option value="delivered" <?= $order['status'] === 'delivered' ? 'selected' : '' ?>>Delivered</option>
                    <option value="completed" <?= $order['status'] === 'completed' ? 'selected' : '' ?>>Completed</option>
                    <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
            </div>
        </div>
    </div>
    <script>
        // Sidebar toggle for mobile
        document.getElementById('mobile-menu-btn').addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('show');
        });

        // Status update
        document.getElementById('statusSelect').addEventListener('change', function() {
            const orderId = this.dataset.orderId;
            const status = this.value;
            const selectElement = this;
            const originalStatus = this.dataset.originalStatus;
            selectElement.disabled = true;

            fetch(`/seller/orders/updateStatus/${orderId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': document.querySelector('input[name="<?= csrf_token() ?>"]').value
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    selectElement.disabled = false;
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil',
                            text: 'Status pesanan diperbarui',
                            timer: 1500,
                            showConfirmButton: false
                        });
                        const badge = document.querySelector('.status-badge');
                        badge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
                        badge.className = `status-badge status-${status}`;
                        selectElement.dataset.originalStatus = status; // Update original status
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: data.message || 'Gagal memperbarui status.',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        selectElement.value = originalStatus;
                    }
                })
                .catch(error => {
                    selectElement.disabled = false;
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Gagal memperbarui status. Coba lagi nanti.',
                        timer: 2000,
                        showConfirmButton: false
                    });
                    selectElement.value = originalStatus;
                    console.error('Error updating status:', error);
                });
        });

        // Verification alert
        function showVerificationAlert() {
            Swal.fire({
                icon: 'warning',
                title: 'Belum Diverifikasi',
                text: 'Akun Anda belum diverifikasi. Verifikasi diperlukan untuk mengakses fitur ini.',
                confirmButtonText: 'Verifikasi Sekarang',
                showCancelButton: true,
                cancelButtonText: 'Nanti',
                confirmButtonColor: '#3b82f6',
                cancelButtonColor: '#ef4444'
            }).then(result => {
                if (result.isConfirmed) {
                    window.location.href = '/seller/verify';
                }
            });
        }

        // Auto-hide flash messages
        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(msg => {
                msg.style.transition = 'opacity 0.3s, transform 0.3s';
                msg.style.opacity = '0';
                msg.style.transform = 'translateY(-10px)';
                setTimeout(() => msg.remove(), 300);
            });
        }, 5000);
    </script>
</body>

</html>