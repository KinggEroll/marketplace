<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk - DigiDaw</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 100%);
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            z-index: 1000;
            animation: fadeInSidebar 0.5s ease;
        }

        .sidebar-hidden {
            transform: translateX(-100%);
        }

        @keyframes fadeInSidebar {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .sidebar-brand {
            padding: 2rem 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item {
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(4px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.25rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-item:hover .nav-link,
        .nav-item.active .nav-link {
            color: white;
        }

        .nav-icon {
            width: 20px;
            height: 20px;
            margin-right: 12px;
            opacity: 0.8;
        }

        .nav-item:hover .nav-icon,
        .nav-item.active .nav-icon {
            opacity: 1;
        }

        .notification-badge {
            position: absolute;
            top: 8px;
            right: 12px;
            background: #ef4444;
            color: white;
            font-size: 0.75rem;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        .content {
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
            transition: margin-left 0.3s ease;
            animation: fadeInContent 0.5s ease;
        }

        @keyframes fadeInContent {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .page-header {
            margin-bottom: 2rem;
        }

        .page-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 0.5rem;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1rem;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            animation: cardFadeIn 0.5s ease backwards;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
        }

        .btn-secondary {
            background: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background: #e2e8f0;
        }

        .flash-message {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            font-weight: 500;
            border-left: 4px solid;
            animation: flashFadeIn 0.5s ease;
        }

        @keyframes flashFadeIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .flash-error {
            background: #fef2f2;
            color: #991b1b;
            border-left-color: #ef4444;
        }

        .flash-success {
            background: #ecfdf5;
            color: #065f46;
            border-left-color: #10b981;
        }

        .flash-info {
            background: #eff6ff;
            color: #1e40af;
            border-left-color: #3b82f6;
        }

        .product-image-preview {
            max-width: 100px;
            max-height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
            }

            .page-title {
                font-size: 2rem;
            }
        }

        @media (max-width: 640px) {
            .content {
                padding: 1rem;
            }

            .card {
                padding: 1.5rem;
            }

            .page-title {
                font-size: 1.75rem;
            }
        }

        @keyframes pulse {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.5;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div class="sidebar-brand">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mr-3">
                    <i class="fas fa-store text-white text-lg"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-white">DigiDaw</h2>
                    <p class="text-blue-200 text-sm">Seller Dashboard</p>
                </div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="/seller/dashboard" class="nav-link">
                    <i class="fas fa-tachometer-alt nav-icon"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item mb-2 active">
                <a href="/seller/products" class="nav-link flex items-center text-white p-3 rounded-xl bg-white bg-opacity-20">
                    <i class="fas fa-box nav-icon mr-3"></i>
                    Produk
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/orders' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-shopping-cart nav-icon"></i>
                    Pesanan
                    <?php if (isset($newOrders) && $newOrders > 0): ?>
                        <span class="notification-badge"><?= $newOrders > 99 ? '99+' : $newOrders ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/reports' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-chart-bar nav-icon"></i>
                    Laporan
                </a>
            </div>
            <div class="nav-item">
                <a href="/seller/profile" class="nav-link">
                    <i class="fas fa-user nav-icon"></i>
                    Profil
                </a>
            </div>
            <div class="nav-item" style="margin-top: 2rem;">
                <a href="/auth/logout" class="nav-link" style="color: #fca5a5;">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    Logout
                </a>
            </div>
        </nav>
    </div>
    <!-- Content -->
    <div class="content">
        <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">
        <!-- Mobile Menu Button -->
        <button id="mobile-menu-btn" class="lg:hidden fixed top-4 left-4 z-50 bg-white bg-opacity-20 backdrop-blur-lg text-white p-3 rounded-xl" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Tambah Produk</h1>
            <p class="page-subtitle">Tambahkan produk baru untuk mulai berjualan</p>
        </div>
        <!-- Flash Messages -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="flash-message flash-error">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= esc(session()->getFlashdata('error')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="flash-message flash-success">
                <i class="fas fa-check-circle mr-2"></i>
                <?= esc(session()->getFlashdata('success')) ?>
            </div>
        <?php endif; ?>
        <!-- Verification Status -->
        <?php if ($needsVerification): ?>
            <div class="verification-card card <?= $verificationStatus === 'pending' ? 'pending' : ($verificationStatus === 'rejected' ? 'rejected' : 'non-verified') ?>">
                <div class="flex items-start justify-between">
                    <div class="flex items-center">
                        <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                            <?php if ($verificationStatus === 'pending'): ?>
                                <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                            <?php else: ?>
                                <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                            <?php if ($verificationStatus === 'pending'): ?>
                                <p class="text-yellow-700 font-semibold">⏳ Verifikasi akun Anda sedang diproses. Tunggu persetujuan admin.</p>
                            <?php elseif ($verificationStatus === 'rejected'): ?>
                                <p class="text-red-700 font-semibold">❌ Verifikasi ditolak. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Upload ulang verifikasi</a></p>
                            <?php else: ?>
                                <p class="text-red-700 font-semibold">⚠️ Akun belum diverifikasi. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Verifikasi sekarang</a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($verificationStatus !== 'pending'): ?>
                        <a href="/seller/verify" class="btn btn-primary">
                            <i class="fas fa-camera"></i>
                            Verifikasi
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                        <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                        <p class="text-green-700 font-semibold">✅ Akun Anda sudah diverifikasi. Selamat berjualan!</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Add Product Form -->
        <div class="card">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-2xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-box text-blue-600 mr-3"></i>
                    Tambah Produk Baru
                </h2>
                <a href="/seller/products" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i>
                    Kembali ke Produk
                </a>
            </div>
            <form id="addProductForm" action="/seller/products/store" method="POST" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Nama Produk</label>
                    <input type="text" name="name" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Kategori</label>
                    <select name="category_id" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                        <option value="">Pilih Kategori</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= esc($category['category_id']) ?>"><?= esc($category['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Harga (Rp)</label>
                    <input type="number" name="price" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" required min="0">
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Stok</label>
                    <input type="number" name="stock" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" required min="0">
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Deskripsi</label>
                    <textarea name="description" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" rows="4"></textarea>
                </div>
                <div class="mb-4">
                    <label class="block text-gray-700 font-semibold mb-2">Gambar Produk</label>
                    <input type="file" name="image" id="productImage" accept="image/*" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                    <img id="imagePreview" class="product-image-preview mt-2 hidden">
                </div>
                <div class="flex gap-3">
                    <button type="submit" class="btn btn-primary flex-1">
                        <i class="fas fa-save"></i>
                        Simpan
                    </button>
                    <a href="/seller/products" class="btn btn-secondary flex-1">
                        <i class="fas fa-times"></i>
                        Batal
                    </a>
                </div>
            </form>
        </div>
    </div>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('show');
        }

        function showVerificationAlert() {
            Swal.fire({
                icon: 'warning',
                title: 'Belum Diverifikasi',
                text: 'Akun Anda belum diverifikasi. Verifikasi diperlukan untuk mengakses fitur ini.',
                confirmButtonText: 'Verifikasi Sekarang',
                showCancelButton: true,
                cancelButtonText: 'Nanti',
                confirmButtonColor: '#3b82f6',
                cancelButtonColor: '#ef4444'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/seller/verify';
                }
            });
        }

        document.getElementById('productImage').addEventListener('change', function(e) {
            const preview = document.getElementById('imagePreview');
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.remove('hidden');
                };
                reader.readAsDataURL(file);
            } else {
                preview.classList.add('hidden');
            }
        });

        document.getElementById('addProductForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const form = this;
            const formData = new FormData(form);

            fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil',
                            text: 'Produk berhasil ditambahkan!',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => {
                            window.location.href = '/seller/products';
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: data.message || 'Gagal menambahkan produk.',
                            timer: 2000,
                            showConfirmButton: false
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Gagal menambahkan produk. Coba lagi nanti.',
                        timer: 2000,
                        showConfirmButton: false
                    });
                    console.error('Error adding product:', error);
                });
        });

        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(msg => {
                msg.style.opacity = '0';
                msg.style.transform = 'translateY(-10px)';
                setTimeout(() => msg.remove(), 300);
            });
        }, 5000);
    </script>
</body>

</html>