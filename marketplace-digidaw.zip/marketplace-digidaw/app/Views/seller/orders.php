<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Pesanan - DigiDaw') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        /* CSS tetap sama seperti sebelumnya */
        * {
            font-family: 'Inter', sans-serif;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            margin: 0;
            overflow-x: hidden;
        }

        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 100%);
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .sidebar-hidden {
            transform: translateX(-100%);
        }

        .sidebar.show {
            transform: translateX(0);
        }

        .sidebar-brand {
            padding: 2rem 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item {
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(4px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.25rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-item:hover .nav-link,
        .nav-item.active .nav-link {
            color: white;
        }

        .nav-icon {
            width: 20px;
            height: 20px;
            margin-right: 12px;
            opacity: 0.8;
        }

        .nav-item:hover .nav-icon,
        .nav-item.active .nav-icon {
            opacity: 1;
        }

        .notification-badge {
            position: absolute;
            top: 8px;
            right: 12px;
            background: #ef4444;
            color: white;
            font-size: 0.75rem;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }

        .content {
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
            transition: margin-left 0.3s ease;
        }

        .content.full-width {
            margin-left: 0;
        }

        .page-header {
            margin-bottom: 2rem;
        }

        .page-title {
            font-size: 2.25rem;
            font-weight: 700;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 0.5rem;
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1rem;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        }

        .order-card {
            background: white;
            border-radius: 12px;
            padding: 1.25rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border-left: 4px solid #3b82f6;
        }

        .order-card:hover {
            transform: translateX(4px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 600;
            text-transform: capitalize;
        }

        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }

        .status-paid {
            background: #dbeafe;
            color: #1e40af;
        }

        .status-delivered {
            background: #e0e7ff;
            color: #5b21b6;
        }

        .status-completed {
            background: #d1fae5;
            color: #065f46;
        }

        .status-cancelled {
            background: #fecaca;
            color: #991b1b;
        }

        .btn {
            padding: 0.75rem 1.25rem;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
        }

        .btn-secondary {
            background: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background: #e2e8f0;
        }

        .flash-message {
            padding: 1rem 1.5rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            font-weight: 500;
            border-left: 4px solid;
            animation: flashFadeIn 0.5s ease;
        }

        @keyframes flashFadeIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .flash-error {
            background: #fef2f2;
            color: #991b1b;
            border-left-color: #ef4444;
        }

        .flash-success {
            background: #ecfdf5;
            color: #065f46;
            border-left-color: #10b981;
        }

        .flash-info {
            background: #eff6ff;
            color: #1e40af;
            border-left-color: #3b82f6;
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 1.5rem;
        }

        .pagination a,
        .pagination span {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            color: #374151;
            background: #f1f5f9;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .pagination a:hover {
            background: #3b82f6;
            color: white;
        }

        .pagination .active {
            background: #3b82f6;
            color: white;
            font-weight: 600;
        }

        .pagination .disabled {
            color: #9ca3af;
            cursor: not-allowed;
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .content {
                margin-left: 0;
            }

            .page-title {
                font-size: 1.75rem;
            }
        }

        @media (max-width: 640px) {
            .content {
                padding: 1rem;
            }

            .card {
                padding: 1rem;
            }

            .page-title {
                font-size: 1.5rem;
            }

            .order-card {
                padding: 1rem;
            }
        }
    </style>
</head>

<body>
    <!-- CSRF Token -->
    <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div class="sidebar-brand">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mr-3">
                    <i class="fas fa-store text-white text-lg"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-white">DigiDaw</h2>
                    <p class="text-blue-200 text-sm">Seller Dashboard</p>
                </div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="/seller/dashboard" class="nav-link">
                    <i class="fas fa-tachometer-alt nav-icon"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/products' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-box nav-icon"></i>
                    Produk
                </a>
            </div>
            <div class="nav-item active">
                <a href="/seller/orders" class="nav-link">
                    <i class="fas fa-shopping-cart nav-icon"></i>
                    Pesanan
                    <?php if (isset($newOrders) && $newOrders > 0): ?>
                        <span class="notification-badge"><?= $newOrders > 99 ? '99+' : $newOrders ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/reports' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-chart-bar nav-icon"></i>
                    Laporan
                </a>
            </div>
            <div class="nav-item">
                <a href="/seller/profile" class="nav-link">
                    <i class="fas fa-user nav-icon"></i>
                    Profil
                </a>
            </div>
            <div class="nav-item" style="margin-top: 2rem;">
                <a href="/auth/logout" class="nav-link" style="color: #fca5a5;">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    Logout
                </a>
            </div>
        </nav>
    </div>
    <!-- Content -->
    <div class="content" id="content">
        <!-- Mobile Menu Button -->
        <button id="mobile-menu-btn" class="lg:hidden fixed top-4 left-4 z-50 bg-white bg-opacity-20 backdrop-blur-lg text-white p-3 rounded-xl">
            <i class="fas fa-bars"></i>
        </button>
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Pesanan</h1>
            <p class="page-subtitle">Kelola pesanan pelanggan Anda</p>
        </div>
        <!-- Flash Messages -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="flash-message flash-error">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= esc(session()->getFlashdata('error')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="flash-message flash-success">
                <i class="fas fa-check-circle mr-2"></i>
                <?= esc(session()->getFlashdata('success')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('info')): ?>
            <div class="flash-message flash-info">
                <i class="fas fa-info-circle mr-2"></i>
                <?= esc(session()->getFlashdata('info')) ?>
            </div>
        <?php endif; ?>
        <!-- Verification Status -->
        <?php if ($needsVerification): ?>
            <div class="card">
                <div class="flex items-start justify-between">
                    <div class="flex items-center">
                        <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                            <?php if ($verificationStatus === 'pending'): ?>
                                <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                            <?php else: ?>
                                <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                            <?php if ($verificationStatus === 'pending'): ?>
                                <p class="text-yellow-700 font-semibold">⏳ Verifikasi akun Anda sedang diproses. Tunggu persetujuan admin.</p>
                            <?php elseif ($verificationStatus === 'rejected'): ?>
                                <p class="text-red-700 font-semibold">❌ Verifikasi ditolak. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Upload ulang verifikasi</a></p>
                            <?php else: ?>
                                <p class="text-red-700 font-semibold">⚠️ Akun belum diverifikasi. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Verifikasi sekarang</a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($verificationStatus !== 'pending'): ?>
                        <a href="/seller/verify" class="btn btn-primary">
                            <i class="fas fa-camera"></i>
                            Verifikasi
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                        <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                        <p class="text-green-700 font-semibold">✅ Akun Anda sudah diverifikasi. Selamat berjualan!</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Orders List -->
        <div class="card">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-shopping-cart text-blue-600 mr-3"></i>
                    Daftar Pesanan
                </h2>
                <select id="statusFilter" class="px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" onchange="applyStatusFilter(this.value)">
                    <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>Semua Status</option>
                    <option value="pending" <?= $filter === 'pending' ? 'selected' : '' ?>>Pending</option>
                    <option value="paid" <?= $filter === 'paid' ? 'selected' : '' ?>>Paid</option>
                    <option value="delivered" <?= $filter === 'delivered' ? 'selected' : '' ?>>Delivered</option>
                    <option value="completed" <?= $filter === 'completed' ? 'selected' : '' ?>>Completed</option>
                    <option value="cancelled" <?= $filter === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
            </div>
            <?php if (empty($orders)): ?>
                <div class="text-center py-8">
                    <i class="fas fa-shopping-cart text-gray-300 text-5xl mb-3"></i>
                    <p class="text-gray-500 text-lg">Belum ada pesanan</p>
                    <p class="text-gray-400 mb-4">Pesanan akan muncul di sini setelah ada pembelian</p>
                </div>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($orders as $order): ?>
                        <div class="order-card">
                            <div class="flex items-start justify-between mb-3">
                                <div>
                                    <h3 class="font-semibold text-base text-gray-800">Order #<?= esc($order['order_id']) ?></h3>
                                    <p class="text-sm text-gray-600"><i class="fas fa-user mr-1"></i><?= esc($order['buyer_name']) ?></p>
                                </div>
                                <div class="text-right">
                                    <p class="text-xl font-bold text-blue-600">Rp <?= number_format($order['total_price'], 0, ',', '.') ?></p>
                                    <span class="status-badge status-<?= esc($order['status']) ?>"><?= ucfirst(esc($order['status'])) ?></span>
                                </div>
                            </div>
                            <?php if (!empty($order['items'])): ?>
                                <div class="mb-3">
                                    <h4 class="font-medium text-gray-700 text-sm mb-2">Item Pesanan:</h4>
                                    <?php foreach (array_slice($order['items'], 0, 2) as $item): ?>
                                        <div class="flex justify-between text-sm text-gray-600 mb-1">
                                            <span><?= esc($item['quantity'] ?? 1) ?>x <?= esc($item['product_name'] ?? 'Produk') ?></span>
                                            <span>Rp <?= number_format($item['subtotal'] ?? ($item['price'] * $item['quantity'] ?? 0), 0, ',', '.') ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                    <?php if (count($order['items']) > 2): ?>
                                        <p class="text-xs text-gray-500">+<?= count($order['items']) - 2 ?> item lainnya</p>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            <div class="flex items-center justify-between pt-2 border-t border-gray-100">
                                <span class="text-sm text-gray-500">
                                    <i class="fas fa-clock mr-1"></i>
                                    <?= date('d M Y H:i', strtotime($order['created_at'])) ?>
                                </span>
                                <div class="flex gap-2">
                                    <?php if ($order['status'] === 'pending'): ?>
                                        <button class="btn btn-primary" onclick="updateStatus(<?= $order['order_id'] ?>, 'paid')">Konfirmasi Pembayaran</button>
                                        <button class="btn btn-secondary" onclick="updateStatus(<?= $order['order_id'] ?>, 'cancelled')">Batalkan</button>
                                    <?php elseif ($order['status'] === 'paid'): ?>
                                        <button class="btn btn-primary" onclick="updateStatus(<?= $order['order_id'] ?>, 'delivered')">Tandai Terkirim</button>
                                    <?php elseif ($order['status'] === 'delivered'): ?>
                                        <button class="btn btn-primary" onclick="updateStatus(<?= $order['order_id'] ?>, 'completed')">Selesaikan Pesanan</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <!-- Pagination -->
                <?php if (isset($pager)): ?>
                    <div class="pagination">
                        <?= $pager->links() ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <script>
        // Sidebar toggle for mobile
        const sidebar = document.getElementById('sidebar');
        const content = document.getElementById('content');
        const mobileMenuBtn = document.getElementById('mobile-menu-btn');

        mobileMenuBtn.addEventListener('click', () => {
            sidebar.classList.toggle('show');
            content.classList.toggle('full-width');
        });

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (!sidebar.contains(e.target) && !mobileMenuBtn.contains(e.target) && sidebar.classList.contains('show')) {
                sidebar.classList.remove('show');
                content.classList.remove('full-width');
            }
        });

        // View order
        document.querySelectorAll('.btn-view-order').forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const orderId = this.getAttribute('href').split('/').pop();
                console.log('View button clicked for orderId:', orderId);
                console.log('Current URL:', window.location.href);
                console.log('Redirecting to /seller/orders/' + orderId);
                setTimeout(() => {
                    window.location.href = `/seller/orders/${orderId}`;
                }, 500); // Delay untuk memastikan log terlihat
            });
        });

        // Status update
        function updateStatus(orderId, status) {
            if (confirm(`Apakah Anda yakin ingin mengubah status pesanan #${orderId} menjadi ${status}?`)) {
                console.log('Updating status for orderId:', orderId, 'to:', status);
                const csrfToken = document.querySelector('input[name="<?= csrf_token() ?>"]').value;
                console.log('CSRF Token:', csrfToken);
                fetch(`/seller/orders/updateStatus/${orderId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            status: status
                        })
                    })
                    .then(response => {
                        console.log('Response status:', response.status);
                        if (!response.ok) {
                            throw new Error(`HTTP error! Status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        console.log('Response data:', data);
                        if (data.status === 'success') {
                            alert(data.message);
                            window.location.reload();
                        } else {
                            alert(data.message || 'Gagal memperbarui status.');
                        }
                    })
                    .catch(error => {
                        console.error('Error updating status:', error);
                        alert('Gagal memperbarui status: ' + error.message);
                    });
            }
        }

        // Apply status filter
        function applyStatusFilter(status) {
            window.location.href = `/seller/orders/${status}`;
        }

        // Verification alert
        function showVerificationAlert() {
            alert('Akun Anda belum diverifikasi. Verifikasi diperlukan untuk mengakses fitur ini.');
            window.location.href = '/seller/verify';
        }

        // Auto-hide flash messages
        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(msg => {
                msg.style.transition = 'opacity 0.3s, transform 0.3s';
                msg.style.opacity = '0';
                msg.style.transform = 'translateY(-10px)';
                setTimeout(() => msg.remove(), 300);
            });
        }, 5000);
    </script>
</body>

</html>