<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Produk - DigiDaw') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        * {
            font-family: 'Inter', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            overflow-x: hidden;
        }

        .glass-effect {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .sidebar {
            width: 280px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 100%);
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            z-index: 1000;
            animation: fadeInSidebar 0.5s ease;
        }

        .sidebar-hidden {
            transform: translateX(-100%);
        }

        @keyframes fadeInSidebar {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .sidebar-brand {
            padding: 2rem 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-nav {
            padding: 1rem 0;
        }

        .nav-item {
            margin: 0.25rem 1rem;
            border-radius: 12px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(4px);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 1rem 1.25rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .nav-item:hover .nav-link,
        .nav-item.active .nav-link {
            color: white;
        }

        .nav-icon {
            width: 20px;
            height: 20px;
            margin-right: 12px;
            opacity: 0.8;
        }

        .nav-item:hover .nav-icon,
        .nav-item.active .nav-icon {
            opacity: 1;
        }

        .notification-badge {
            position: absolute;
            top: 8px;
            right: 12px;
            background: #ef4444;
            color: white;
            font-size: 0.75rem;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
            animation: pulse 2s infinite;
        }

        .content {
            margin-left: 280px;
            padding: 2rem;
            min-height: 100vh;
            transition: margin-left 0.3s ease;
            animation: fadeInContent 0.5s ease;
        }

        @keyframes fadeInContent {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .page-header {
            margin-bottom: 2rem;
        }

        .page-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 0.5rem;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-20px);
                opacity: 0;
            }

            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .page-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 1.1rem;
        }

        .card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 20px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            animation: cardFadeIn 0.5s ease backwards;
        }

        .card:nth-child(1) {
            animation-delay: 0.1s;
        }

        .card:nth-child(2) {
            animation-delay: 0.2s;
        }

        .card:nth-child(3) {
            animation-delay: 0.3s;
        }

        @keyframes cardFadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15);
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .product-card {
            background: white;
            border-radius: 16px;
            padding: 1.5rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            border: 1px solid rgba(0, 0, 0, 0.05);
            animation: fadeInUp 0.5s ease backwards;
        }

        .product-card:nth-child(1) {
            animation-delay: 0.1s;
        }

        .product-card:nth-child(2) {
            animation-delay: 0.2s;
        }

        .product-card:nth-child(3) {
            animation-delay: 0.3s;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
        }

        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 600;
            text-transform: capitalize;
        }

        .status-active {
            background: #dbeafe;
            color: #1e40af;
        }

        .status-inactive {
            background: #fecaca;
            color: #991b1b;
        }

        .btn {
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(59, 130, 246, 0.4);
        }

        .btn-secondary {
            background: #f1f5f9;
            color: #475569;
        }

        .btn-secondary:hover {
            background: #e2e8f0;
        }

        .btn-danger {
            background: linear-gradient(135deg, #ef4444 0%, #b91c1c 100%);
            color: white;
        }

        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(239, 68, 68, 0.4);
        }

        .flash-message {
            padding: 1rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            font-weight: 500;
            border-left: 4px solid;
            animation: flashFadeIn 0.5s ease;
        }

        @keyframes flashFadeIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .flash-error {
            background: #fef2f2;
            color: #991b1b;
            border-left-color: #ef4444;
        }

        .flash-success {
            background: #ecfdf5;
            color: #065f46;
            border-left-color: #10b981;
        }

        .flash-info {
            background: #eff6ff;
            color: #1e40af;
            border-left-color: #3b82f6;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(4px);
            z-index: 2000;
            align-items: center;
            justify-content: center;
        }

        .modal.show {
            display: flex;
            animation: modalFadeIn 0.3s ease;
        }

        @keyframes modalFadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 2rem;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: modalSlideIn 0.3s ease;
        }

        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translateY(-20px) scale(0.95);
            }

            to {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
        }

        .chat-conversation {
            background: #f8fafc;
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 0.5rem;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid #e2e8f0;
        }

        .chat-conversation:hover {
            background: #e2e8f0;
            transform: translateX(4px);
        }

        .chat-conversation.active {
            background: #3b82f6;
            color: white;
        }

        .chat-area {
            background: #f8fafc;
            border-radius: 12px;
            padding: 1rem;
            height: 300px;
            overflow-y: auto;
            border: 1px solid #e2e8f0;
            animation: fadeIn 0.5s ease;
        }

        .message {
            margin-bottom: 1rem;
            padding: 0.75rem 1rem;
            border-radius: 12px;
            max-width: 70%;
            animation: slideInMessage 0.3s ease backwards;
        }

        .message.sent {
            background: #3b82f6;
            color: white;
            margin-left: auto;
            text-align: right;
        }

        .message.received {
            background: white;
            color: #374151;
            border: 1px solid #e5e7eb;
        }

        @keyframes slideInMessage {
            from {
                transform: translateX(20px);
                opacity: 0;
            }

            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 1.5rem;
        }

        .pagination a,
        .pagination span {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            color: #374151;
            background: #f1f5f9;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .pagination a:hover {
            background: #3b82f6;
            color: white;
        }

        .pagination .active {
            background: #3b82f6;
            color: white;
            font-weight: 600;
        }

        .pagination .disabled {
            color: #9ca3af;
            cursor: not-allowed;
        }

        .product-image-preview {
            max-width: 100px;
            max-height: 100px;
            object-fit: cover;
            border-radius: 8px;
        }

        .loading-spinner {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
        }

        @keyframes spin {
            to {
                transform: rotate(360deg);
            }
        }

        @media (max-width: 1024px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
            }

            .page-title {
                font-size: 2rem;
            }

            .product-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 640px) {
            .content {
                padding: 1rem;
            }

            .card {
                padding: 1.5rem;
            }

            .page-title {
                font-size: 1.75rem;
            }

            .product-card {
                padding: 1rem;
            }
        }

        @keyframes pulse {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.5;
            }
        }
    </style>
</head>

<body>
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar">
        <div class="sidebar-brand">
            <div class="flex items-center">
                <div class="w-10 h-10 bg-white bg-opacity-20 rounded-xl flex items-center justify-center mr-3">
                    <i class="fas fa-store text-white text-lg"></i>
                </div>
                <div>
                    <h2 class="text-xl font-bold text-white">DigiDaw</h2>
                    <p class="text-blue-200 text-sm">Seller Dashboard</p>
                </div>
            </div>
        </div>
        <nav class="sidebar-nav">
            <div class="nav-item">
                <a href="/seller/dashboard" class="nav-link">
                    <i class="fas fa-tachometer-alt nav-icon"></i>
                    Dashboard
                </a>
            </div>
            <div class="nav-item active">
                <a href="/seller/products" class="nav-link">
                    <i class="fas fa-box nav-icon"></i>
                    Produk
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/orders' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-shopping-cart nav-icon"></i>
                    Pesanan
                    <?php if (isset($newOrders) && $newOrders > 0): ?>
                        <span class="notification-badge"><?= $newOrders > 99 ? '99+' : $newOrders ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
            </div>
            <div class="nav-item <?= $needsVerification ? 'opacity-50' : '' ?>">
                <a href="<?= $needsVerification ? 'javascript:void(0)' : '/seller/reports' ?>" class="nav-link" <?= $needsVerification ? 'onclick="showVerificationAlert()"' : '' ?>>
                    <i class="fas fa-chart-bar nav-icon"></i>
                    Laporan
                </a>
            </div>
            <div class="nav-item">
                <a href="/seller/profile" class="nav-link">
                    <i class="fas fa-user nav-icon"></i>
                    Profil
                </a>
            </div>
            <div class="nav-item" style="margin-top: 2rem;">
                <a href="/auth/logout" class="nav-link" style="color: #fca5a5;">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    Logout
                </a>
            </div>
        </nav>
    </div>
    <!-- Content -->
    <div class="content">
        <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>">
        <!-- Mobile Menu Button -->
        <button id="mobile-menu-btn" class="lg:hidden fixed top-4 left-4 z-50 bg-white bg-opacity-20 backdrop-blur-lg text-white p-3 rounded-xl" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
        <!-- Page Header -->
        <div class="page-header">
            <h1 class="page-title">Produk</h1>
            <p class="page-subtitle">Kelola produk Anda dengan mudah</p>
        </div>
        <!-- Flash Messages -->
        <?php if (session()->getFlashdata('error')): ?>
            <div class="flash-message flash-error">
                <i class="fas fa-exclamation-circle mr-2"></i>
                <?= esc(session()->getFlashdata('error')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('success')): ?>
            <div class="flash-message flash-success">
                <i class="fas fa-check-circle mr-2"></i>
                <?= esc(session()->getFlashdata('success')) ?>
            </div>
        <?php endif; ?>
        <?php if (session()->getFlashdata('info')): ?>
            <div class="flash-message flash-info">
                <i class="fas fa-info-circle mr-2"></i>
                <?= esc(session()->getFlashdata('info')) ?>
            </div>
        <?php endif; ?>
        <!-- Verification Status -->
        <?php if ($needsVerification): ?>
            <div class="verification-card card <?= $verificationStatus === 'pending' ? 'pending' : ($verificationStatus === 'rejected' ? 'rejected' : 'non-verified') ?>">
                <div class="flex items-start justify-between">
                    <div class="flex items-center">
                        <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                            <?php if ($verificationStatus === 'pending'): ?>
                                <i class="fas fa-clock text-yellow-600 text-2xl"></i>
                            <?php else: ?>
                                <i class="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
                            <?php endif; ?>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                            <?php if ($verificationStatus === 'pending'): ?>
                                <p class="text-yellow-700 font-semibold">⏳ Verifikasi akun Anda sedang diproses. Tunggu persetujuan admin.</p>
                            <?php elseif ($verificationStatus === 'rejected'): ?>
                                <p class="text-red-700 font-semibold">❌ Verifikasi ditolak. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Upload ulang verifikasi</a></p>
                            <?php else: ?>
                                <p class="text-red-700 font-semibold">⚠️ Akun belum diverifikasi. <a href="/seller/verify" class="text-blue-600 underline hover:text-blue-800">Verifikasi sekarang</a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($verificationStatus !== 'pending'): ?>
                        <a href="/seller/verify" class="btn btn-primary">
                            <i class="fas fa-camera"></i>
                            Verifikasi
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-xl flex items-center justify-center mr-4" style="background: rgba(255, 255, 255, 0.2);">
                        <i class="fas fa-check-circle text-green-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold mb-1">Selamat datang, <?= esc($username) ?>!</h3>
                        <p class="text-green-700 font-semibold">✅ Akun Anda sudah diverifikasi. Selamat berjualan!</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- Products List -->
        <div class="card">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-2xl font-bold text-gray-800 flex items-center">
                    <i class="fas fa-box text-blue-600 mr-3"></i>
                    Daftar Produk
                </h2>
                <div class="flex gap-3">
                    <select id="productFilter" class="px-4 py-2 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500" onchange="applyFilter(this.value)">
                        <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>Semua Produk</option>
                        <option value="low-stock" <?= $filter === 'low-stock' ? 'selected' : '' ?>>Stok Rendah</option>
                        <option value="new" <?= $filter === 'new' ? 'selected' : '' ?>>Produk Baru</option>
                    </select>
                    <a href="/seller/tambahproduk" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Tambah Produk
                    </a>
                </div>
            </div>
            <?php if (empty($products)): ?>
                <div class="text-center py-12">
                    <i class="fas fa-box text-gray-300 text-6xl mb-4"></i>
                    <p class="text-gray-500 text-lg">Belum ada produk</p>
                    <p class="text-gray-400 mb-6">Tambahkan produk pertama Anda untuk mulai berjualan</p>
                    <a href="/seller/tambahproduk" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Tambah Produk
                    </a>
                </div>
            <?php else: ?>
                <div class="product-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <div class="flex items-start justify-between mb-3">
                                <h3 class="font-semibold text-gray-800 text-lg leading-tight"><?= esc($product['name']) ?></h3>
                                <span class="status-badge status-<?= $product['status'] ?>"><?= ucfirst($product['status']) ?></span>
                            </div>
                            <img src="<?= esc($product['image_url'] ?? $product['image'] ?? '/images/default-product.jpg') ?>" class="product-image-preview mb-3" alt="<?= esc($product['name']) ?>">
                            <div class="mb-3">
                                <p class="text-2xl font-bold text-blue-600">Rp <?= number_format($product['price'], 0, ',', '.') ?></p>
                                <p class="text-gray-600">Stok: <?= esc($product['stock']) ?> unit</p>
                            </div>
                            <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                                <span><i class="fas fa-calendar mr-1"></i><?= date('d M Y', strtotime($product['created_at'])) ?></span>
                            </div>
                            <div class="flex gap-2">
                                <button class="btn btn-secondary flex-1" onclick="viewProduct(<?= $product['product_id'] ?>)">
                                    <i class="fas fa-eye"></i>
                                    Lihat
                                </button>
                                <button class="btn btn-primary flex-1" onclick="editProduct(<?= $product['product_id'] ?>)">
                                    <i class="fas fa-edit"></i>
                                    Edit
                                </button>
                                <button class="btn btn-danger flex-1" onclick="deleteProduct(<?= $product['product_id'] ?>)">
                                    <i class="fas fa-trash"></i>
                                    Hapus
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <!-- Pagination -->
                <?php if (isset($pager)): ?>
                    <div class="pagination">
                        <?= $pager->links() ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <!-- Chat Modal -->
        <div id="chatModal" class="modal">
            <div class="modal-content">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-2xl font-bold text-gray-800 flex items-center">
                        <i class="fas fa-comments text-blue-600 mr-3"></i>
                        Pesan
                    </h2>
                    <button onclick="toggleChatModal()" class="text-gray-400 hover:text-gray-600 text-2xl">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <!-- Conversations List -->
                    <div class="md:col-span-1">
                        <h3 class="font-semibold text-gray-800 mb-4">Percakapan</h3>
                        <div class="space-y-2 max-h-80 overflow-y-auto">
                            <?php if (empty($conversations)): ?>
                                <div class="text-center py-8">
                                    <i class="fas fa-comments text-gray-300 text-4xl mb-3"></i>
                                    <p class="text-gray-500">Belum ada pesan</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($conversations as $conv): ?>
                                    <div class="chat-conversation" onclick="selectConversation('<?= $conv['order_id'] ?? '' ?>', '<?= $conv['buyer_id'] ?? '' ?>', '<?= esc($conv['buyer_name'] ?? 'N/A') ?>')">
                                        <div class="flex justify-between items-start mb-2">
                                            <span class="font-medium"><?= esc($conv['buyer_name'] ?? 'N/A') ?></span>
                                            <span class="text-xs opacity-75"><?= date('H:i', strtotime($conv['last_message'] ?? 'now')) ?></span>
                                        </div>
                                        <p class="text-sm opacity-75 mb-1">Order #<?= $conv['order_id'] ?? 'N/A' ?></p>
                                        <p class="text-sm truncate"><?= esc($conv['last_message'] ?? '') ?></p>
                                        <?php if (isset($conv['unread_count']) && $conv['unread_count'] > 0): ?>
                                            <span class="notification-badge mt-2"><?= $conv['unread_count'] ?></span>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- Chat Area -->
                    <div class="md:col-span-2">
                        <div id="chatHeader" class="mb-4 hidden">
                            <h3 class="font-semibold text-gray-800" id="chatTitle">Pilih percakapan</h3>
                            <p class="text-sm text-gray-600" id="chatSubtitle"></p>
                        </div>
                        <div id="chatArea" class="chat-area mb-4">
                            <div class="text-center py-12">
                                <i class="fas fa-comments text-gray-300 text-4xl mb-3"></i>
                                <p class="text-gray-500">Pilih percakapan untuk memulai</p>
                            </div>
                        </div>
                        <form id="chatForm" class="hidden" action="/seller/sendMessage" method="POST">
                            <input type="hidden" name="order_id" id="chatOrderId">
                            <input type="hidden" name="receiver_id" id="chatReceiverId">
                            <div class="flex gap-3">
                                <input type="text" name="message" id="chatMessage" class="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" placeholder="Ketik pesan...">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i>
                                    Kirim
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('show');
        }

        function toggleChatModal() {
            const modal = document.getElementById('chatModal');
            modal.classList.toggle('show');
            if (!modal.classList.contains('show')) {
                resetChat();
            }
        }

        function resetChat() {
            document.getElementById('chatArea').innerHTML = `
                <div class="text-center py-12">
                    <i class="fas fa-comments text-gray-300 text-4xl mb-3"></i>
                    <p class="text-gray-500">Pilih percakapan untuk memulai</p>
                </div>
            `;
            document.getElementById('chatForm').classList.add('hidden');
            document.getElementById('chatHeader').classList.add('hidden');
            document.querySelectorAll('.chat-conversation').forEach(conv => {
                conv.classList.remove('active');
            });
        }

        function selectConversation(orderId, buyerId, buyerName) {
            document.getElementById('chatOrderId').value = orderId;
            document.getElementById('chatReceiverId').value = buyerId;
            document.getElementById('chatTitle').textContent = buyerName;
            document.getElementById('chatSubtitle').textContent = `Order #${orderId}`;
            document.getElementById('chatHeader').classList.remove('hidden');
            document.getElementById('chatForm').classList.remove('hidden');
            document.querySelectorAll('.chat-conversation').forEach(conv => {
                conv.classList.remove('active');
            });
            event.currentTarget.classList.add('active');
            loadMessages(orderId);
        }

        function loadMessages(orderId) {
            const chatArea = document.getElementById('chatArea');
            chatArea.innerHTML = '<div class="text-center py-4"><div class="loading-spinner mx-auto"></div></div>';
            fetch(`/seller/chat/${orderId}`, {
                    method: 'GET',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'error') {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message,
                            timer: 2000,
                            showConfirmButton: false
                        });
                        resetChat();
                        return;
                    }
                    chatArea.innerHTML = '';
                    data.messages.forEach((msg, index) => {
                        const messageDiv = document.createElement('div');
                        messageDiv.className = `message ${msg.sender_id == <?= session()->get('user_id') ?> ? 'sent' : 'received'}`;
                        messageDiv.style.animationDelay = `${index * 0.1}s`;
                        messageDiv.innerHTML = `
                        <p>${msg.message}</p>
                        <small class="text-xs opacity-75 mt-1 block">${new Date(msg.created_at).toLocaleTimeString('id-ID', {hour: '2-digit', minute: '2-digit'})}</small>
                    `;
                        chatArea.appendChild(messageDiv);
                    });
                    chatArea.scrollTop = chatArea.scrollHeight;
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Gagal memuat pesan. Coba lagi nanti.',
                        timer: 2000,
                        showConfirmButton: false
                    });
                    console.error('Error fetching chat:', error);
                });
        }

        function viewProduct(productId) {
            if (!productId) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'ID produk tidak valid.',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            window.location.href = `/seller/products/view/${productId}`;
        }

        function editProduct(productId) {
            if (!productId) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'ID produk tidak valid.',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            window.location.href = `/seller/products/edit/${productId}`;
        }

        function deleteProduct(productId) {
            if (!productId) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'ID produk tidak valid.',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            Swal.fire({
                icon: 'warning',
                title: 'Hapus Produk',
                text: 'Apakah Anda yakin ingin menghapus produk ini?',
                showCancelButton: true,
                confirmButtonText: 'Hapus',
                cancelButtonText: 'Batal',
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#6b7280'
            }).then((result) => {
                if (result.isConfirmed) {
                    console.log('Sending DELETE request for product ID:', productId); // Debug
                    fetch(`/seller/products/delete/${productId}`, {
                            method: 'POST',
                            headers: {
                                'X-Requested-With': 'XMLHttpRequest',
                                'X-CSRF-TOKEN': document.querySelector('input[name="<?= csrf_token() ?>"]').value
                            }
                        })
                        .then(response => {
                            console.log('Response status:', response.status); // Debug
                            return response.json();
                        })
                        .then(data => {
                            console.log('Response data:', data); // Debug
                            if (data.status === 'success') {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil',
                                    text: 'Produk dihapus',
                                    timer: 1500,
                                    showConfirmButton: false
                                }).then(() => {
                                    window.location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Gagal',
                                    text: data.message || 'Gagal menghapus produk.',
                                    timer: 2000,
                                    showConfirmButton: false
                                });
                            }
                        })
                        .catch(error => {
                            Swal.fire({
                                icon: 'error',
                                title: 'Error',
                                text: 'Gagal menghapus produk. Coba lagi nanti.',
                                timer: 2000,
                                showConfirmButton: false
                            });
                            console.error('Error deleting product:', error);
                        });
                }
            });
        }

        function applyFilter(filter) {
            window.location.href = `/seller/products/${filter}`;
        }

        function showVerificationAlert() {
            Swal.fire({
                icon: 'warning',
                title: 'Belum Diverifikasi',
                text: 'Akun Anda belum diverifikasi. Verifikasi diperlukan untuk mengakses fitur ini.',
                confirmButtonText: 'Verifikasi Sekarang',
                showCancelButton: true,
                cancelButtonText: 'Nanti',
                confirmButtonColor: '#3b82f6',
                cancelButtonColor: '#ef4444'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/seller/verify';
                }
            });
        }

        // Polling for unread messages
        let lastMessageId = 0;

        function pollMessages() {
            fetch('/seller/getUnreadCount', {
                    method: 'GET',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const badge = document.querySelector('.nav-item .nav-link[href="javascript:void(0)"] .notification-badge');
                        if (data.unread_count > 0) {
                            badge.textContent = data.unread_count > 99 ? '99+' : data.unread_count;
                            badge.style.display = 'block';
                        } else {
                            badge.style.display = 'none';
                        }
                    }
                })
                .catch(error => {
                    console.error('Error polling messages:', error);
                });
        }

        setInterval(pollMessages, 30000); // Poll every 30 seconds
        pollMessages(); // Initial poll

        setTimeout(() => {
            document.querySelectorAll('.flash-message').forEach(msg => {
                msg.style.opacity = '0';
                msg.style.transform = 'translateY(-10px)';
                setTimeout(() => msg.remove(), 300);
            });
        }, 5000);

        document.addEventListener('click', function(e) {
            const chatModal = document.getElementById('chatModal');
            if (e.target === chatModal) {
                toggleChatModal();
            }
        });
    </script>
</body>

</html>