<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= esc($title ?? 'Laporan Penjualan - DigiDaw') ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header img.logo {
            max-width: 150px;
            margin-bottom: 10px;
        }
        .header h1 {
            font-size: 28px;
            margin: 0;
            color: #1e3a8a;
        }
        .header p {
            color: #666;
            margin: 5px 0;
            font-size: 14px;
        }
        .summary {
            margin-bottom: 20px;
            padding: 10px;
            background: #f9fafb;
            border-radius: 8px;
            font-size: 14px;
        }
        .summary p {
            margin: 5px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            font-size: 14px;
        }
        th {
            background-color: #1e3a8a;
            color: white;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9fafb;
        }
        .no-data {
            text-align: center;
            font-style: italic;
            color: #666;
            margin-top: 20px;
            font-size: 16px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 10px;
        }
        @media print {
            .no-print {
                display: none;
            }
            body {
                margin: 0;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <!-- Replace with your actual logo path -->
        <img src="/assets/images/logo.png" alt="DigiDaw Logo" class="logo" onerror="this.style.display='none'">
        <h1>Laporan Penjualan - DigiDaw</h1>
        <p>Laporan Ekspor Penjualan</p>
        <p>Pengguna: <?= esc($username) ?></p>
        <p>Periode: <?= date('d M Y', strtotime($startDate)) ?> - <?= date('d M Y', strtotime($endDate)) ?></p>
        <p>Dibuat pada: <?= esc($currentTime) ?></p>
    </div>

    <!-- Summary Section -->
    <div class="summary">
        <p><strong>Jumlah Pesanan:</strong> <?= count($reports) ?> pesanan</p>
        <p><strong>Total Pendapatan:</strong> Rp <?= number_format(array_sum(array_column($reports, 'total_price')), 0, ',', '.') ?></p>
    </div>

    <!-- Report Content -->
    <?php if (empty($reports)): ?>
        <p class="no-data">Tidak ada data penjualan untuk periode ini. Silakan periksa periode lain atau pastikan terdapat pesanan dengan status "completed".</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Nama Pembeli</th>
                    <th>Total Harga</th>
                    <th>Tanggal</th>
                    <th>Item</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reports as $report): ?>
                    <tr>
                        <td><?= esc($report['order_id']) ?></td>
                        <td><?= esc($report['buyer_name']) ?></td>
                        <td>Rp <?= number_format($report['total_price'], 0, ',', '.') ?></td>
                        <td><?= date('d/m/Y H:i', strtotime($report['created_at'])) ?></td>
                        <td>
                            <?php 
                            $items = '';
                            foreach ($report['items'] as $item) {
                                $items .= sprintf(
                                    '%dx %s (Rp %s)<br>',
                                    $item['quantity'] ?? 1,
                                    esc($item['product_name'] ?? 'Produk'),
                                    number_format($item['subtotal'] ?? $item['price'] ?? 0, 0, ',', '.')
                                );
                            }
                            echo trim($items);
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- Footer -->
    <div class="footer">
        <p>Terima kasih telah menggunakan DigiDaw. Untuk pertanyaan, hubungi support@digidaw.com.</p>
    </div>

    <button class="no-print" onclick="window.print()">Cetak Laporan</button>
    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>