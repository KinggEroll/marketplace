<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            color: #fff;
        }
        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }
        .neon-effect {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .neon-effect:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(102, 126, 234, 0.5);
        }
        .referral-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .referral-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }
        .notification-badge {
            background: linear-gradient(45deg, #ff4757, #ee5a24);
            animation: bounce 1s infinite;
            border-radius: 50%;
            padding: 0.2rem 0.6rem;
        }
        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-5px); }
            60% { transform: translateY(-2px); }
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 8px;
            min-width: 180px;
            z-index: 1000;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        .dropdown-menu.active {
            display: block;
        }
        .dropdown-menu a {
            display: block;
            padding: 0.75rem 1rem;
            color: #fff;
            text-decoration: none;
            transition: background 0.3s ease;
        }
        .dropdown-menu a:hover {
            background: linear-gradient(90deg, #667eea, #764ba2);
            color: #fff;
        }
    </style>
</head>

<body class="text-white">
    <input type="hidden" id="csrf_token" value="<?= csrf_hash() ?>">

    <nav class="p-4 glass-card mx-4 mt-4 relative" data-aos="fade-down">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-2xl font-bold text-white flex items-center">
                <span class="mr-2 text-3xl">🎮</span> DigiAw
            </a>
            <div class="flex items-center space-x-4">
                <?php if ($isLoggedIn): ?>
                    <div class="relative">
                        <button class="text-white hover:text-yellow-300 transition-colors duration-300">
                            <i class="fas fa-bell text-xl"></i>
                            <?php if (isset($stats['notification_count']) && $stats['notification_count'] > 0): ?>
                                <span class="notification-badge absolute -top-2 -right-2 text-xs font-bold">
                                    <?= $stats['notification_count'] ?>
                                </span>
                            <?php endif; ?>
                        </button>
                    </div>
                    <div class="relative dropdown">
                        <button class="flex items-center text-white hover:text-yellow-300 transition-colors duration-300">
                            <div class="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center mr-2">
                                <i class="fas fa-user text-sm"></i>
                            </div>
                            <span class="font-medium"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2 transition-transform duration-300"></i>
                        </button>
                        <div class="dropdown-menu">
                            <a href="/profile/edit"><i class="fas fa-user-edit mr-2"></i> Profil</a>
                            <a href="/auth/logout"><i class="fas fa-sign-out-alt mr-2"></i> Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="/auth/login" class="text-white hover:text-yellow-300 transition-colors duration-300">Login</a>
                    <a href="/auth/register" class="neon-effect px-4 py-2 rounded-full font-medium">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-6 flex flex-col md:flex-row gap-6">
        <aside class="w-full md:w-64" data-aos="fade-right">
            <div class="glass-card p-4">
                <h3 class="text-lg font-bold text-white mb-4">Navigasi</h3>
                <ul class="space-y-2">
                    <li><a href="/dashboard" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-home mr-3"></i> Dashboard</a></li>
                    <li><a href="/orders" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-shopping-bag mr-3"></i> Pesanan</a></li>
                    <li><a href="/cart" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-shopping-cart mr-3"></i> Keranjang <?php if (isset($stats['cart_count']) && $stats['cart_count'] > 0): ?><span class="ml-auto bg-red-500 text-white text-xs rounded-full px-1 py-0.5"><?= $stats['cart_count'] ?></span><?php endif; ?></a></li>
                    <li><a href="/wishlist" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-heart mr-3"></i> Wishlist</a></li>
                    <li><a href="/transactions" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-wallet mr-3"></i> Riwayat Transaksi</a></li>
                    <li><a href="/notifications" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-bell mr-3"></i> Notifikasi <?php if (isset($stats['notification_count']) && $stats['notification_count'] > 0): ?><span class="notification-badge text-white text-xs rounded-full px-1 py-0.5"><?= $stats['notification_count'] ?></span><?php endif; ?></a></li>
                    <li><a href="/promos" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-tags mr-3"></i> Promo</a></li>
                    <li><a href="/referral" class="block px-3 py-2 text-white bg-white bg-opacity-20 rounded-lg flex items-center"><i class="fas fa-user-plus mr-3"></i> Referral</a></li>
                    <li><a href="/profile/edit" class="block px-3 py-2 text-white hover:bg-white hover:bg-opacity-10 rounded-lg flex items-center"><i class="fas fa-cog mr-3"></i> Pengaturan</a></li>
                </ul>
            </div>
        </aside>

        <div class="flex-1">
            <div class="glass-card p-6">
                <div class="text-center mb-6" data-aos="fade-up">
                    <h2 class="text-2xl md:text-4xl font-bold text-white mb-3">Program Referral</h2>
                    <p class="text-white text-opacity-80 text-base md:text-lg">Ajak teman dan dapatkan bonus menarik!</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6" data-aos="fade-up" data-aos-delay="100">
                    <div class="referral-card p-4 text-center">
                        <div class="text-2xl md:text-3xl mb-2">👥</div>
                        <h3 class="text-xl md:text-2xl font-bold text-white mb-1"><?= esc($stats['total_referrals']) ?></h3>
                        <p class="text-white text-opacity-70 text-sm md:text-base">Total Referral</p>
                    </div>
                    <div class="referral-card p-4 text-center">
                        <div class="text-2xl md:text-3xl mb-2">💰</div>
                        <h3 class="text-xl md:text-2xl font-bold text-white mb-1">Rp <?= number_format($stats['total_referrals'] * 10000, 0, ',', '.') ?></h3>
                        <p class="text-white text-opacity-70 text-sm md:text-base">Total Bonus</p>
                    </div>
                    <div class="referral-card p-4 text-center">
                        <div class="text-2xl md:text-3xl mb-2">🎯</div>
                        <h3 class="text-xl md:text-2xl font-bold text-white mb-1"><?= $stats['total_referrals'] >= 10 ? 'Tercapai' : (10 - $stats['total_referrals']) . ' lagi' ?></h3>
                        <p class="text-white text-opacity-70 text-sm md:text-base">Target 10 Referral</p>
                    </div>
                </div>

                <div class="referral-card p-6 mb-6" data-aos="fade-up" data-aos-delay="200">
                    <h3 class="text-xl md:text-2xl font-semibold text-white mb-4 text-center">Kode Referral Anda</h3>
                    <div class="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-4 mb-4">
                        <div class="bg-white bg-opacity-20 rounded-lg p-3 w-full md:w-auto">
                            <input type="text" id="referralCode" value="<?= esc($referralCode) ?>"
                                class="w-full bg-transparent text-white text-center text-lg md:text-2xl font-bold border-none outline-none" readonly>
                        </div>
                        <button onclick="copyReferralCode()" class="neon-effect px-4 py-2 rounded-lg text-white font-semibold hover:shadow-lg w-full md:w-auto">
                            <i class="fas fa-copy mr-2"></i> Salin
                        </button>
                    </div>
                    <div class="text-center">
                        <p class="text-white text-opacity-80 mb-3 text-sm md:text-base">Bagikan kode ini kepada teman-teman Anda!</p>
                        <div class="flex flex-col md:flex-row justify-center space-y-3 md:space-y-0 md:space-x-3">
                            <button onclick="shareToWhatsApp()" class="neon-effect px-3 py-2 rounded-lg text-white text-sm md:text-base">
                                <i class="fab fa-whatsapp mr-2"></i> WhatsApp
                            </button>
                            <button onclick="shareToTelegram()" class="neon-effect px-3 py-2 rounded-lg text-white text-sm md:text-base">
                                <i class="fab fa-telegram mr-2"></i> Telegram
                            </button>
                            <button onclick="shareToFacebook()" class="neon-effect px-3 py-2 rounded-lg text-white text-sm md:text-base">
                                <i class="fab fa-facebook mr-2"></i> Facebook
                            </button>
                        </div>
                    </div>
                </div>

                <div class="referral-card p-6" data-aos="fade-up" data-aos-delay="300">
                    <h3 class="text-xl md:text-2xl font-semibold text-white mb-4">Daftar Referral Anda</h3>
                    <?php if (empty($referrals)): ?>
                        <div class="text-center py-8">
                            <div class="text-4xl md:text-6xl mb-3">👥</div>
                            <p class="text-white text-opacity-70 text-lg md:text-xl mb-2">Belum ada referral</p>
                            <p class="text-white text-opacity-60 text-sm md:text-base">Mulai ajak teman untuk mendapatkan bonus!</p>
                        </div>
                    <?php else: ?>
                        <div class="overflow-x-auto rounded-lg">
                            <table class="w-full">
                                <thead class="bg-white bg-opacity-10">
                                    <tr>
                                        <th class="py-2 px-4 text-left text-white font-semibold text-sm md:text-base">No</th>
                                        <th class="py-2 px-4 text-left text-white font-semibold text-sm md:text-base">Username</th>
                                        <th class="py-2 px-4 text-left text-white font-semibold text-sm md:text-base">Email</th>
                                        <th class="py-2 px-4 text-left text-white font-semibold text-sm md:text-base">Tanggal Bergabung</th>
                                        <th class="py-2 px-4 text-left text-white font-semibold text-sm md:text-base">Bonus</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($referrals as $index => $referral): ?>
                                        <tr class="border-b border-white border-opacity-10 hover:bg-white hover:bg-opacity-5 transition-all" data-aos="zoom-in" data-aos-delay="<?= $index * 100 ?>">
                                            <td class="py-2 px-4 text-white text-sm md:text-base"><?= $index + 1 ?></td>
                                            <td class="py-2 px-4 text-white font-medium text-sm md:text-base"><?= esc($referral['username']) ?></td>
                                            <td class="py-2 px-4 text-white text-opacity-80 text-sm md:text-base"><?= esc($referral['email']) ?></td>
                                            <td class="py-2 px-4 text-white text-opacity-80 text-sm md:text-base"><?= date('d M Y', strtotime($referral['created_at'])) ?></td>
                                            <td class="py-2 px-4">
                                                <span class="bg-green-500 text-white px-2 py-1 rounded-full text-xs md:text-sm font-medium">
                                                    +Rp 10.000
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="referral-card p-6 mt-6" data-aos="fade-up" data-aos-delay="400">
                    <h3 class="text-xl md:text-2xl font-semibold text-white mb-4 text-center">Cara Kerja Program Referral</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div class="text-center">
                            <div class="bg-white bg-opacity-20 rounded-full w-12 h-12 md:w-16 md:h-16 flex items-center justify-center mx-auto mb-2">
                                <span class="text-xl md:text-2xl">1️⃣</span>
                            </div>
                            <h4 class="text-md md:text-lg font-semibold text-white mb-1">Bagikan Kode</h4>
                            <p class="text-white text-opacity-70 text-sm md:text-base">Bagikan kode referral Anda kepada teman-teman</p>
                        </div>
                        <div class="text-center">
                            <div class="bg-white bg-opacity-20 rounded-full w-12 h-12 md:w-16 md:h-16 flex items-center justify-center mx-auto mb-2">
                                <span class="text-xl md:text-2xl">2️⃣</span>
                            </div>
                            <h4 class="text-md md:text-lg font-semibold text-white mb-1">Teman Daftar</h4>
                            <p class="text-white text-opacity-70 text-sm md:text-base">Teman mendaftar menggunakan kode referral Anda</p>
                        </div>
                        <div class="text-center">
                            <div class="bg-white bg-opacity-20 rounded-full w-12 h-12 md:w-16 md:h-16 flex items-center justify-center mx-auto mb-2">
                                <span class="text-xl md:text-2xl">3️⃣</span>
                            </div>
                            <h4 class="text-md md:text-lg font-semibold text-white mb-1">Dapatkan Bonus</h4>
                            <p class="text-white text-opacity-70 text-sm md:text-base">Anda mendapatkan bonus Rp 10.000 untuk setiap referral</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="toastTemplate" class="toast-notification hidden fixed bottom-4 right-4">
        <div class="flex items-center space-x-3 bg-white p-3 rounded-lg shadow-lg">
            <div class="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                <i class="fas fa-check text-white text-sm"></i>
            </div>
            <div>
                <p class="font-medium text-gray-800" id="toastTitle">Success!</p>
                <p class="text-sm text-gray-600" id="toastMessage">Action completed successfully.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init({ duration: 800, once: true, offset: 100 });

        document.querySelectorAll('.dropdown').forEach(dropdown => {
            const toggle = dropdown.querySelector('button');
            const menu = dropdown.querySelector('.dropdown-menu');
            const chevron = toggle.querySelector('.fa-chevron-down');
            if (toggle && menu && chevron) {
                toggle.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    menu.classList.toggle('active');
                    chevron.classList.toggle('rotate-180');
                });
                document.addEventListener('click', (e) => {
                    if (!dropdown.contains(e.target)) {
                        menu.classList.remove('active');
                        chevron.classList.remove('rotate-180');
                    }
                });
            }
        });

        function copyReferralCode() {
            const codeInput = document.getElementById('referralCode');
            codeInput.select();
            navigator.clipboard.writeText(codeInput.value).then(() => {
                showToast('Berhasil!', 'Kode referral berhasil disalin!', 'success');
            });
        }

        function shareToWhatsApp() {
            const code = document.getElementById('referralCode').value;
            const message = `Halo! Yuk gabung di DigiAw dengan kode referral saya: ${code}. Dapatkan produk digital terbaik dengan harga terjangkau!`;
            window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
        }

        function shareToTelegram() {
            const code = document.getElementById('referralCode').value;
            const message = `Halo! Yuk gabung di DigiAw dengan kode referral saya: ${code}. Dapatkan produk digital terbaik dengan harga terjangkau!`;
            window.open(`https://t.me/share/url?text=${encodeURIComponent(message)}`, '_blank');
        }

        function shareToFacebook() {
            const code = document.getElementById('referralCode').value;
            const message = `Halo! Yuk gabung di DigiAw dengan kode referral saya: ${code}. Dapatkan produk digital terbaik dengan harga terjangkau!`;
            window.open(`https://www.facebook.com/sharer/sharer.php?quote=${encodeURIComponent(message)}`, '_blank');
        }

        function showToast(title, message, type = 'success') {
            const toast = document.getElementById('toastTemplate').cloneNode(true);
            toast.id = 'toast-' + Date.now();
            toast.classList.remove('hidden');
            toast.querySelector('#toastTitle').textContent = title;
            toast.querySelector('#toastMessage').textContent = message;

            const icon = toast.querySelector('i');
            const iconContainer = toast.querySelector('.w-8');
            if (type === 'warning') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-exclamation text-white text-sm';
            } else if (type === 'error') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-times text-white text-sm';
            }

            document.body.appendChild(toast);
            setTimeout(() => toast.classList.add('opacity-100'), 100);
            setTimeout(() => {
                toast.classList.remove('opacity-100');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        document.addEventListener('click', function(event) {
            const button = event.target.closest('button, .neon-effect');
            if (button && (button.type === 'submit' || button.href)) {
                const originalContent = button.innerHTML;
                button.innerHTML = '<span class="inline-block w-4 h-4 border-2 border-t-transparent border-white rounded-full animate-spin mr-2"></span>Loading...';
                button.disabled = true;
                setTimeout(() => {
                    button.innerHTML = originalContent;
                    button.disabled = false;
                }, 2000);
            }
        });
    </script>
</html>