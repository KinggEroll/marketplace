<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deposit Saldo - DigiDaw</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #e0e7ff 0%, #c6e8d7 100%);
            color: #2d3748;
            margin: 0;
            min-height: 100vh;
        }

        .dark body {
            background: linear-gradient(135deg, #2d3748 0%, #4a5568 100%);
            color: #e0e7ff;
        }

        .navbar {
            backdrop-filter: blur(12px);
            background: rgba(255, 255, 255, 0.1);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            position: sticky;
            top: 0;
            z-index: 50;
        }

        .dark .navbar {
            background: rgba(45, 55, 72, 0.3);
            border-bottom: 1px solid rgba(198, 232, 215, 0.3);
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 15px;
            padding: 2rem;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .dark .glass-card {
            background: rgba(74, 85, 104, 0.3);
            border-color: rgba(198, 232, 215, 0.2);
        }

        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }

        .input-field {
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 0.75rem;
            transition: border-color 0.3s ease;
            background: white;
        }

        .dark .input-field {
            border-color: #4a5568;
            background: #4a5568;
            color: #e0e7ff;
        }

        .input-field:focus {
            border-color: #4a90e2;
            outline: none;
        }

        .dark .input-field:focus {
            border-color: #c6e8d7;
        }

        .neon-effect {
            background: none;
            color: #4a90e2;
            border: 2px solid #4a90e2;
            border-radius: 10px;
            padding: 0.75rem 1.5rem;
            transition: all 0.3s ease;
        }

        .dark .neon-effect {
            color: #c6e8d7;
            border-color: #c6e8d7;
        }

        .neon-effect:hover {
            background: #4a90e2;
            color: white;
        }

        .dark .neon-effect:hover {
            background: #c6e8d7;
            color: #2d3748;
        }
    </style>
</head>

<body>
    <nav class="navbar p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-green-300 flex items-center">
                <span class="mr-2">🎮</span> DigiDaw
            </a>
            <div class="flex items-center space-x-6">
                <?php if ($isLoggedIn): ?>
                    <div class="relative dropdown">
                        <button class="flex items-center text-gray-800 dark:text-gray-200 hover:text-blue-500 transition-all duration-300">
                            <i class="fas fa-user-circle mr-2 text-2xl"></i>
                            <span class="font-semibold"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2 text-sm"></i>
                        </button>
                        <div class="dropdown-menu absolute right-0 mt-2 w-48 bg-white dark:bg-gray-700 rounded-lg shadow-lg py-2 opacity-0 invisible transition-all duration-300">
                            <a href="/profile/edit" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white">Profil</a>
                            <a href="/profile/deposit" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white">Deposit</a>
                            <a href="/dashboard" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-blue-500 hover:text-white">Dashboard</a>
                            <a href="/auth/logout" class="block px-4 py-2 text-gray-800 dark:text-gray-200 hover:bg-red-500 hover:text-white">Logout</a>
                        </div>
                    </div>
                    <button onclick="toggleDarkMode()" class="text-gray-800 dark:text-gray-200 hover:text-blue-500">
                        <i class="fas fa-moon"></i>
                    </button>
                <?php else: ?>
                    <a href="/auth/login" class="text-gray-800 dark:text-gray-200 hover:text-blue-500 font-medium">Masuk</a>
                    <a href="/auth/register" class="bg-blue-500 hover:bg-green-300 text-white px-4 py-2 rounded-full hover:shadow transition-all duration-300 font-semibold">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-8">
        <div class="glass-card max-w-2xl mx-auto">
            <h2 class="text-3xl font-bold text-gray-800 dark:text-gray-200 mb-6">Deposit Saldo</h2>
            <p class="text-gray-600 dark:text-gray-300 mb-4">Masukkan jumlah deposit dan pilih metode pembayaran. Untuk simulasi, gunakan kode konfirmasi <strong>DEMO123</strong>.</p>
            <form id="depositForm" class="space-y-6">
                <?= csrf_field() ?>
                <input type="hidden" name="user_id" value="<?= esc($user['user_id']) ?>">

                <!-- Current Balance -->
                <div>
                    <label class="block text-gray-600 dark:text-gray-300 font-medium mb-2">Saldo Saat Ini</label>
                    <p class="text-2xl font-bold text-blue-500 dark:text-green-300">Rp <?= number_format($user['balance'] ?? 0, 2, ',', '.') ?></p>
                </div>

                <!-- Deposit Amount -->
                <div>
                    <label for="amount" class="block text-gray-600 dark:text-gray-300 font-medium mb-2">Jumlah Deposit (Rp)</label>
                    <input type="number" id="amount" name="amount" class="input-field w-full" placeholder="Minimal Rp 10.000" min="10000" step="1000">
                    <div id="amount_error" class="text-red-500 text-sm mt-1 hidden"></div>
                </div>

                <!-- Payment Method -->
                <div>
                    <label for="payment_method" class="block text-gray-600 dark:text-gray-300 font-medium mb-2">Metode Pembayaran</label>
                    <select id="payment_method" name="payment_method" class="input-field w-full">
                        <option value="">Pilih metode</option>
                        <option value="bank_transfer">Transfer Bank</option>
                        <option value="ewallet">E-Wallet</option>
                    </select>
                    <div id="payment_method_error" class="text-red-500 text-sm mt-1 hidden"></div>
                </div>

                <!-- Confirmation Code -->
                <div>
                    <label for="confirmation_code" class="block text-gray-600 dark:text-gray-300 font-medium mb-2">Kode Konfirmasi</label>
                    <input type="text" id="confirmation_code" name="confirmation_code" class="input-field w-full" placeholder="Masukkan kode konfirmasi (contoh: DEMO123)">
                    <div id="confirmation_code_error" class="text-red-500 text-sm mt-1 hidden"></div>
                </div>

                <!-- Submit Button -->
                <div>
                    <button type="submit" class="neon-effect flex items-center">
                        <i class="fas fa-wallet mr-2"></i> Proses Deposit
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function toggleDarkMode() {
            const isDark = document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', isDark ? 'enabled' : 'disabled');
        }
        if (localStorage.getItem('darkMode') === 'enabled') document.body.classList.add('dark');

        document.getElementById('depositForm').addEventListener('submit', function(e) {
            e.preventDefault();

            // Clear previous errors
            document.querySelectorAll('.text-red-500').forEach(el => {
                el.classList.add('hidden');
                el.textContent = '';
            });

            // Client-side validation
            let isValid = true;
            const amount = document.getElementById('amount').value.trim();
            const paymentMethod = document.getElementById('payment_method').value;
            const confirmationCode = document.getElementById('confirmation_code').value.trim();

            if (!amount || amount < 10000) {
                document.getElementById('amount_error').textContent = 'Jumlah deposit minimal Rp 10.000.';
                document.getElementById('amount_error').classList.remove('hidden');
                isValid = false;
            }
            if (!paymentMethod) {
                document.getElementById('payment_method_error').textContent = 'Pilih metode pembayaran.';
                document.getElementById('payment_method_error').classList.remove('hidden');
                isValid = false;
            }
            if (!confirmationCode || confirmationCode.length !== 6) {
                document.getElementById('confirmation_code_error').textContent = 'Kode konfirmasi harus 6 karakter.';
                document.getElementById('confirmation_code_error').classList.remove('hidden');
                isValid = false;
            }

            if (!isValid) return;

            const formData = new FormData(this);
            fetch('/profile/processDeposit', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: data.message,
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => window.location.href = '/dashboard');
                    } else {
                        if (data.errors) {
                            for (const [field, message] of Object.entries(data.errors)) {
                                const errorElement = document.getElementById(`${field}_error`);
                                if (errorElement) {
                                    errorElement.textContent = message;
                                    errorElement.classList.remove('hidden');
                                }
                            }
                        }
                        Swal.fire({
                            icon: 'error',
                            title: 'Gagal',
                            text: data.message || 'Terjadi kesalahan.',
                            confirmButtonText: 'OK'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Kesalahan',
                        text: 'Gagal memproses deposit.',
                        confirmButtonText: 'OK'
                    });
                });
        });
    </script>
</body>

</html>