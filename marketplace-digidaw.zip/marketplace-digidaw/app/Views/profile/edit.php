<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .glass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px 0 rgba(31, 38, 135, 0.5);
        }

        .neon-effect {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .neon-effect::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }

        .neon-effect:hover::before {
            left: 100%;
        }

        .neon-effect:hover {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(102, 126, 234, 0.6);
        }

        .floating-animation {
            animation: floating 3s ease-in-out infinite;
        }

        @keyframes floating {

            0%,
            100% {
                transform: translateY(0px);
            }

            50% {
                transform: translateY(-10px);
            }
        }

        .notification-badge {
            background: linear-gradient(45deg, #ff6b6b, #ee5a24);
            animation: bounce 1s infinite;
        }

        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-10px);
            }

            60% {
                transform: translateY(-5px);
            }
        }

        .sidebar-nav {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(15px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .nav-item {
            transition: all 0.3s ease;
            border-radius: 10px;
            margin: 4px 0;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateX(5px);
        }

        .nav-item.active {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }

        .gradient-text {
            background: linear-gradient(45deg, #667eea, #764ba2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .dropdown-menu {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            transform: translateY(-10px);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            opacity: 0;
            visibility: hidden;
        }

        .dropdown-menu.active {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .toast-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            padding: 15px 20px;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .toast-notification.show {
            transform: translateX(0);
        }

        .input-field {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            transition: all 0.3s ease;
        }

        .input-field:focus {
            background: rgba(255, 255, 255, 0.2);
            border-color: #667eea;
            box-shadow: 0 0 10px rgba(102, 126, 234, 0.5);
        }

        footer {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }

        .profile-picture-preview {
            max-width: 150px;
            max-height: 150px;
            object-fit: cover;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="p-4 glass-card mx-4 mt-4" data-aos="fade-down">
        <div class="container mx-auto flex justify-between items-center">
            <a href="/" class="text-2xl font-bold gradient-text flex items-center floating-animation">
                <span class="mr-2 text-3xl">🎮</span> DigiAw
            </a>
            <div class="flex items-center space-x-6">
                <?php if ($isLoggedIn): ?>
                    <!-- Notification Bell -->
                    <div class="relative">
                        <a href="/notifications" class="text-white hover:text-yellow-300 transition-colors duration-300">
                            <i class="fas fa-bell text-xl"></i>
                            <?php if (!empty($stats['notification_count']) && $stats['notification_count'] > 0): ?>
                                <span class="notification-badge absolute -top-2 -right-2 text-xs rounded-full px-2 py-1 text-white font-bold">
                                    <?= esc($stats['notification_count']) ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </div>
                    <!-- User Dropdown -->
                    <div class="relative dropdown">
                        <button class="flex items-center text-white hover:text-yellow-300 transition-colors duration-300">
                            <div class="w-8 h-8 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full flex items-center justify-center mr-2">
                                <?php if (!empty($user['profile_picture'])): ?>
                                    <img src="<?= esc($user['profile_picture']) ?>" alt="Profile" class="w-full h-full rounded-full object-cover">
                                <?php else: ?>
                                    <i class="fas fa-user text-sm"></i>
                                <?php endif; ?>
                            </div>
                            <span class="font-medium"><?= esc($username) ?></span>
                            <i class="fas fa-chevron-down ml-2 transition-transform duration-300"></i>
                        </button>
                        <div class="dropdown-menu absolute right-0 mt-2 w-48 py-2 z-10">
                            <a href="/profile/edit" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-user-edit mr-2"></i>Profil
                            </a>
                            <a href="/auth/logout" class="block px-4 py-2 text-gray-800 hover:bg-gradient-to-r hover:from-red-500 hover:to-pink-500 hover:text-white transition-all duration-300">
                                <i class="fas fa-sign-out-alt mr-2"></i>Logout
                            </a>
                        </div>
                    </div>
                    <button onclick="toggleDarkMode()" class="text-white hover:text-yellow-300 transition-colors duration-300">
                        <i class="fas fa-moon text-xl"></i>
                    </button>
                <?php else: ?>
                    <a href="/auth/login" class="text-white hover:text-yellow-300 transition-colors duration-300">Login</a>
                    <a href="/auth/register" class="neon-effect px-6 py-2 rounded-full font-medium">Daftar</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container mx-auto px-4 py-8 flex gap-8">
        <!-- Sidebar -->
        <aside class="w-64 hidden md:block" data-aos="fade-right">
            <div class="sidebar-nav p-6">
                <h3 class="text-xl font-bold text-white mb-6 gradient-text">Navigasi</h3>
                <ul class="space-y-2">
                    <li><a href="/dashboard" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-home mr-3"></i> Dashboard</a></li>
                    <li><a href="/orders" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-shopping-bag mr-3"></i> Pesanan</a></li>
                    <li><a href="/cart" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-shopping-cart mr-3"></i> Keranjang <?php if (!empty($stats['cart_count']) && $stats['cart_count'] > 0): ?><span class="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1"><?= esc($stats['cart_count']) ?></span><?php endif; ?></a></li>
                    <li><a href="/wishlist" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-heart mr-3"></i> Wishlist</a></li>
                    <li><a href="/transactions" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-wallet mr-3"></i> Riwayat Transaksi</a></li>
                    <li><a href="/notifications" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-bell mr-3"></i> Notifikasi <?php if (!empty($stats['notification_count']) && $stats['notification_count'] > 0): ?><span class="ml-auto notification-badge text-white text-xs rounded-full px-2 py-1"><?= esc($stats['notification_count']) ?></span><?php endif; ?></a></li>
                    <li><a href="/promos" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-tags mr-3"></i> Promo</a></li>
                    <li><a href="/referral" class="nav-item block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-user-plus mr-3"></i> Referral</a></li>
                    <li><a href="/profile/edit" class="nav-item active block px-4 py-3 text-white rounded-lg flex items-center"><i class="fas fa-cog mr-3"></i> Pengaturan</a></li>
                </ul>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="flex-1">
            <div class="glass-card p-8 mb-8" data-aos="fade-up">
                <h2 class="text-3xl font-bold text-white mb-6 flex items-center">
                    <i class="fas fa-user-edit mr-3 text-blue-400"></i>Edit Profil
                </h2>
                <?php if (session()->getFlashdata('error')): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                        <?= session()->getFlashdata('error') ?>
                    </div>
                <?php endif; ?>
                <?php if (session()->getFlashdata('success')): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                        <?= session()->getFlashdata('success') ?>
                    </div>
                <?php endif; ?>
                <form id="profileForm" action="/profile/update" method="post" enctype="multipart/form-data" class="space-y-6">
                    <?= csrf_field() ?>
                    <div>
                        <label for="username" class="block text-white opacity-70 text-sm mb-2">Username</label>
                        <input type="text" id="username" name="username" value="<?= esc($user['username']) ?>" class="input-field w-full p-3 rounded-lg" required>
                    </div>
                    <div>
                        <label for="email" class="block text-white opacity-70 text-sm mb-2">Email</label>
                        <input type="email" id="email" name="email" value="<?= esc($user['email']) ?>" class="input-field w-full p-3 rounded-lg" required readonly>
                    </div>
                    <div>
                        <label for="phone_number" class="block text-white opacity-70 text-sm mb-2">Nomor Telepon</label>
                        <input type="tel" id="phone_number" name="phone_number" value="<?= esc($user['phone_number'] ?? '') ?>" class="input-field w-full p-3 rounded-lg">
                    </div>
                    <div>
                        <label for="address" class="block text-white opacity-70 text-sm mb-2">Alamat</label>
                        <textarea id="address" name="address" class="input-field w-full p-3 rounded-lg" rows="4"><?= esc($user['address'] ?? '') ?></textarea>
                    </div>
                    <div>
                        <label for="profile_picture" class="block text-white opacity-70 text-sm mb-2">Foto Profil</label>
                        <?php if (!empty($user['profile_picture'])): ?>
                            <img src="<?= esc($user['profile_picture']) ?>" alt="Profile Picture" class="profile-picture-preview mb-2">
                        <?php endif; ?>
                        <input type="file" id="profile_picture" name="profile_picture" accept="image/jpeg,image/png,image/gif" class="input-field w-full p-3 rounded-lg">
                        <p class="text-white opacity-70 text-xs mt-1">Maks. 2MB, format: JPEG, PNG, GIF</p>
                    </div>
                    <div class="flex space-x-4">
                        <button type="submit" class="neon-effect px-6 py-3 rounded-lg">Simpan Perubahan</button>
                        <a href="/dashboard" class="px-6 py-3 rounded-lg bg-white bg-opacity-20 text-white hover:bg-opacity-30">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="p-4 mt-8 text-center text-white">
        <p class="text-sm opacity-70">© <?= date('Y') ?> DigiAw. All rights reserved.</p>
    </footer>

    <!-- Toast Notification Template -->
    <div id="toastTemplate" class="toast-notification" style="display: none;">
        <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center">
                <i class="fas fa-check text-white text-sm"></i>
            </div>
            <div>
                <p class="font-medium text-gray-800" id="toastTitle">Success!</p>
                <p class="text-sm text-gray-600" id="toastMessage">Action completed successfully.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true
        });

        // Dropdown functionality
        document.querySelector('.dropdown button')?.addEventListener('click', function() {
            const menu = document.querySelector('.dropdown-menu');
            const chevron = this.querySelector('.fa-chevron-down');
            menu.classList.toggle('active');
            chevron.style.transform = menu.classList.contains('active') ? 'rotate(180deg)' : 'rotate(0deg)';
        });

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const dropdown = document.querySelector('.dropdown');
            if (!dropdown.contains(event.target)) {
                document.querySelector('.dropdown-menu').classList.remove('active');
                document.querySelector('.fa-chevron-down').style.transform = 'rotate(0deg)';
            }
        });

        // Toggle dark mode
        function toggleDarkMode() {
            document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', document.body.classList.contains('dark') ? 'enabled' : 'disabled');
        }
        if (localStorage.getItem('darkMode') === 'enabled') document.body.classList.add('dark');

        // Toast notification system
        function showToast(title, message, type = 'success') {
            const toast = document.getElementById('toastTemplate').cloneNode(true);
            toast.id = 'toast-' + Date.now();
            toast.style.display = 'block';

            const icon = toast.querySelector('i');
            const iconContainer = toast.querySelector('.w-8');

            if (type === 'warning') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-exclamation text-white text-sm';
            } else if (type === 'error') {
                iconContainer.className = 'w-8 h-8 bg-gradient-to-r from-red-400 to-pink-500 rounded-full flex items-center justify-center';
                icon.className = 'fas fa-times text-white text-sm';
            }

            toast.querySelector('#toastTitle').textContent = title;
            toast.querySelector('#toastMessage').textContent = message;

            document.body.appendChild(toast);

            setTimeout(() => toast.classList.add('show'), 100);
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 3000);
        }

        // Form validation and submission
        document.getElementById('profileForm')?.addEventListener('submit', function(e) {
            e.preventDefault();
            const form = this;
            const username = form.username.value.trim();
            const phone_number = form.phone_number.value.trim();
            const address = form.address.value.trim();
            const profilePicture = form.profile_picture.files[0];

            if (username.length < 3) {
                showToast('Error', 'Username harus minimal 3 karakter', 'error');
                return;
            }

            if (phone_number && !/^08[0-9]{8,13}$/.test(phone_number)) {
                showToast('Error', 'Nomor telepon tidak valid', 'error');
                return;
            }

            if (address && address.length < 10) {
                showToast('Error', 'Alamat harus minimal 10 karakter', 'error');
                return;
            }

            if (profilePicture) {
                const maxSize = 2 * 1024 * 1024; // 2MB
                if (profilePicture.size > maxSize) {
                    showToast('Error', 'Foto profil maksimal 2MB', 'error');
                    return;
                }
                const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(profilePicture.type)) {
                    showToast('Error', 'Format foto harus JPEG, PNG, atau GIF', 'error');
                    return;
                }
            }

            const submitButton = form.querySelector('button[type="submit"]');
            const originalContent = submitButton.innerHTML;
            submitButton.innerHTML = '<div class="loading-spinner inline-block mr-2"></div>Menyimpan...';
            submitButton.disabled = true;

            fetch(form.action, {
                    method: 'POST',
                    body: new FormData(form) // Use FormData for file uploads
                })
                .then(response => response.json())
                .then(data => {
                    submitButton.innerHTML = originalContent;
                    submitButton.disabled = false;
                    if (data.status === 'success') {
                        showToast('Berhasil!', data.message || 'Profil berhasil diperbarui');
                        setTimeout(() => window.location.href = '/dashboard', 1500);
                    } else {
                        showToast('Error', data.message || 'Gagal memperbarui profil', 'error');
                        if (data.errors) {
                            Object.values(data.errors).forEach(error => {
                                showToast('Error', error, 'error');
                            });
                        }
                    }
                })
                .catch(error => {
                    submitButton.innerHTML = originalContent;
                    submitButton.disabled = false;
                    showToast('Error', 'Terjadi kesalahan server', 'error');
                });
        });

        // Handle session flash messages
        <?php if (session()->getFlashdata('success')): ?>
            showToast('Berhasil!', '<?= session()->getFlashdata('success') ?>', 'success');
        <?php endif; ?>
        <?php if (session()->getFlashdata('error')): ?>
            showToast('Error', '<?= session()->getFlashdata('error') ?>', 'error');
        <?php endif; ?>
    </script>
</body>

</html>