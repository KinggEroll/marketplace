<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'Register - DigiDaw') ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                    },
                    animation: {
                        'float': 'float 8s ease-in-out infinite',
                        'slide-up': 'slideUp 0.8s cubic-bezier(0.4, 0.0, 0.2, 1)',
                        'fade-in': 'fadeIn 1s ease-out',
                        'bounce-subtle': 'bounceSubtle 3s ease-in-out infinite',
                        'pulse-glow': 'pulseGlow 3s ease-in-out infinite',
                        'gradient-shift': 'gradientShift 12s ease-in-out infinite',
                        'shake': 'shake 0.6s ease-in-out',
                        'success-scale': 'successScale 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55)',
                        'morphing': 'morphing 8s ease-in-out infinite',
                    },
                    keyframes: {
                        float: {
                            '0%, 100%': { transform: 'translateY(0px) rotate(0deg)' },
                            '33%': { transform: 'translateY(-30px) rotate(120deg)' },
                            '66%': { transform: 'translateY(15px) rotate(240deg)' },
                        },
                        slideUp: {
                            '0%': { transform: 'translateY(150px) scale(0.8)', opacity: '0' },
                            '100%': { transform: 'translateY(0) scale(1)', opacity: '1' },
                        },
                        fadeIn: {
                            '0%': { opacity: '0', transform: 'translateY(20px)' },
                            '100%': { opacity: '1', transform: 'translateY(0)' },
                        },
                        bounceSubtle: {
                            '0%, 100%': { transform: 'translateY(0px) scale(1)' },
                            '50%': { transform: 'translateY(-10px) scale(1.05)' },
                        },
                        pulseGlow: {
                            '0%, 100%': { boxShadow: '0 0 30px rgba(139, 92, 246, 0.4)' },
                            '50%': { boxShadow: '0 0 60px rgba(139, 92, 246, 0.8)' },
                        },
                        gradientShift: {
                            '0%, 100%': { backgroundPosition: '0% 50%' },
                            '50%': { backgroundPosition: '100% 50%' },
                        },
                        shake: {
                            '0%, 100%': { transform: 'translateX(0)' },
                            '10%, 30%, 50%, 70%, 90%': { transform: 'translateX(-8px)' },
                            '20%, 40%, 60%, 80%': { transform: 'translateX(8px)' },
                        },
                        successScale: {
                            '0%': { transform: 'scale(0) rotate(-180deg)', opacity: '0' },
                            '50%': { transform: 'scale(1.2) rotate(0deg)', opacity: '1' },
                            '100%': { transform: 'scale(1) rotate(0deg)', opacity: '1' },
                        },
                        morphing: {
                            '0%, 100%': { borderRadius: '60% 40% 30% 70%/60% 30% 70% 40%', transform: 'translate3d(0,0,0) rotateZ(0deg)' },
                            '34%': { borderRadius: '70% 60% 50% 30%/50% 60% 30% 60%', transform: 'translate3d(0,5px,0) rotateZ(-5deg)' },
                            '67%': { borderRadius: '100% 60% 60% 100%/100% 100% 60% 60%', transform: 'translate3d(0,-3px,0) rotateZ(5deg)' },
                        },
                    },
                },
            },
        }
    </script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(-45deg, #8B5CF6, #EC4899, #F59E0B, #10B981, #3B82F6, #8B5CF6);
            background-size: 600% 600%;
            animation: gradientShift 20s ease infinite;
            overflow-x: hidden;
        }

        .glass-morphism {
            backdrop-filter: blur(25px);
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        .input-focus-glow:focus {
            box-shadow: 0 0 30px rgba(139, 92, 246, 0.5);
            border-color: #8B5CF6;
            transform: translateY(-2px);
        }

        .btn-gradient-hover {
            background: linear-gradient(135deg, #8B5CF6, #EC4899, #F59E0B);
            background-size: 200% 200%;
            transition: all 0.4s cubic-bezier(0.4, 0.0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .btn-gradient-hover:hover {
            background-position: right center;
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 20px 40px -12px rgba(139, 92, 246, 0.6);
        }

        .btn-gradient-hover::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
            transition: left 0.6s;
        }

        .btn-gradient-hover:hover::before {
            left: 100%;
        }

        .floating-orbs {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        .orb {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: float 12s ease-in-out infinite;
            filter: blur(1px);
        }

        .orb:nth-child(1) {
            width: 120px;
            height: 120px;
            top: 10%;
            left: 15%;
            background: radial-gradient(circle, rgba(139, 92, 246, 0.3), transparent);
            animation-delay: 0s;
        }

        .orb:nth-child(2) {
            width: 180px;
            height: 180px;
            top: 70%;
            right: 10%;
            background: radial-gradient(circle, rgba(236, 72, 153, 0.3), transparent);
            animation-delay: 3s;
        }

        .orb:nth-child(3) {
            width: 90px;
            height: 90px;
            top: 40%;
            left: 75%;
            background: radial-gradient(circle, rgba(245, 158, 11, 0.3), transparent);
            animation-delay: 6s;
        }

        .orb:nth-child(4) {
            width: 150px;
            height: 150px;
            top: 20%;
            right: 40%;
            background: radial-gradient(circle, rgba(16, 185, 129, 0.3), transparent);
            animation-delay: 9s;
        }

        .morphing-bg {
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(45deg,
                    rgba(139, 92, 246, 0.1),
                    rgba(236, 72, 153, 0.1),
                    rgba(245, 158, 11, 0.1),
                    rgba(16, 185, 129, 0.1));
            animation: morphing 15s ease-in-out infinite;
            z-index: -2;
        }

        .notification-slide-in {
            animation: slideInRight 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .notification-slide-out {
            animation: slideOutRight 0.4s ease-in-out;
        }

        @keyframes slideInRight {
            from { transform: translateX(500px) scale(0.8); opacity: 0; }
            to { transform: translateX(0) scale(1); opacity: 1; }
        }

        @keyframes slideOutRight {
            from { transform: translateX(0) scale(1); opacity: 1; }
            to { transform: translateX(500px) scale(0.8); opacity: 0; }
        }

        .progress-bar {
            transition: width 0.3s ease;
        }

        .select-custom {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%23ffffff' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
            background-position: right 0.5rem center;
            background-repeat: no-repeat;
            background-size: 1.5em 1.5em;
            padding-right: 2.5rem;
        }

        .loading-dots::after {
            content: '';
            animation: loadingDots 1.5s infinite;
        }

        @keyframes loadingDots {
            0%, 20% { content: ''; }
            40% { content: '.'; }
            60% { content: '..'; }
            80%, 100% { content: '...'; }
        }
    </style>
</head>

<body class="min-h-screen flex items-center justify-center p-4">
    <!-- Morphing Background -->
    <div class="morphing-bg"></div>

    <!-- Floating Orbs -->
    <div class="floating-orbs">
        <div class="orb"></div>
        <div class="orb"></div>
        <div class="orb"></div>
        <div class="orb"></div>
    </div>

    <!-- Enhanced Notification Container -->
    <div id="notificationContainer" class="fixed top-6 right-6 z-50 space-y-4 max-w-sm w-full"></div>

    <!-- Main Register Container -->
    <div class="glass-morphism rounded-3xl p-10 w-full max-w-lg transform animate-slide-up shadow-2xl relative">
        <!-- Decorative Elements -->
        <div class="absolute -top-6 -right-6 w-24 h-24 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full opacity-20 animate-bounce-subtle"></div>
        <div class="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-full opacity-30 animate-pulse"></div>

        <!-- Header -->
        <div class="text-center mb-10">
            <div class="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 mb-6 animate-bounce-subtle animate-pulse-glow">
                <i class="fas fa-water text-4xl text-white"></i>
            </div>
            <h2 class="text-4xl font-bold text-white mb-3 animate-fade-in">Bergabung dengan DigiDaw</h2>
            <p class="text-purple-100 text-lg animate-fade-in">Mulai perjalanan digital Anda bersama kami</p>
        </div>

        <!-- Register Form -->
        <form id="registerForm" action="/auth/doRegister" method="post" class="space-y-6">
            <?= csrf_field() ?>

            <!-- Role Selection -->
            <div class="space-y-3 animate-fade-in">
                <label for="role" class="block text-sm font-semibold text-purple-100">
                    <i class="fas fa-user-tag mr-2"></i>Daftar Sebagai
                </label>
                <select
                    id="role"
                    name="role"
                    required
                    class="w-full px-4 py-4 bg-white/10 border border-white/30 rounded-xl text-white placeholder-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent input-focus-glow transition-all duration-300 select-custom appearance-none">
                    <option value="" class="bg-purple-900 text-white">Pilih peran Anda</option>
                    <option value="pembeli" class="bg-purple-900 text-white">💳 Pembeli</option>
                    <option value="penjual" class="bg-purple-900 text-white">🏪 Penjual</option>
                </select>
            </div>

            <!-- Username Field -->
            <div class="space-y-3 animate-fade-in">
                <label for="username" class="block text-sm font-semibold text-purple-100">
                    <i class="fas fa-user mr-2"></i>Username
                </label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    value="<?= old('username') ?>"
                    required
                    class="w-full px-4 py-4 bg-white/10 border border-white/30 rounded-xl text-white placeholder-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent input-focus-glow transition-all duration-300"
                    placeholder="Pilih username unik Anda"
                    minlength="3"
                    maxlength="50">
            </div>

            <!-- Email Field -->
            <div class="space-y-3 animate-fade-in">
                <label for="email" class="block text-sm font-semibold text-purple-100">
                    <i class="fas fa-envelope mr-2"></i>Email
                </label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?= old('email') ?>"
                    required
                    class="w-full px-4 py-4 bg-white/10 border border-white/30 rounded-xl text-white placeholder-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent input-focus-glow transition-all duration-300"
                    placeholder="alamat@email.com">
            </div>

            <!-- Password Field -->
            <div class="space-y-3 animate-fade-in">
                <label for="password" class="block text-sm font-semibold text-purple-100">
                    <i class="fas fa-lock mr-2"></i>Password
                </label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    required
                    class="w-full px-4 py-4 bg-white/10 border border-white/30 rounded-xl text-white placeholder-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent input-focus-glow transition-all duration-300"
                    placeholder="Buat password yang kuat"
                    minlength="6">
            </div>

            <!-- Confirm Password Field -->
            <div class="space-y-3 animate-fade-in">
                <label for="confirm_password" class="block text-sm font-semibold text-purple-100">
                    <i class="fas fa-lock mr-2"></i>Konfirmasi Password
                </label>
                <input
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    required
                    class="w-full px-4 py-4 bg-white/10 border border-white/30 rounded-xl text-white placeholder-purple-200 focus:outline-none focus:ring-2 focus:ring-purple-400 focus:border-transparent input-focus-glow transition-all duration-300"
                    placeholder="Ulangi password Anda">
            </div>

            <!-- Terms and Conditions -->
            <div class="flex items-start space-x-3 animate-fade-in">
                <input
                    type="checkbox"
                    id="terms"
                    name="terms"
                    required
                    class="w-5 h-5 mt-1 text-purple-500 bg-white/10 border border-white/30 rounded focus:ring-purple-400 focus:ring-2">
                <label for="terms" class="text-sm text-purple-100 leading-relaxed">
                    Saya menyetujui
                    <a href="#" class="text-white font-semibold hover:text-purple-200 underline transition-colors">Syarat & Ketentuan</a>
                    dan
                    <a href="#" class="text-white font-semibold hover:text-purple-200 underline transition-colors">Kebijakan Privasi</a>
                </label>
            </div>

            <!-- Register Button -->
            <button
                type="submit"
                id="submitBtn"
                class="w-full btn-gradient-hover text-white font-bold py-4 px-6 rounded-xl transform transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-purple-300">
                <span id="btnText" class="flex items-center justify-center">
                    <i class="fas fa-user-plus mr-3"></i>
                    Daftar Sekarang
                </span>
            </button>
        </form>

        <!-- Social Register -->
        <div class="mt-10">
            <div class="relative">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-white/30"></div>
                </div>
                <div class="relative flex justify-center text-sm">
                    <span class="px-4 bg-transparent text-purple-100 font-medium">Atau daftar dengan</span>
                </div>
            </div>
            <div class="mt-6 grid grid-cols-3 gap-4">
                <button class="flex justify-center py-3 px-4 border border-white/30 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 transform hover:scale-110 hover:rotate-3">
                    <i class="fab fa-google text-xl"></i>
                </button>
                <button class="flex justify-center py-3 px-4 border border-white/30 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 transform hover:scale-110 hover:-rotate-3">
                    <i class="fab fa-facebook text-xl"></i>
                </button>
                <button class="flex justify-center py-3 px-4 border border-white/30 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 transform hover:scale-110 hover:rotate-3">
                    <i class="fab fa-twitter text-xl"></i>
                </button>
            </div>
        </div>

        <!-- Login Link -->
        <div class="mt-10 text-center">
            <p class="text-purple-100 text-lg">
                Sudah punya akun?
                <a href="/auth/login" class="font-bold text-white hover:text-purple-200 transition-colors duration-300 underline decoration-2 underline-offset-4 hover:decoration-purple-200">
                    Masuk sekarang
                </a>
            </p>
        </div>
    </div>

    <script>
        // Enhanced Notification System
        class AdvancedNotificationManager {
            constructor() {
                this.container = document.getElementById('notificationContainer');
                this.notifications = [];
                this.init();
            }

            init() {
                this.showInitialNotifications();
                this.setupSoundEffects();
            }

            setupSoundEffects() {
                this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            }

            playNotificationSound(type) {
                const frequencies = {
                    success: [523.25, 659.25, 783.99], // C5, E5, G5
                    error: [329.63, 261.63], // E4, C4
                    warning: [440, 554.37], // A4, C#5
                    info: [440] // A4
                };
                const freq = frequencies[type] || frequencies.info;
                freq.forEach((f, i) => setTimeout(() => this.playTone(f, 0.1), i * 100));
            }

            playTone(frequency, duration) {
                const oscillator = this.audioContext.createOscillator();
                const gainNode = this.audioContext.createGain();
                oscillator.connect(gainNode);
                gainNode.connect(this.audioContext.destination);
                oscillator.frequency.value = frequency;
                oscillator.type = 'sine';
                gainNode.gain.setValueAtTime(0.1, this.audioContext.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioContext.currentTime + duration);
                oscillator.start(this.audioContext.currentTime);
                oscillator.stop(this.audioContext.currentTime + duration);
            }

            showInitialNotifications() {
                <?php if (session()->getFlashdata('errors')): ?>
                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                        this.showNotification('<?= esc(addslashes($error)) ?>', 'error');
                    <?php endforeach; ?>
                <?php elseif (session()->getFlashdata('error')): ?>
                    this.showNotification('<?= esc(addslashes(session()->getFlashdata('error'))) ?>', 'error');
                <?php endif; ?>
                <?php if (session()->getFlashdata('success')): ?>
                    this.showNotification('<?= esc(addslashes(session()->getFlashdata('success'))) ?>', 'success', 7000, '/auth/login');
                <?php endif; ?>
            }

            showNotification(message, type = 'info', duration = 6000, redirectUrl = null) {
                const id = 'notification-' + Date.now() + Math.random();
                const icons = { success: 'fas fa-check-circle', error: 'fas fa-exclamation-circle', warning: 'fas fa-exclamation-triangle', info: 'fas fa-info-circle' };
                const colors = { success: 'from-emerald-500 via-green-500 to-teal-500', error: 'from-red-500 via-rose-500 to-pink-500', warning: 'from-amber-500 via-orange-500 to-yellow-500', info: 'from-blue-500 via-indigo-500 to-purple-500' };
                const bgColors = { success: 'rgba(16, 185, 129, 0.1)', error: 'rgba(239, 68, 68, 0.1)', warning: 'rgba(245, 158, 11, 0.1)', info: 'rgba(59, 130, 246, 0.1)' };

                const notification = document.createElement('div');
                notification.id = id;
                notification.className = `notification-slide-in glass-morphism rounded-2xl p-6 shadow-2xl transform transition-all duration-300 hover:scale-105 border-l-4`;
                notification.style.backgroundColor = bgColors[type];
                notification.style.borderLeftColor = type === 'success' ? '#10B981' : type === 'error' ? '#EF4444' : type === 'warning' ? '#F59E0B' : '#3B82F6';

                notification.innerHTML = `
                    <div class="flex items-start space-x-4">
                        <div class="flex-shrink-0">
                            <div class="w-12 h-12 rounded-full bg-gradient-to-r ${colors[type]} flex items-center justify-center animate-success-scale">
                                <i class="${icons[type]} text-white text-lg"></i>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <div class="flex items-center justify-between">
                                <h4 class="text-sm font-bold text-white mb-1">${this.getNotificationTitle(type)}</h4>
                                <button onclick="notificationManager.removeNotification('${id}')" class="flex-shrink-0 text-white/60 hover:text-white transition-colors hover:rotate-90 transform duration-300">
                                    <i class="fas fa-times text-lg"></i>
                                </button>
                            </div>
                            <p class="text-sm text-white/90 leading-relaxed">${message}</p>
                            ${redirectUrl ? `
                                <div class="mt-4 flex space-x-3">
                                    <a href="${redirectUrl}" class="inline-flex items-center px-4 py-2 bg-white/20 hover:bg-white/30 text-white text-sm rounded-lg transition-all duration-300 transform hover:scale-105">
                                        <i class="fas fa-arrow-right mr-2"></i>
                                        ${type === 'success' ? 'Login Sekarang' : 'Lanjutkan'}
                                    </a>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                    <div class="absolute bottom-0 left-0 h-1 bg-gradient-to-r ${colors[type]} rounded-full transition-all duration-${duration}" style="width: 100%; animation: shrinkProgress ${duration}ms linear forwards;"></div>
                `;

                this.container.appendChild(notification);
                this.notifications.push(id);
                this.playNotificationSound(type);

                if (duration > 0) {
                    setTimeout(() => this.removeNotification(id), duration);
                }

                if (redirectUrl) {
                    const link = notification.querySelector('a');
                    if (link) link.addEventListener('click', () => this.removeNotification(id));
                }
            }

            getNotificationTitle(type) {
                const titles = { success: '✨ Berhasil!', error: '⚠️ Oops!', warning: '🔔 Perhatian', info: 'ℹ️ Informasi' };
                return titles[type] || titles.info;
            }

            removeNotification(id) {
                const notification = document.getElementById(id);
                if (notification) {
                    notification.classList.remove('notification-slide-in');
                    notification.classList.add('notification-slide-out');
                    setTimeout(() => {
                        if (notification.parentNode) {
                            notification.parentNode.removeChild(notification);
                            this.notifications = this.notifications.filter(n => n !== id);
                        }
                    }, 400);
                }
            }
        }

        const notificationManager = new AdvancedNotificationManager();

        const style = document.createElement('style');
        style.textContent = `@keyframes shrinkProgress { 0% { width: 100%; } 100% { width: 0%; } }`;
        document.head.appendChild(style);

        // Form Validation and Enhancement
        class FormEnhancer {
            constructor() {
                this.form = document.getElementById('registerForm');
                this.submitBtn = document.getElementById('submitBtn');
                this.btnText = document.getElementById('btnText');
                this.init();
            }

            init() {
                this.setupEventListeners();
            }

            setupEventListeners() {
                this.form.addEventListener('submit', (e) => this.handleSubmit(e));
            }

            handleSubmit(e) {
                e.preventDefault();
                this.btnText.innerHTML = `
                    <span class="flex items-center justify-center">
                        <div class="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                        <span class="loading-dots">Mendaftar</span>
                    </span>
                `;
                this.submitBtn.disabled = true;
                this.form.submit();
            }
        }

        const formEnhancer = new FormEnhancer();

        document.addEventListener('mousemove', function(e) {
            const orbs = document.querySelectorAll('.orb');
            const x = e.clientX / window.innerWidth;
            const y = e.clientY / window.innerHeight;
            orbs.forEach((orb, index) => {
                const speed = (index + 1) * 0.3;
                const moveX = (x - 0.5) * speed * 30;
                const moveY = (y - 0.5) * speed * 30;
                orb.style.transform = `translate(${moveX}px, ${moveY}px)`;
            });
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                const focusedElement = document.activeElement;
                if (focusedElement.tagName === 'INPUT' || focusedElement.tagName === 'SELECT') {
                    focusedElement.style.transform = 'scale(1.02)';
                    setTimeout(() => { focusedElement.style.transform = 'scale(1)'; }, 200);
                }
            }
        });
    </script>
</body>

</html>