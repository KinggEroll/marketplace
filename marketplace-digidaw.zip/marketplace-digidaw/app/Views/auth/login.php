<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - DigiDaw</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                    },
                    animation: {
                        'float': 'float 6s ease-in-out infinite',
                        'slide-up': 'slideUp 0.6s ease-out',
                        'fade-in': 'fadeIn 0.8s ease-out',
                        'bounce-subtle': 'bounceSubtle 2s ease-in-out infinite',
                        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
                        'gradient-shift': 'gradientShift 8s ease-in-out infinite',
                        'shake': 'shake 0.5s ease-in-out',
                    },
                    keyframes: {
                        float: {
                            '0%, 100%': {
                                transform: 'translateY(0px)'
                            },
                            '50%': {
                                transform: 'translateY(-20px)'
                            }
                        },
                        slideUp: {
                            '0%': {
                                transform: 'translateY(100px)',
                                opacity: '0'
                            },
                            '100%': {
                                transform: 'translateY(0)',
                                opacity: '1'
                            }
                        },
                        fadeIn: {
                            '0%': {
                                opacity: '0'
                            },
                            '100%': {
                                opacity: '1'
                            }
                        },
                        bounceSubtle: {
                            '0%, 100%': {
                                transform: 'translateY(0px)'
                            },
                            '50%': {
                                transform: 'translateY(-5px)'
                            }
                        },
                        pulseGlow: {
                            '0%, 100%': {
                                boxShadow: '0 0 20px rgba(59, 130, 246, 0.3)'
                            },
                            '50%': {
                                boxShadow: '0 0 40px rgba(59, 130, 246, 0.6)'
                            }
                        },
                        gradientShift: {
                            '0%, 100%': {
                                backgroundPosition: '0% 50%'
                            },
                            '50%': {
                                backgroundPosition: '100% 50%'
                            }
                        },
                        shake: {
                            '0%, 100%': {
                                transform: 'translateX(0)'
                            },
                            '25%': {
                                transform: 'translateX(-5px)'
                            },
                            '75%': {
                                transform: 'translateX(5px)'
                            }
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(-45deg, #667eea, #764ba2, #f093fb, #f5576c, #4facfe, #00f2fe);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            overflow-x: hidden;
        }

        .glass-effect {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .input-glow:focus {
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.4);
            border-color: #3b82f6;
        }

        .btn-hover {
            transition: all 0.3s cubic-bezier(0.4, 0.0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .btn-hover:before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: left 0.5s;
        }

        .btn-hover:hover:before {
            left: 100%;
        }

        .floating-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        .shape {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: float 8s ease-in-out infinite;
        }

        .shape:nth-child(1) {
            width: 80px;
            height: 80px;
            top: 20%;
            left: 10%;
            animation-delay: 0s;
        }

        .shape:nth-child(2) {
            width: 120px;
            height: 120px;
            top: 60%;
            right: 15%;
            animation-delay: 2s;
        }

        .shape:nth-child(3) {
            width: 60px;
            height: 60px;
            top: 80%;
            left: 80%;
            animation-delay: 4s;
        }

        .notification-enter {
            animation: slideInRight 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .notification-exit {
            animation: slideOutRight 0.3s ease-in-out;
        }

        @keyframes slideInRight {
            from {
                transform: translateX(400px);
                opacity: 0;
            }

            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }

            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }

        .loading-overlay {
            background: rgba(0, 0, 0, 0.7);
            backdrop-filter: blur(5px);
        }

        .spinner {
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 3px solid #3b82f6;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
</head>

<body class="min-h-screen flex items-center justify-center p-4">
    <!-- Floating Shapes Background -->
    <div class="floating-shapes">
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="fixed inset-0 loading-overlay flex items-center justify-center z-50 hidden">
        <div class="text-center">
            <div class="spinner mx-auto mb-4"></div>
            <p class="text-white text-lg font-medium">Memproses login...</p>
        </div>
    </div>

    <!-- Notification Container -->
    <div id="notificationContainer" class="fixed top-6 right-6 z-40 space-y-4 max-w-sm w-full"></div>

    <!-- Main Login Container -->
    <div class="glass-effect rounded-3xl p-8 w-full max-w-md transform animate-slide-up shadow-2xl">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mb-6 animate-bounce-subtle">
                <i class="fas fa-water text-3xl text-white"></i>
            </div>
            <h2 class="text-3xl font-bold text-white mb-2">Selamat Datang</h2>
            <p class="text-blue-100">Masuk ke akun DigiDaw Anda</p>
        </div>

        <!-- Login Form -->
        <form id="loginForm" action="/auth/doLogin" method="post" class="space-y-6">
            <?= csrf_field() ?>

            <?php if ($redirect ?? null): ?>
                <input type="hidden" name="redirect" value="<?= esc($redirect) ?>">
            <?php endif; ?>

            <!-- Username Field -->
            <div class="space-y-2">
                <label for="username" class="block text-sm font-medium text-blue-100">
                    <i class="fas fa-user mr-2"></i>Username
                </label>
                <div class="relative">
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value="<?= old('username') ?>"
                        required
                        class="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-xl text-white placeholder-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent input-glow transition-all duration-300"
                        placeholder="Masukkan username Anda">
                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center">
                        <i class="fas fa-user text-blue-300"></i>
                    </div>
                </div>
            </div>

            <!-- Password Field -->
            <div class="space-y-2">
                <label for="password" class="block text-sm font-medium text-blue-100">
                    <i class="fas fa-lock mr-2"></i>Password
                </label>
                <div class="relative">
                    <input
                        type="password"
                        id="password"
                        name="password"
                        required
                        class="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-xl text-white placeholder-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent input-glow transition-all duration-300"
                        placeholder="Masukkan password Anda">
                    <button
                        type="button"
                        id="togglePassword"
                        class="absolute inset-y-0 right-0 pr-3 flex items-center text-blue-300 hover:text-blue-100 transition-colors">
                        <i class="fas fa-eye" id="eyeIcon"></i>
                    </button>
                </div>
            </div>

            <!-- Remember Me -->
            <div class="flex items-center justify-between">
                <label class="flex items-center text-blue-100 cursor-pointer group">
                    <input
                        type="checkbox"
                        name="remember_me"
                        class="w-4 h-4 text-blue-500 bg-white/20 border border-white/30 rounded focus:ring-blue-400 focus:ring-2">
                    <span class="ml-2 text-sm group-hover:text-white transition-colors">Ingat Saya</span>
                </label>
                <a href="#" class="text-sm text-blue-200 hover:text-white transition-colors duration-300">
                    Lupa Password?
                </a>
            </div>

            <!-- Login Button -->
            <button
                type="submit"
                class="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-3 px-6 rounded-xl btn-hover transform hover:scale-105 hover:shadow-2xl focus:outline-none focus:ring-4 focus:ring-blue-300 transition-all duration-300 animate-pulse-glow">
                <span class="flex items-center justify-center">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Masuk
                </span>
            </button>
        </form>

        <!-- Social Login -->
        <div class="mt-8">
            <div class="relative">
                <div class="absolute inset-0 flex items-center">
                    <div class="w-full border-t border-white/30"></div>
                </div>
                <div class="relative flex justify-center text-sm">
                    <span class="px-2 bg-transparent text-blue-100">Atau masuk dengan</span>
                </div>
            </div>

            <div class="mt-6 grid grid-cols-2 gap-3">
                <button class="w-full inline-flex justify-center py-2 px-4 border border-white/30 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                    <i class="fab fa-google text-xl"></i>
                </button>
                <button class="w-full inline-flex justify-center py-2 px-4 border border-white/30 rounded-xl bg-white/10 text-white hover:bg-white/20 transition-all duration-300 transform hover:scale-105">
                    <i class="fab fa-facebook text-xl"></i>
                </button>
            </div>
        </div>

        <!-- Register Link -->
        <div class="mt-8 text-center">
            <p class="text-blue-100">
                Belum punya akun?
                <a href="/auth/register" class="font-semibold text-white hover:text-blue-200 transition-colors duration-300 underline decoration-2 underline-offset-4">
                    Daftar sekarang
                </a>
            </p>
        </div>
    </div>

    <script>
        // Enhanced Notification System
        class NotificationManager {
            constructor() {
                this.container = document.getElementById('notificationContainer');
                this.notifications = [];
                this.showInitialNotifications();
            }

            showInitialNotifications() {
                <?php
                $error = session()->getFlashdata('error');
                $success = session()->getFlashdata('success');

                if ($error) {
                    echo "this.showNotification(" . json_encode($error) . ", 'error');" . PHP_EOL;
                }

                if ($success) {
                    echo "this.showNotification(" . json_encode($success) . ", 'success');" . PHP_EOL;
                }
                ?>
            }

            showNotification(message, type = 'info', duration = 5000) {
                const id = 'notification-' + Date.now();
                const icons = {
                    success: 'fas fa-check-circle',
                    error: 'fas fa-exclamation-circle',
                    warning: 'fas fa-exclamation-triangle',
                    info: 'fas fa-info-circle'
                };

                const colors = {
                    success: 'from-green-500 to-emerald-600',
                    error: 'from-red-500 to-rose-600',
                    warning: 'from-yellow-500 to-orange-600',
                    info: 'from-blue-500 to-indigo-600'
                };

                const notification = document.createElement('div');
                notification.id = id;
                notification.className = `notification-enter glass-effect rounded-xl p-4 shadow-2xl transform transition-all duration-300 hover:scale-105`;

                notification.innerHTML = `
                    <div class="flex items-start space-x-3">
                        <div class="flex-shrink-0">
                            <div class="w-8 h-8 rounded-full bg-gradient-to-r ${colors[type]} flex items-center justify-center">
                                <i class="${icons[type]} text-white text-sm"></i>
                            </div>
                        </div>
                        <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-white">${message}</p>
                        </div>
                        <button onclick="notificationManager.removeNotification('${id}')" class="flex-shrink-0 text-white/60 hover:text-white transition-colors">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="absolute bottom-0 left-0 h-1 bg-gradient-to-r ${colors[type]} rounded-full transition-all duration-${duration}" style="width: 100%; animation: shrink ${duration}ms linear forwards;"></div>
                `;

                this.container.appendChild(notification);
                this.notifications.push(id);

                if (duration > 0) {
                    setTimeout(() => {
                        this.removeNotification(id);
                    }, duration);
                }
            }

            removeNotification(id) {
                const notification = document.getElementById(id);
                if (notification) {
                    notification.classList.remove('notification-enter');
                    notification.classList.add('notification-exit');
                    setTimeout(() => {
                        if (notification.parentNode) {
                            notification.parentNode.removeChild(notification);
                        }
                        this.notifications = this.notifications.filter(n => n !== id);
                    }, 300);
                }
            }
        }

        // Initialize notification manager
        const notificationManager = new NotificationManager();

        // Add shrink animation to CSS
        const style = document.createElement('style');
        style.textContent = `
            @keyframes shrink {
                0% { width: 100%; }
                100% { width: 0%; }
            }
        `;
        document.head.appendChild(style);

        // Password toggle functionality
        document.getElementById('togglePassword').addEventListener('click', function() {
            const password = document.getElementById('password');
            const eyeIcon = document.getElementById('eyeIcon');

            if (password.type === 'password') {
                password.type = 'text';
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            } else {
                password.type = 'password';
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            }
        });

        // Form submission with loading
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const loadingOverlay = document.getElementById('loadingOverlay');
            const submitBtn = this.querySelector('button[type="submit"]');

            // Show loading
            loadingOverlay.classList.remove('hidden');
            submitBtn.disabled = true;
            submitBtn.innerHTML = `
                <span class="flex items-center justify-center">
                    <div class="spinner w-5 h-5 mr-2"></div>
                    Memproses...
                </span>
            `;
        });

        // Input animations
        document.querySelectorAll('input').forEach(input => {
            input.addEventListener('focus', function() {
                this.parentElement.style.transform = 'scale(1.02)';
            });

            input.addEventListener('blur', function() {
                this.parentElement.style.transform = 'scale(1)';
            });

            // Error shake animation
            input.addEventListener('invalid', function() {
                this.classList.add('animate-shake');
                setTimeout(() => {
                    this.classList.remove('animate-shake');
                }, 500);
            });
        });

        // Parallax effect for floating shapes
        document.addEventListener('mousemove', function(e) {
            const shapes = document.querySelectorAll('.shape');
            const x = e.clientX / window.innerWidth;
            const y = e.clientY / window.innerHeight;

            shapes.forEach((shape, index) => {
                const speed = (index + 1) * 0.5;
                const moveX = (x - 0.5) * speed * 20;
                const moveY = (y - 0.5) * speed * 20;
                shape.style.transform = `translate(${moveX}px, ${moveY}px)`;
            });
        });

        // Keyboard navigation
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.tagName !== 'BUTTON') {
                const form = document.getElementById('loginForm');
                const inputs = form.querySelectorAll('input');
                const currentIndex = Array.from(inputs).indexOf(document.activeElement);

                if (currentIndex < inputs.length - 1) {
                    inputs[currentIndex + 1].focus();
                } else {
                    form.querySelector('button[type="submit"]').focus();
                }
            }
        });
    </script>
</body>

</html>