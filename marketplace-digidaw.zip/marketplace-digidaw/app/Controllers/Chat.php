<?php

namespace App\Controllers;

use App\Models\MessageModel;
use App\Models\OrderModel;
use App\Models\UserModel;
use App\Models\ProductModel;
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Database\Exceptions\DatabaseException;

/**
 * Controller untuk mengelola fungsi chat.
 * @package App\Controllers
 */
class Chat extends BaseController
{
    use ResponseTrait;

    /** @var MessageModel */
    protected $messageModel;
    /** @var OrderModel */
    protected $orderModel;
    /** @var UserModel */
    protected $userModel;
    /** @var ProductModel */
    protected $productModel;
    /** @var \CodeIgniter\Database\ConnectionInterface */
    protected $db; // Deklarasi properti

    public function __construct()
    {
        helper(['form', 'url']);
        $this->messageModel = new MessageModel();
        $this->orderModel = new OrderModel();
        $this->userModel = new UserModel();
        $this->productModel = new ProductModel();
        $this->db = \Config\Database::connect(); // Inisialisasi
    }

    /**
     * Mendapatkan daftar percakapan untuk pengguna yang login.
     * @return \CodeIgniter\HTTP\Response
     */
    public function index()
    {
        if (!session()->get('logged_in')) {
            log_message('error', 'Chat/index: User not logged in');
            return $this->respond(['success' => false, 'message' => 'Silakan login terlebih dahulu'], 401);
        }

        $userId = (int)session()->get('user_id');
        $user = $this->userModel->find($userId);
        if (!$user) {
            log_message('error', "Chat/index: Invalid user, user_id: $userId");
            return $this->respond(['success' => false, 'message' => 'Akun tidak valid'], 400);
        }

        $conversations = $this->messageModel->getConversations($userId);

        return $this->respond([
            'success' => true,
            'conversations' => $conversations
        ], 200);
    }

    /**
     * Mendapatkan pesan untuk order tertentu.
     * @param int $orderId
     * @return \CodeIgniter\HTTP\Response
     */
    public function getMessages($orderId)
    {
        if (!session()->get('logged_in')) {
            log_message('error', 'Chat/getMessages: User not logged in');
            return $this->respond(['success' => false, 'message' => 'Silakan login terlebih dahulu'], 401);
        }

        $userId = (int)session()->get('user_id');
        $orderId = (int)$orderId;

        $user = $this->userModel->find($userId);
        if (!$user) {
            log_message('error', "Chat/getMessages: Invalid user, user_id: $userId");
            return $this->respond(['success' => false, 'message' => 'Akun tidak valid'], 400);
        }

        try {
            $order = $this->orderModel
                ->select('orders.*, products.seller_id, products.name as product_name')
                ->join('order_details', 'orders.order_id = order_details.order_id', 'left')
                ->join('products', 'order_details.product_id = products.product_id', 'left')
                ->where('orders.order_id', $orderId)
                ->groupStart()
                ->where('orders.buyer_id', $userId)
                ->orWhere('products.seller_id', $userId)
                ->groupEnd()
                ->first();

            if (!$order) {
                log_message('error', "Chat/getMessages: Order not found or no access, user_id: $userId, order_id: $orderId");
                return $this->respond(['success' => false, 'message' => 'Pesanan tidak ditemukan atau Anda tidak memiliki akses'], 400);
            }

            $messages = $this->messageModel
                ->select('messages.*, users.username as sender_name')
                ->join('users', 'users.user_id = messages.sender_id', 'left')
                ->where('messages.order_id', $orderId)
                ->orderBy('messages.created_at', 'ASC')
                ->findAll();

            $this->messageModel
                ->where('order_id', $orderId)
                ->where('receiver_id', $userId)
                ->where('is_read', 0)
                ->set(['is_read' => 1])
                ->update();

            foreach ($messages as &$msg) {
                $msg['message'] = esc($msg['message'] ?? '');
                $msg['sender_id'] = (int)($msg['sender_id'] ?? 0);
                $msg['receiver_id'] = (int)($msg['receiver_id'] ?? 0);
                $msg['sender_name'] = esc($msg['sender_name'] ?? '');
            }

            return $this->respond([
                'success' => true,
                'messages' => $messages,
                'order' => [
                    'order_id' => (int)$order['order_id'],
                    'product_name' => esc($order['product_name'] ?? ''),
                    'other_party_id' => ($order['buyer_id'] == $userId) ? $order['seller_id'] : $order['buyer_id']
                ]
            ], 200);
        } catch (DatabaseException $e) {
            log_message('error', "Chat/getMessages: Database error, user_id: $userId, order_id: $orderId, error: " . $e->getMessage());
            return $this->respond(['success' => false, 'message' => 'Kesalahan database'], 500);
        }
    }

    /**
     * Mengirim pesan baru.
     * @return \CodeIgniter\HTTP\Response
     */
    public function sendMessage()
    {
        if (!session()->get('logged_in')) {
            log_message('error', 'Chat/sendMessage: User not logged in');
            return $this->respond(['success' => false, 'message' => 'Silakan login terlebih dahulu'], 401);
        }

        $userId = (int)session()->get('user_id');
        $orderId = (int)$this->request->getPost('order_id');
        $message = esc($this->request->getPost('message'));

        if (empty($orderId) || empty($message)) {
            log_message('error', "Chat/sendMessage: Incomplete data, user_id: $userId, order_id: $orderId");
            return $this->respond(['success' => false, 'message' => 'Data tidak lengkap'], 400);
        }

        $user = $this->userModel->find($userId);
        if (!$user) {
            log_message('error', "Chat/sendMessage: Invalid user, user_id: $userId");
            return $this->respond(['success' => false, 'message' => 'Akun tidak valid'], 400);
        }

        if ($user['role'] === 'penjual' && $user['verification_status'] !== 'verified') {
            log_message('error', "Chat/sendMessage: Account not verified, user_id: $userId");
            return $this->respond(['success' => false, 'message' => 'Akun Anda belum diverifikasi'], 403);
        }

        try {
            $order = $this->orderModel
                ->select('orders.*, products.seller_id')
                ->join('order_details', 'orders.order_id = order_details.order_id', 'left')
                ->join('products', 'order_details.product_id = products.product_id', 'left')
                ->where('orders.order_id', $orderId)
                ->groupStart()
                ->where('orders.buyer_id', $userId)
                ->orWhere('products.seller_id', $userId)
                ->groupEnd()
                ->first();

            if (!$order) {
                log_message('error', "Chat/sendMessage: Order not found or no access, user_id: $userId, order_id: $orderId");
                return $this->respond(['success' => false, 'message' => 'Pesanan tidak ditemukan atau Anda tidak memiliki akses'], 400);
            }

            $receiverId = (int)(($order['buyer_id'] == $userId) ? $order['seller_id'] : $order['buyer_id']);
            $receiver = $this->userModel->find($receiverId);
            if (!$receiver) {
                log_message('error', "Chat/sendMessage: Invalid receiver_id, user_id: $userId, receiver_id: $receiverId");
                return $this->respond(['success' => false, 'message' => 'Penerima pesan tidak valid'], 400);
            }

            $messageData = [
                'order_id' => $orderId,
                'sender_id' => $userId,
                'receiver_id' => $receiverId,
                'message' => $message,
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s'),
                'last_message_at' => date('Y-m-d H:i:s')
            ];

            if ($this->messageModel->insert($messageData)) {
                $newMessage = $this->messageModel
                    ->select('messages.*, users.username as sender_name')
                    ->join('users', 'users.user_id = messages.sender_id', 'left')
                    ->where('messages.message_id', $this->messageModel->getInsertID())
                    ->first();

                log_message('info', "Chat/sendMessage: Message sent successfully, user_id: $userId, order_id: $orderId");
                return $this->respond([
                    'success' => true,
                    'message' => 'Pesan berhasil dikirim',
                    'data' => [
                        'message_id' => (int)$newMessage['message_id'],
                        'order_id' => (int)$newMessage['order_id'],
                        'sender_id' => (int)$newMessage['sender_id'],
                        'receiver_id' => (int)$newMessage['receiver_id'],
                        'message' => esc($newMessage['message'] ?? ''),
                        'sender_name' => esc($newMessage['sender_name'] ?? '')
                    ]
                ], 200);
            }

            log_message('error', "Chat/sendMessage: Failed to insert message, user_id: $userId, order_id: $orderId");
            return $this->respond(['success' => false, 'message' => 'Gagal mengirim pesan'], 500);
        } catch (DatabaseException $e) {
            log_message('error', "Chat/sendMessage: Database error, user_id: $userId, order_id: $orderId, error: " . $e->getMessage());
            return $this->respond(['success' => false, 'message' => 'Kesalahan database'], 500);
        }
    }

    /**
     * Mendapatkan jumlah pesan yang belum dibaca.
     * @return \CodeIgniter\HTTP\Response
     */
    public function getUnreadCount()
    {
        if (!session()->get('logged_in')) {
            log_message('error', 'Chat/getUnreadCount: User not logged in');
            return $this->respond(['success' => false, 'message' => 'Silakan login terlebih dahulu'], 401);
        }

        $userId = (int)session()->get('user_id');
        $user = $this->userModel->find($userId);
        if (!$user) {
            log_message('error', "Chat/getUnreadCount: Invalid user, user_id: $userId");
            return $this->respond(['success' => false, 'message' => 'Akun tidak valid'], 400);
        }

        if ($user['role'] === 'penjual' && $user['verification_status'] !== 'verified') {
            log_message('error', "Chat/getUnreadCount: Account not verified, user_id: $userId");
            return $this->respond(['success' => false, 'message' => 'Akun Anda belum diverifikasi'], 403);
        }

        try {
            $unreadCount = $this->messageModel
                ->where('receiver_id', $userId)
                ->where('is_read', 0)
                ->countAllResults();

            return $this->respond([
                'success' => true,
                'unread_count' => (int)$unreadCount
            ], 200);
        } catch (DatabaseException $e) {
            log_message('error', "Chat/getUnreadCount: Database error, user_id: $userId, error: " . $e->getMessage());
            return $this->respond(['success' => false, 'message' => 'Kesalahan database'], 500);
        }
    }

    /**
     * Memulai chat dengan penjual untuk order tertentu.
     * @return \CodeIgniter\HTTP\Response
     */
    public function startChatWithSeller()
    {
        // $receivedToken = $this->request->getHeaderLine('X-CSRF-Token') ?: $this->request->getPost('csrf_token');
        // log_message('debug', 'startChatWithSeller: Received CSRF token: ' . $receivedToken . ', Expected: ' . csrf_hash());

        // if (!$receivedToken || $receivedToken !== csrf_hash()) {
        //     return $this->fail('Invalid CSRF token', 403);
        // }

        // $orderId = $this->request->getPost('order_id');
        // $userId = session()->get('user_id');
        // $userRole = session()->get('role');

        // log_message('debug', 'startChatWithSeller: order_id=' . $orderId . ', user_id=' . $userId . ', role=' . $userRole);

        // if (!$orderId || !is_numeric($orderId)) {
        //     return $this->fail('Order ID tidak valid', 400);
        // }

        // $order = $this->orderModel->getOrderDetails($orderId);

        // if (empty($order)) {
        //     return $this->fail('Order tidak ditemukan', 404);
        // }

        // $isAuthorized = false;
        // foreach ($order as $item) {
        //     if ($userRole === 'pembeli' && $item['buyer_id'] == $userId) {
        //         $isAuthorized = true;
        //     } elseif ($userRole === 'penjual' && $item['seller_id'] == $userId) {
        //         $isAuthorized = true;
        //     }
        // }

        // if (!$isAuthorized) {
        //     return $this->fail('Anda tidak memiliki akses untuk memulai chat untuk order ini', 403);
        // }

        // if (!in_array($order[0]['status'], ['paid', 'delivered'])) {
        //     return $this->fail('Chat hanya tersedia untuk pesanan yang sudah dibayar atau dikirim', 400);
        // }

        // session()->set('chat_order_id', $orderId);

        // return $this->respond([
        //     'success' => true,
        //     'message' => 'Chat berhasil dimulai',
        //     'order_id' => $orderId,
        //     'csrf_token' => csrf_hash() // Return new CSRF token
        // ]);
    }
    /**
     * Polling untuk pesan baru.
     * @return \CodeIgniter\HTTP\Response
     */
    public function pollMessages()
    {
        if (!session()->get('logged_in')) {
            log_message('error', 'Chat/pollMessages: User not logged in');
            return $this->respond(['success' => false, 'message' => 'Silakan login terlebih dahulu'], 401);
        }

        $userId = (int)session()->get('user_id');
        $orderId = (int)$this->request->getGet('order_id');
        $lastMessageId = (int)($this->request->getGet('last_message_id') ?? 0);

        if (empty($orderId)) {
            log_message('error', "Chat/pollMessages: Missing order_id, user_id: $userId");
            return $this->respond(['success' => false, 'message' => 'Order ID diperlukan'], 400);
        }

        try {
            $newMessages = $this->messageModel
                ->select('messages.*, users.username as sender_name')
                ->join('users', 'users.user_id = messages.sender_id', 'left')
                ->where('messages.order_id', $orderId)
                ->where('messages.message_id >', $lastMessageId)
                ->orderBy('messages.created_at', 'ASC')
                ->findAll();

            if (!empty($newMessages)) {
                $messageIds = array_column($newMessages, 'message_id');
                $this->messageModel
                    ->whereIn('message_id', $messageIds)
                    ->where('receiver_id', $userId)
                    ->where('is_read', 0)
                    ->set(['is_read' => 1])
                    ->update();
            }

            foreach ($newMessages as &$msg) {
                $msg['message'] = esc($msg['message'] ?? '');
                $msg['sender_id'] = (int)($msg['sender_id'] ?? 0);
                $msg['receiver_id'] = (int)($msg['receiver_id'] ?? 0);
                $msg['sender_name'] = esc($msg['sender_name'] ?? '');
            }

            return $this->respond([
                'success' => true,
                'messages' => $newMessages,
                'unread_count' => (int)$this->messageModel
                    ->where('receiver_id', $userId)
                    ->where('is_read', 0)
                    ->countAllResults()
            ], 200);
        } catch (DatabaseException $e) {
            log_message('error', "Chat/pollMessages: Database error, user_id: $userId, order_id: $orderId, error: " . $e->getMessage());
            return $this->respond(['success' => false, 'message' => 'Kesalahan database'], 500);
        }
    }
    public function sendFile()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['success' => false, 'message' => 'Invalid request']);
        }

        $userId  = session()->get('user_id');
        $orderId = (int)$this->request->getPost('order_id');

        $file = $this->request->getFile('file');
        if (!$file || !$file->isValid()) {
            return $this->response->setJSON(['success' => false, 'message' => 'File tidak valid']);
        }

        // validasi order milik user / seller
        $order = $this->orderModel
            ->select('orders.*, products.seller_id')
            ->join('order_details', 'order_details.order_id = orders.order_id')
            ->join('products',      'products.product_id = order_details.product_id')
            ->where('orders.order_id', $orderId)
            ->groupStart()
            ->where('orders.buyer_id', $userId)
            ->orWhere('products.seller_id', $userId)
            ->groupEnd()
            ->first();

        if (!$order) {
            return $this->response->setJSON(['success' => false, 'message' => 'Order tidak valid']);
        }

        $newName = $file->getRandomName();
        $path    = WRITEPATH . 'uploads/chat/' . date('Y/m');
        if (!is_dir($path)) mkdir($path, 0755, true);
        $file->move($path, $newName);

        $url = base_url('writable/uploads/chat/' . date('Y/m') . '/' . $newName);

        $receiverId = ($userId == $order['buyer_id'])
            ? $order['seller_id']
            : $order['buyer_id'];

        $this->messageModel->insert([
            'order_id'    => $orderId,
            'sender_id'   => $userId,
            'receiver_id' => $receiverId,
            'message'     => $url,
            'is_read'     => 0,
            'created_at'  => date('Y-m-d H:i:s')
        ]);

        return $this->response->setJSON([
            'success' => true,
            'data' => [
                'message' => $url,
                'sender_name' => session()->get('username'),
                'created_at' => date('Y-m-d H:i:s')
            ]
        ]);
    }
}
