<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\WalletModel;
use CodeIgniter\HTTP\ResponseInterface;

class Profile extends BaseController
{
    protected $userModel;
    protected $walletModel;
    protected $session;

    public function __construct()
    {
        helper('form');
        $this->userModel = new UserModel();
        $this->walletModel = new WalletModel();
        $this->session = service('session');
    }

    public function edit()
    {
        if (!$this->session->get('logged_in') || $this->session->get('role') !== 'pembeli') {
            return redirect()->to('/auth/login');
        }

        $data = [
            'title' => 'Edit Profil', // Added title
            'isLoggedIn' => $this->session->get('logged_in'),
            'username' => $this->session->get('username'),
            'role' => $this->session->get('role'),
            'user' => $this->userModel->find($this->session->get('user_id'))
        ];

        return view('profile/edit', $data);
    }

    public function update(): ResponseInterface
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Permintaan tidak valid']);
        }

        $userId = $this->session->get('user_id');
        if (!$userId) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Pengguna belum login']);
        }

        $validationRules = [
            'username' => 'required|min_length[3]|max_length[50]|is_unique[users.username,user_id,' . $userId . ']',
            'email' => 'required|valid_email|is_unique[users.email,user_id,' . $userId . ']',
            'phone_number' => 'permit_empty|regex_match[/^08[0-9]{8,13}$/]',
            'address' => 'required|min_length[10]|max_length[255]'
        ];

        if (!$this->validate($validationRules)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Validasi gagal',
                'errors' => $this->validator->getErrors()
            ]);
        }

        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'phone_number' => $this->request->getPost('phone_number'),
            'address' => $this->request->getPost('address'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        // Handle profile picture upload
        $profilePicture = $this->request->getFile('profile_picture');
        if ($profilePicture && $profilePicture->isValid()) {
            $validationRule = [
                'profile_picture' => [
                    'label' => 'Foto Profil',
                    'rules' => 'uploaded[profile_picture]|is_image[profile_picture]|max_size[profile_picture,2048]|mime_in[profile_picture,image/jpeg,image/png,image/gif]'
                ]
            ];
            if (!$this->validate($validationRule)) {
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Validasi foto profil gagal',
                    'errors' => $this->validator->getErrors()
                ]);
            }

            $uploadPath = ROOTPATH . 'public/uploads/profiles/';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            $newName = $profilePicture->getRandomName();
            if ($profilePicture->move($uploadPath, $newName)) {
                $data['profile_picture'] = '/uploads/profiles/' . $newName;
                // Delete old profile picture if exists
                $oldPicture = $this->userModel->find($userId)['profile_picture'];
                if ($oldPicture && file_exists(ROOTPATH . 'public' . $oldPicture)) {
                    unlink(ROOTPATH . 'public' . $oldPicture);
                }
            } else {
                log_message('error', 'Gagal memindahkan foto profil: ' . $profilePicture->getErrorString());
                return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal mengunggah foto profil']);
            }
        }

        // Remove empty fields (except required ones)
        foreach (['phone_number'] as $key) {
            if (empty($data[$key])) unset($data[$key]);
        }

        if ($this->userModel->update($userId, $data)) {
            $this->session->set('username', $data['username']);
            return $this->response->setJSON(['status' => 'success', 'message' => 'Profil berhasil diperbarui']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal memperbarui profil']);
        }
    }

    public function deposit()
    {
        if (!$this->session->get('logged_in') || $this->session->get('role') !== 'pembeli') {
            return redirect()->to('/auth/login');
        }

        $data = [
            'isLoggedIn' => $this->session->get('logged_in'),
            'username' => $this->session->get('username'),
            'role' => $this->session->get('role'),
            'user' => $this->userModel->find($this->session->get('user_id'))
        ];

        return view('profile/deposit', $data);
    }

    public function processDeposit(): ResponseInterface
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Permintaan tidak valid']);
        }

        $userId = $this->session->get('user_id');
        if (!$userId) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Pengguna belum login']);
        }

        $validationRules = [
            'amount' => 'required|numeric|greater_than_equal_to[10000]',
            'payment_method' => 'required|in_list[bank_transfer,ewallet]',
            'confirmation_code' => 'required|exact_length[6]|alpha_numeric'
        ];

        if (!$this->validate($validationRules)) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Validasi gagal',
                'errors' => $this->validator->getErrors()
            ]);
        }

        $amount = $this->request->getPost('amount');
        $paymentMethod = $this->request->getPost('payment_method');
        $confirmationCode = $this->request->getPost('confirmation_code');

        // Simulate payment validation (e.g., check confirmation code)
        $validCode = 'DEMO123'; // Dummy code for simulation
        if ($confirmationCode !== $validCode) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Kode konfirmasi tidak valid']);
        }

        // Insert into wallets table
        $walletData = [
            'user_id' => $userId,
            'amount' => $amount,
            'type' => 'deposit',
            'description' => 'Deposit via ' . $paymentMethod,
            'created_at' => date('Y-m-d H:i:s')
        ];

        if ($this->walletModel->insert($walletData)) {
            // Note: Balance is updated via trigger in the database
            return $this->response->setJSON(['status' => 'success', 'message' => 'Deposit berhasil']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal memproses deposit']);
        }
    }
}
