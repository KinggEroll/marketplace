<?php

namespace App\Controllers;

use App\Models\ProductModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Product extends BaseController
{
    protected $productModel;

    public function __construct()
    {
        $this->productModel = new ProductModel();
    }

    public function detail($id)
    {
        $product = $this->productModel->where('seller_id', session()->get('user_id'))->find($id);
        if (!$product) {
            throw new PageNotFoundException('Produk tidak ditemukan atau Anda tidak memiliki akses.');
        }

        return view('seller/product_detail', [
            'title' => 'Detail Produk',
            'product' => $product,
            'username' => session()->get('username'),
            'needsVerification' => session()->get('verification_status') !== 'verified',
            'verificationStatus' => session()->get('verification_status') ?? 'non_verified'
        ]);
    }

    public function create()
    {
        log_message('debug', 'Product::create called for user_id: ' . session()->get('user_id') . ', verification_status: ' . session()->get('verification_status'));
        if (session()->get('verification_status') !== 'verified') {
            log_message('info', 'Product::create: User not verified, redirecting to /seller/verify');
            return redirect()->to('/seller/verify')->with('error', 'Akun Anda harus diverifikasi untuk menambahkan produk.');
        }

        $categoryModel = new \App\Models\CategoryModel();
        $categories = $categoryModel->findAll();

        return view('seller/tambahproduk', [
            'title' => 'Tambah Produk',
            'username' => session()->get('username'),
            'needsVerification' => session()->get('verification_status') !== 'verified',
            'verificationStatus' => session()->get('verification_status') ?? 'non_verified',
            'categories' => $categories
        ]);
    }

    public function store()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid request.']);
        }

        if (session()->get('verification_status') !== 'verified') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Akun Anda harus diverifikasi untuk menambahkan produk.']);
        }

        $validation = \Config\Services::validation();
        $validation->setRules([
            'name' => 'required|min_length[3]|max_length[100]',
            'category_id' => 'required|integer|is_not_unique[categories.category_id]',
            'price' => 'required|numeric|greater_than[0]',
            'stock' => 'required|integer|greater_than_equal_to[0]',
            'description' => 'permit_empty|string',
            'image' => 'uploaded[image]|max_size[image,1024]|is_image[image]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON(['status' => 'error', 'message' => $validation->getErrors()]);
        }

        $file = $this->request->getFile('image');
        $newName = $file->getRandomName();
        $file->move(ROOTPATH . 'public/uploads/products', $newName);

        $data = [
            'seller_id' => session()->get('user_id'),
            'category_id' => $this->request->getPost('category_id'),
            'name' => $this->request->getPost('name'),
            'price' => $this->request->getPost('price'),
            'stock' => $this->request->getPost('stock'),
            'description' => $this->request->getPost('description'),
            'image_url' => '/uploads/products/' . $newName,
            'status' => 'active',
            'created_at' => date('Y-m-d H:i:s')
        ];

        if ($this->productModel->insert($data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Produk berhasil ditambahkan']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal menambahkan produk']);
        }
    }
    public function edit($id)
    {
        $product = $this->productModel->where('seller_id', session()->get('user_id'))->find($id);
        if (!$product) {
            throw new PageNotFoundException('Produk tidak ditemukan atau Anda tidak memiliki akses.');
        }

        $categoryModel = new \App\Models\CategoryModel();
        $categories = $categoryModel->findAll();

        return view('seller/edit_product', [
            'title' => 'Edit Produk',
            'product' => $product,
            'username' => session()->get('username'),
            'needsVerification' => session()->get('verification_status') !== 'verified',
            'verificationStatus' => session()->get('verification_status') ?? 'non_verified',
            'categories' => $categories
        ]);
    }

    public function update($id)
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid request.']);
        }

        $product = $this->productModel->where('seller_id', session()->get('user_id'))->find($id);
        if (!$product) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Produk tidak ditemukan atau Anda tidak memiliki akses.']);
        }

        $validation = \Config\Services::validation();
        $validation->setRules([
            'name' => 'required|min_length[3]|max_length[100]',
            'category_id' => 'required|integer|is_not_unique[categories.category_id]',
            'price' => 'required|numeric|greater_than[0]',
            'stock' => 'required|integer|greater_than_equal_to[0]',
            'description' => 'permit_empty|string',
            'image' => 'if_exist|uploaded[image]|max_size[image,1024]|is_image[image]',
            'status' => 'required|in_list[active,inactive,out_of_stock]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON(['status' => 'error', 'message' => $validation->getErrors()]);
        }

        $data = [
            'name' => $this->request->getPost('name'),
            'category_id' => $this->request->getPost('category_id'),
            'price' => $this->request->getPost('price'),
            'stock' => $this->request->getPost('stock'),
            'description' => $this->request->getPost('description'),
            'status' => $this->request->getPost('status')
        ];

        $file = $this->request->getFile('image');
        if ($file && $file->isValid()) {
            $newName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/uploads/products', $newName);
            $data['image_url'] = '/uploads/products/' . $newName;

            if ($product['image_url'] && file_exists(ROOTPATH . 'public' . $product['image_url'])) {
                unlink(ROOTPATH . 'public' . $product['image_url']);
            }
        }

        if ($this->productModel->update($id, $data)) {
            return $this->response->setJSON(['status' => 'success', 'message' => 'Produk berhasil diperbarui']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal memperbarui produk']);
        }
    }

    public function delete($id)
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Invalid request.']);
        }

        $product = $this->productModel->where('seller_id', session()->get('user_id'))->find($id);
        if (!$product) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Produk tidak ditemukan atau Anda tidak memiliki akses.']);
        }

        if ($this->productModel->delete($id)) {
            if (!empty($product['image_url']) && file_exists(ROOTPATH . 'public' . $product['image_url'])) {
                unlink(ROOTPATH . 'public' . $product['image_url']);
            }
            return $this->response->setJSON(['status' => 'success', 'message' => 'Produk berhasil dihapus']);
        } else {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal menghapus produk']);
        }
    }
}
