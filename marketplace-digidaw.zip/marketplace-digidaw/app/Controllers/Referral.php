<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\NotificationModel;
use App\Models\CartModel; // Added CartModel

class Referral extends BaseController
{
    protected $userModel;
    protected $notificationModel;
    protected $cartModel; // Added property

    public function __construct()
    {
        helper(['form', 'url']);
        $this->userModel = new UserModel();
        $this->notificationModel = new NotificationModel();
        $this->cartModel = new CartModel(); // Initialized
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');

        // Ambil data user untuk mendapatkan referral code
        $user = $this->userModel->find($userId);
        $referralCode = $user['referral_code'] ?? $this->generateReferralCode($userId);

        // Ambil daftar user yang direferral
        $referrals = $this->userModel
            ->select('user_id, username, email, created_at')
            ->where('referred_by', $userId)
            ->findAll();

        $data = [
            'title' => 'Referral - DigiAw', // Fixed typo "DigiDaw" to "DigiAw"
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'referrals' => $referrals,
            'referralCode' => $referralCode,
            'stats' => [
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
                'total_referrals' => count($referrals),
                'cart_count' => $this->cartModel->where('user_id', $userId)->countAllResults(), // Added cart count
            ],
        ];

        return view('referral/index', $data);
    }

    private function generateReferralCode($userId)
    {
        $code = strtoupper(substr(md5($userId . time()), 0, 8));

        // Update user dengan referral code
        $this->userModel->update($userId, ['referral_code' => $code]);

        return $code;
    }

    public function copyCode()
    {
        if (!session()->get('logged_in')) {
            return $this->response->setJSON(['success' => false, 'message' => 'Unauthorized']);
        }

        $userId = session()->get('user_id');
        $user = $this->userModel->find($userId);
        $referralCode = $user['referral_code'] ?? $this->generateReferralCode($userId);

        return $this->response->setJSON([
            'success' => true,
            'code' => $referralCode,
            'message' => 'Kode referral berhasil disalin!'
        ]);
    }
}