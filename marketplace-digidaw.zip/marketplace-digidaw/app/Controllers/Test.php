<?php
namespace App\Controllers;

use CodeIgniter\Controller;

class Test extends Controller
{
    public function index()
    {
        // Coba koneksi ke database
        $db = \Config\Database::connect();
        if ($db->connID) {
            echo "Koneksi ke database berhasil!";
            // Cek tabel yang ada
            $tables = $db->listTables();
            echo "<h3>Daftar Tabel di Database:</h3>";
            echo "<ul>";
            foreach ($tables as $table) {
                echo "<li>$table</li>";
            }
            echo "</ul>";
        } else {
            echo "Gagal terhubung ke database.";
        }
    }
}