<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\OrderModel;
use App\Models\ReportModel;
use CodeIgniter\API\ResponseTrait;

class Report extends BaseController
{
    use ResponseTrait;

    protected $userModel;
    protected $orderModel;
    protected $reportModel;

    public function __construct()
    {
        helper(['form', 'url']);
        $this->userModel = new UserModel();
        $this->orderModel = new OrderModel();
        $this->reportModel = new ReportModel();
    }

    public function index()
    {
        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'Report::index: user_id not found in session');
            return redirect()->to('/auth/login')->with('error', 'Sesi habis. Silakan login ulang.');
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            log_message('error', 'Report::index: Invalid user or not a seller, user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Akun tidak valid atau bukan penjual.');
        }

        $isVerified = $user['verification_status'] === 'verified';
        session()->set([
            'is_enabled' => $isVerified,
            'verification_status' => $user['verification_status'] ?? 'non_verified'
        ]);

        try {
            $reports = $this->orderModel
                ->select('orders.order_id, orders.total_price, orders.status, orders.created_at, users.username as buyer_name')
                ->join('users', 'users.user_id = orders.buyer_id')
                ->where('orders.seller_id', (int)$userId)
                ->where('orders.status', 'completed')
                ->orderBy('orders.created_at', 'DESC')
                ->findAll(10);
        } catch (\Exception $e) {
            log_message('error', 'Report::index: Failed to fetch reports, user_id: ' . $userId . ', error: ' . $e->getMessage());
            return redirect()->to('/seller/dashboard')->with('error', 'Gagal memuat laporan. Silakan coba lagi.');
        }

        if (empty($reports)) {
            log_message('info', 'Report::index: No completed orders found for user_id: ' . $userId);
        }

        foreach ($reports as &$report) {
            $report['items'] = $this->orderModel->getOrderDetails((int)$report['order_id']) ?: [];
        }

        $chartData = $this->getChartData('yearly');
        $newOrders = $this->orderModel->where(['seller_id' => (int)$userId, 'status' => 'pending'])->countAllResults();

        $data = [
            'title' => 'Laporan Penjualan - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => esc(session()->get('username')),
            'role' => session()->get('role'),
            'isEnabled' => $isVerified,
            'verificationStatus' => $user['verification_status'] ?? 'non_verified',
            'needsVerification' => !$isVerified,
            'reports' => $reports,
            'chartData' => $chartData,
            'newOrders' => $newOrders,
            'currentTime' => date('d M Y H:i')
        ];

        log_message('debug', 'Report::index: Data prepared for user_id: ' . $userId . ', chartData: ' . json_encode($chartData));
        return view('seller/reports', $data);
    }

    public function getData()
    {
        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'Report::getData: user_id not found in session');
            return $this->respond(['status' => 'error', 'message' => 'Sesi habis. Silakan login ulang.'], 401);
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            log_message('error', 'Report::getData: Invalid user or not a seller, user_id: ' . $userId);
            return $this->respond(['status' => 'error', 'message' => 'Akun tidak valid atau bukan penjual.'], 401);
        }

        if ($user['verification_status'] !== 'verified') {
            log_message('error', 'Report::getData: Account not verified, user_id: ' . $userId);
            return $this->respond(['status' => 'error', 'message' => 'Akun Anda belum diverifikasi.'], 403);
        }

        $period = $this->request->getGet('period') ?? 'yearly';
        if (!in_array($period, ['weekly', 'monthly', 'yearly'])) {
            log_message('error', 'Report::getData: Invalid period: ' . $period . ', user_id: ' . $userId);
            return $this->respond(['status' => 'error', 'message' => 'Periode tidak valid.'], 400);
        }

        try {
            $chartData = $this->getChartData($period);
            if (empty($chartData['data']) || array_sum($chartData['data']) == 0) {
                log_message('info', 'Report::getData: No sales data for period ' . $period . ', user_id: ' . $userId);
            }
            return $this->respond(['status' => 'success', 'labels' => $chartData['labels'], 'data' => $chartData['data']]);
        } catch (\Exception $e) {
            log_message('error', 'Report::getData: Failed to fetch chart data for period ' . $period . ', user_id: ' . $userId . ', error: ' . $e->getMessage());
            return $this->respond(['status' => 'error', 'message' => 'Gagal memuat data grafik: ' . $e->getMessage()], 500);
        }
    }

    protected function getChartData($period)
    {
        $userId = session()->get('user_id');
        $query = $this->orderModel
            ->where('seller_id', (int)$userId)
            ->where('status', 'completed');

        $labels = [];
        $data = [];

        switch ($period) {
            case 'weekly':
                $query->select("DATE_FORMAT(created_at, '%a') as label, SUM(total_price) as total")
                    ->where('created_at >=', date('Y-m-d', strtotime('-7 days')))
                    ->groupBy('label')
                    ->orderBy('created_at', 'ASC');
                $days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                $labels = $days;
                $data = array_fill(0, 7, 0);
                break;
            case 'monthly':
                $query->select("DATE_FORMAT(created_at, '%b %Y') as label, SUM(total_price) as total")
                    ->where('created_at >=', date('Y-m-d', strtotime('-1 year')))
                    ->groupBy('label')
                    ->orderBy('created_at', 'ASC');
                $labels = [];
                for ($i = 11; $i >= 0; $i--) {
                    $labels[] = date('M Y', strtotime("-$i months"));
                }
                $data = array_fill(0, 12, 0);
                break;
            case 'yearly':
            default:
                $query->select("YEAR(created_at) as label, SUM(total_price) as total")
                    ->where('created_at >=', date('Y-m-d', strtotime('-5 years')))
                    ->groupBy('label')
                    ->orderBy('label', 'ASC');
                $currentYear = (int)date('Y');
                $labels = array_map('strval', range($currentYear - 4, $currentYear));
                $data = array_fill(0, 5, 0);
                break;
        }

        try {
            $results = $query->findAll();
            foreach ($results as $row) {
                $index = array_search($row['label'], $labels);
                if ($index !== false) {
                    $data[$index] = (float)$row['total'];
                }
            }
        } catch (\Exception $e) {
            log_message('error', 'Report::getChartData: Query failed for period ' . $period . ', user_id: ' . $userId . ', error: ' . $e->getMessage());
            throw $e;
        }

        if (empty($results)) {
            log_message('info', 'Report::getChartData: No data found for period ' . $period . ', returning default dataset');
        }

        return ['labels' => $labels, 'data' => $data];
    }

    public function export()
    {
        $userId = session()->get('user_id');
        if (!$userId) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login dulu.');
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            return redirect()->to('/auth/login')->with('error', 'Hanya penjual yang bisa mengakses.');
        }

        if ($user['verification_status'] !== 'verified') {
            return redirect()->to('/seller/dashboard')->with('error', 'Akun belum diverifikasi.');
        }

        $startDate = $this->request->getGet('start_date') ?? date('Y-m-d', strtotime('-30 days'));
        $endDate = $this->request->getGet('end_date') ?? date('Y-m-d');

        if (!strtotime($startDate) || !strtotime($endDate)) {
            return redirect()->to('/seller/reports')->with('error', 'Tanggal tidak valid.');
        }

        if (strtotime($startDate) > strtotime($endDate)) {
            return redirect()->to('/seller/reports')->with('error', 'Tanggal mulai harus sebelum tanggal akhir.');
        }

        try {
            $reports = $this->orderModel
                ->select('orders.order_id, orders.total_price, orders.status, orders.created_at, users.username as buyer_name')
                ->join('users', 'users.user_id = orders.buyer_id')
                ->where('orders.seller_id', (int)$userId)
                ->where('orders.status', 'completed')
                ->where('orders.created_at >=', $startDate)
                ->where('orders.created_at <=', $endDate . ' 23:59:59')
                ->orderBy('orders.created_at', 'DESC')
                ->findAll();
        } catch (\Exception $e) {
            log_message('error', 'Report::export: Failed to fetch reports, user_id: ' . $userId . ', error: ' . $e->getMessage());
            return redirect()->to('/seller/reports')->with('error', 'Gagal mengambil data laporan.');
        }

        foreach ($reports as &$report) {
            $report['items'] = $this->orderModel->getOrderDetails((int)$report['order_id']) ?: [];
        }

        try {
            $insertData = [
                'report_type' => 'sales_export',
                'generated_by' => (int)$userId,
                'start_date' => $startDate,
                'end_date' => $endDate,
                'data' => json_encode(['total_reports' => count($reports)]),
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->reportModel->insert($insertData);
        } catch (\Exception $e) {
            log_message('error', 'Report::export: Failed to save report metadata, user_id: ' . $userId . ', error: ' . $e->getMessage());
            session()->setFlashdata('warning', 'Laporan berhasil dibuat, tetapi metadata tidak tersimpan: ' . $e->getMessage());
        }

        $data = [
            'title' => 'Laporan Penjualan - DigiDaw',
            'username' => esc(session()->get('username')),
            'reports' => $reports,
            'startDate' => $startDate,
            'endDate' => $endDate,
            'currentTime' => date('d M Y H:i')
        ];

        return view('seller/reports_print', $data);
    }
}
