<?php
namespace App\Controllers;

use App\Models\PromoModel;
use App\Models\NotificationModel;
use App\Models\CartModel; // Added CartModel

class Promo extends BaseController
{
    protected $promoModel;
    protected $notificationModel;
    protected $cartModel; // Added property

    public function __construct()
    {
        helper(['form', 'url']);
        $this->promoModel = new PromoModel();
        $this->notificationModel = new NotificationModel();
        $this->cartModel = new CartModel(); // Initialized
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        $promos = $this->promoModel
            ->where('status', 'active')
            ->where('valid_from <=', date('Y-m-d H:i:s'))
            ->where('valid_until >=', date('Y-m-d H:i:s'))
            ->findAll();

        $data = [
            'title' => 'Promo - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'promos' => $promos,
            'stats' => [
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
                'cart_count' => $this->cartModel->where('user_id', $userId)->countAllResults(), // Added cart count
            ],
        ];

        return view('promos/index', $data);
    }
}