<?php

namespace App\Controllers;

use App\Models\CartModel;
use App\Models\ProductModel;
use App\Models\OrderModel;
use App\Models\TransactionModel;
use App\Models\UserModel;
use App\Models\PromoModel;
use App\Models\NotificationModel;
use CodeIgniter\Exceptions\PageNotFoundException;

class Cart extends BaseController
{
    protected $cartModel;
    protected $productModel;
    protected $orderModel;
    protected $transactionModel;
    protected $userModel;
    protected $promoModel;
    protected $notificationModel;

    public function __construct()
    {
        // Load helpers
        helper(['form', 'url']);

        // Initialize models
        $this->cartModel = new CartModel();
        $this->productModel = new ProductModel();
        $this->orderModel = new OrderModel();
        $this->transactionModel = new TransactionModel();
        $this->userModel = new UserModel();
        $this->promoModel = new PromoModel();
        $this->notificationModel = new NotificationModel();
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        $cartItems = $this->cartModel
            ->select('carts.cart_id, carts.quantity, products.product_id, products.name, products.price, products.image_url, categories.name as category_name')
            ->join('products', 'carts.product_id = products.product_id')
            ->join('categories', 'products.category_id = categories.category_id')
            ->where('carts.user_id', $userId)
            ->findAll();

        $totalAmount = 0;
        foreach ($cartItems as $item) {
            $totalAmount += $item['price'] * $item['quantity'];
        }

        $data = [
            'title' => 'Keranjang Belanja - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'cartItems' => $cartItems,
            'totalAmount' => $totalAmount,
            'stats' => [
                'cart_count' => count($cartItems),
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
            ],
        ];

        return view('cart/index', $data);
    }

    public function add()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Permintaan tidak valid']);
        }

        $session = session();
        if (!$session->get('logged_in')) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Silakan login untuk menambahkan produk ke keranjang.',
                'redirect' => '/auth/login',
            ]);
        }

        $userId = $session->get('user_id');
        if (!$userId || $userId <= 0) {
            $session->remove(['user_id', 'username', 'email', 'logged_in']);
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Sesi login tidak valid. Silakan login kembali.',
                'redirect' => '/auth/login',
            ]);
        }

        $productId = $this->request->getPost('product_id');
        $quantity = (int) $this->request->getPost('quantity') ?: 1;

        if (!$productId || $quantity < 1) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'ID produk atau kuantitas tidak valid']);
        }

        $product = $this->productModel->find($productId);
        if (!$product || $product['stock'] < $quantity) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Stok tidak cukup']);
        }

        try {
            $cartItem = $this->cartModel->where('product_id', $productId)->where('user_id', $userId)->first();
            if ($cartItem) {
                $newQuantity = $cartItem['quantity'] + $quantity;
                if ($newQuantity > $product['stock']) {
                    return $this->response->setJSON(['status' => 'error', 'message' => 'Stok tidak cukup']);
                }
                $this->cartModel->update($cartItem['cart_id'], ['quantity' => $newQuantity]);
            } else {
                $this->cartModel->insert([
                    'user_id' => $userId,
                    'product_id' => $productId,
                    'quantity' => $quantity,
                ]);
            }

            $cartItems = $this->cartModel->getCart($userId);
            $cartData = array_column($cartItems, 'quantity', 'product_id');
            $cartCount = array_sum(array_column($cartItems, 'quantity'));

            return $this->response->setJSON([
                'status' => 'success',
                'quantity' => $cartData[$productId] ?? $quantity,
                'cart' => $cartData,
                'items' => $cartItems,
                'cartCount' => $cartCount,
                'csrf_token' => csrf_hash(),
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Error in cart add: ' . $e->getMessage());
            return $this->response->setJSON(['status' => 'error', 'message' => 'Terjadi kesalahan server.']);
        }
    }

    public function get()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Permintaan tidak valid']);
        }

        $userId = session()->get('user_id') ?? 0;
        if (!$userId) {
            return $this->response->setJSON(['status' => 'success', 'cart' => [], 'items' => [], 'csrf_token' => csrf_hash()]);
        }

        try {
            $cartItems = $this->cartModel->getCart($userId);
            $cartData = array_column($cartItems, 'quantity', 'product_id');
            return $this->response->setJSON([
                'status' => 'success',
                'cart' => $cartData,
                'items' => $cartItems,
                'csrf_token' => csrf_hash(),
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Error fetching cart: ' . $e->getMessage());
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal mengambil data keranjang: ' . $e->getMessage()]);
        }
    }

    public function updateQuantity()
    {
        if (!$this->request->isAJAX()) {
            throw new PageNotFoundException('Invalid request');
        }

        if (!session()->get('logged_in')) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Silakan login untuk mengubah kuantitas produk.',
                'redirect' => '/auth/login',
            ]);
        }

        $userId = session()->get('user_id');
        if (!$userId || $userId <= 0) {
            session()->remove(['user_id', 'username', 'email', 'logged_in']);
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Sesi login tidak valid. Silakan login kembali.',
                'redirect' => '/auth/login',
            ]);
        }

        $user = $this->userModel->find($userId);
        if (!$user) {
            session()->remove(['user_id', 'username', 'email', 'logged_in']);
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Pengguna tidak ditemukan. Silakan login kembali.',
                'redirect' => '/auth/login',
            ]);
        }

        $productId = $this->request->getPost('product_id');
        $action = $this->request->getPost('action');

        $productId = filter_var($productId, FILTER_VALIDATE_INT);
        if ($productId === false || !in_array($action, ['increase', 'decrease'])) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Data tidak valid']);
        }

        $cartItem = $this->cartModel->where('product_id', $productId)
            ->where('user_id', $userId)
            ->first();

        if (!$cartItem) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Produk tidak ada di keranjang']);
        }

        $product = $this->productModel->find($productId);
        $newQuantity = $cartItem['quantity'];

        if ($action === 'increase') {
            $newQuantity++;
            if ($newQuantity > $product['stock']) {
                return $this->response->setJSON(['status' => 'error', 'message' => 'Stok tidak cukup']);
            }
        } elseif ($action === 'decrease') {
            $newQuantity--;
            if ($newQuantity <= 0) {
                $this->cartModel->delete($cartItem['cart_id']);
                $cartItems = $this->cartModel->getCart($userId);
                $cartData = array_column($cartItems, 'quantity', 'product_id');
                return $this->response->setJSON([
                    'status' => 'success',
                    'quantity' => 0,
                    'cart' => $cartData,
                    'items' => $cartItems,
                    'csrf_token' => csrf_hash(),
                ]);
            }
        }

        $this->cartModel->update($cartItem['cart_id'], ['quantity' => $newQuantity]);
        $cartItems = $this->cartModel->getCart($userId);
        $cartData = array_column($cartItems, 'quantity', 'product_id');

        return $this->response->setJSON([
            'status' => 'success',
            'quantity' => $newQuantity,
            'cart' => $cartData,
            'items' => $cartItems,
            'csrf_token' => csrf_hash(),
        ]);
    }

    public function remove($productId = null)
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Permintaan tidak valid']);
        }

        if (!session()->get('logged_in')) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Silakan login terlebih dahulu', 'redirect' => '/auth/login']);
        }

        $userId = session()->get('user_id');
        if (!$userId || $userId <= 0) {
            session()->remove(['user_id', 'username', 'email', 'logged_in']);
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Sesi login tidak valid. Silakan login kembali.',
                'redirect' => '/auth/login',
            ]);
        }

        // Ambil product_id dari POST atau URL
        $productId = $productId ?? $this->request->getPost('product_id');
        if (!$productId || !filter_var($productId, FILTER_VALIDATE_INT)) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Produk tidak ditemukan']);
        }

        $deleted = $this->cartModel->where(['user_id' => $userId, 'product_id' => $productId])->delete();
        if (!$deleted) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Gagal menghapus produk dari keranjang']);
        }

        $cartItems = $this->cartModel->getCart($userId);
        $cartData = array_column($cartItems, 'quantity', 'product_id');

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Produk dihapus dari keranjang',
            'cart' => $cartData,
            'items' => $cartItems,
            'csrf_token' => csrf_hash(),
        ]);
    }

    public function clearCart()
    {
        if (!$this->request->isAJAX()) {
            throw new PageNotFoundException('Invalid request');
        }

        if (!session()->get('logged_in')) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Silakan login terlebih dahulu', 'redirect' => '/auth/login']);
        }

        $userId = session()->get('user_id');
        $this->cartModel->where('user_id', $userId)->delete();

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Keranjang berhasil dihapus.',
            'csrf_token' => csrf_hash(),
        ]);
    }

    public function checkout()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login untuk melanjutkan checkout.');
        }

        $userId = session()->get('user_id');
        $cartItems = $this->cartModel
            ->select('carts.cart_id, carts.quantity, products.product_id, products.name, products.price, products.image_url, categories.name as category_name')
            ->join('products', 'carts.product_id = products.product_id')
            ->join('categories', 'products.category_id = categories.category_id')
            ->where('carts.user_id', $userId)
            ->findAll();

        if (empty($cartItems)) {
            return redirect()->to('/cart')->with('error', 'Keranjang Anda kosong.');
        }

        $totalAmount = 0;
        foreach ($cartItems as $item) {
            $totalAmount += $item['price'] * $item['quantity'];
        }

        $user = $this->userModel->select('username, email, balance')->find($userId);

        $data = [
            'title' => 'Checkout - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'cartItems' => $cartItems,
            'totalAmount' => $totalAmount,
            'user' => $user,
            'stats' => [
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
            ],
        ];

        return view('checkout', $data);
    }

    public function complete()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login untuk melanjutkan checkout.');
        }

        $userId = session()->get('user_id');
        $cartItems = $this->cartModel
            ->select('carts.cart_id, carts.quantity, products.product_id, products.name, products.price, categories.name as category_name')
            ->join('products', 'carts.product_id = products.product_id')
            ->join('categories', 'products.category_id = categories.category_id')
            ->where('carts.user_id', $userId)
            ->findAll();

        if (empty($cartItems)) {
            return redirect()->to('/cart')->with('error', 'Keranjang Anda kosong.');
        }

        // Validate stock
        foreach ($cartItems as $item) {
            $product = $this->productModel->find($item['product_id']);
            if ($product['stock'] < $item['quantity']) {
                return redirect()->to('/cart/checkout')->with('error', 'Stok produk ' . esc($item['name']) . ' tidak cukup.');
            }
        }

        // Validate input
        $phoneNumber = $this->request->getPost('phone_number');
        $gameIds = $this->request->getPost('game_id') ?? [];
        $promoCode = $this->request->getPost('promo_code');
        $paymentMethod = $this->request->getPost('payment_method');

        $hasPulsa = false;
        $hasGame = false;
        $games = [];
        foreach ($cartItems as $item) {
            if (in_array($item['category_name'], ['Pulsa', 'Paket Data'])) {
                $hasPulsa = true;
            }
            if ($item['category_name'] === 'Voucher Game') {
                $hasGame = true;
                preg_match('/Voucher (.*?)( \d+)/', $item['name'], $matches);
                $gameName = $matches[1] ?? str_replace('Voucher ', '', $item['name']);
                $games[$gameName] = $gameName;
            }
        }

        if ($hasPulsa && (!$phoneNumber || !preg_match('/^08[0-9]{8,11}$/', $phoneNumber))) {
            return redirect()->to('/cart/checkout')->with('error', 'Nomor telepon tidak valid (harus diawali 08 dan 10-13 digit).');
        }

        if ($hasGame) {
            foreach ($games as $gameName) {
                if (empty($gameIds[$gameName])) {
                    return redirect()->to('/cart/checkout')->with('error', "ID game untuk {$gameName} harus diisi.");
                }
            }
        }

        if (!$paymentMethod || !in_array($paymentMethod, ['bank_transfer', 'ewallet', 'credit_card'])) {
            return redirect()->to('/cart/checkout')->with('error', 'Metode pembayaran tidak valid.');
        }

        // Calculate total and check promo
        $totalAmount = 0;
        foreach ($cartItems as $item) {
            $totalAmount += $item['price'] * $item['quantity'];
        }

        $promoId = null;
        $discountApplied = 0;
        if ($promoCode) {
            $promo = $this->promoModel
                ->where('code', $promoCode)
                ->where('status', 'active')
                ->where('valid_from <=', date('Y-m-d H:i:s'))
                ->where('valid_until >=', date('Y-m-d H:i:s'))
                ->first();

            if ($promo) {
                $db = \Config\Database::connect();
                $usageCount = $db->table('promo_usages')
                    ->where('promo_id', $promo['promo_id'])
                    ->where('user_id', $userId)
                    ->countAllResults();
                if ($usageCount >= $promo['usage_limit_per_user']) {
                    return redirect()->to('/cart/checkout')->with('error', 'Promo sudah mencapai batas penggunaan.');
                }

                if ($promo['min_purchase'] && $totalAmount < $promo['min_purchase']) {
                    return redirect()->to('/cart/checkout')->with('error', 'Belanja minimum Rp ' . number_format($promo['min_purchase'], 0, ',', '.') . ' untuk menggunakan promo.');
                }

                if ($promo['discount_type'] === 'percentage') {
                    $discount = ($promo['discount_value'] / 100) * $totalAmount;
                    if ($promo['max_discount'] && $discount > $promo['max_discount']) {
                        $discount = $promo['max_discount'];
                    }
                } else {
                    $discount = $promo['discount_value'];
                }

                $discountApplied = $discount;
                $totalAmount -= $discount;
                $promoId = $promo['promo_id'];
            } else {
                return redirect()->to('/cart/checkout')->with('error', 'Kode promo tidak valid atau kadaluarsa.');
            }
        }

        // Check balance for ewallet
        if ($paymentMethod === 'ewallet') {
            $user = $this->userModel->find($userId);
            if ($user['balance'] < $totalAmount) {
                return redirect()->to('/cart/checkout')->with('error', 'Saldo tidak cukup. Saldo Anda: Rp ' . number_format($user['balance'], 0, ',', '.'));
            }
        }

        // Start transaction
        $db = \Config\Database::connect();
        $db->transBegin();

        try {
            // Create order
            $orderData = [
                'buyer_id' => $userId,
                'promo_id' => $promoId,
                'total_price' => $totalAmount,
                'status' => 'pending',
                'payment_method' => $paymentMethod,
                'payment_status' => 'pending',
                'seller_id' => $this->productModel->find($cartItems[0]['product_id'])['seller_id'], // Ambil seller_id dari produk pertama
                'created_at' => date('Y-m-d H:i:s'),
            ];
            $this->orderModel->insert($orderData);
            $orderId = $this->orderModel->insertID();

            // Save order details
            foreach ($cartItems as $item) {
                $gameName = null;
                if ($item['category_name'] === 'Voucher Game') {
                    preg_match('/Voucher (.*?)( \d+)/', $item['name'], $matches);
                    $gameName = $matches[1] ?? str_replace('Voucher ', '', $item['name']);
                }

                $db->table('order_details')->insert([
                    'order_id' => $orderId,
                    'product_id' => $item['product_id'],
                    'quantity' => $item['quantity'],
                    'price' => $item['price'],
                    'phone_number' => in_array($item['category_name'], ['Pulsa', 'Paket Data']) ? $phoneNumber : null,
                    'game_id' => ($item['category_name'] === 'Voucher Game' && !empty($gameIds[$gameName])) ? $gameIds[$gameName] : null,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);

                // Update stock
                $product = $this->productModel->find($item['product_id']);
                $this->productModel->update($item['product_id'], [
                    'stock' => $product['stock'] - $item['quantity'],
                    'sold_count' => ($product['sold_count'] ?? 0) + $item['quantity'],
                ]);
            }

            // Save promo usage
            if ($promoId && $discountApplied > 0) {
                $db->table('promo_usages')->insert([
                    'promo_id' => $promoId,
                    'order_id' => $orderId,
                    'user_id' => $userId,
                    'discount_applied' => $discountApplied,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
            }

            // Create transaction
            $transactionData = [
                'order_id' => $orderId,
                'amount' => $totalAmount,
                'status' => 'pending',
                'created_at' => date('Y-m-d H:i:s'),
            ];
            $this->transactionModel->insert($transactionData);
            $transactionId = $this->transactionModel->insertID();

            // Deduct balance and save wallet for ewallet
            if ($paymentMethod === 'ewallet') {
                $this->userModel->update($userId, ['balance' => $this->userModel->find($userId)['balance'] - $totalAmount]);
                $db->table('wallets')->insert([
                    'user_id' => $userId,
                    'amount' => -$totalAmount,
                    'type' => 'payment',
                    'description' => 'Pembayaran pesanan #' . $orderId,
                    'created_at' => date('Y-m-d H:i:s'),
                ]);
                $this->orderModel->update($orderId, ['payment_status' => 'confirmed']);
                $this->transactionModel->update($transactionId, ['status' => 'released']);
            }

            // Add notification
            $this->notificationModel->insert([
                'user_id' => $userId,
                'type' => 'order',
                'message' => 'Pesanan #' . $orderId . ' telah dibuat. Silakan lakukan pembayaran jika diperlukan.',
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            // Clear cart
            $this->cartModel->where('user_id', $userId)->delete();

            // Commit transaction
            $db->transCommit();

            return redirect()->to('/orders')->with('success', 'Pesanan berhasil dibuat! ' . ($paymentMethod === 'ewallet' ? 'Pembayaran telah diproses.' : 'Silakan lakukan pembayaran.'));
        } catch (\Exception $e) {
            $db->transRollback();
            log_message('error', 'Error in checkout: ' . $e->getMessage());
            return redirect()->to('/cart/checkout')->with('error', 'Terjadi kesalahan saat memproses pesanan: ' . $e->getMessage());
        }
    }
}
