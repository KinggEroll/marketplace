<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\ProductModel;
use App\Models\CategoryModel;
use App\Models\PromoModel;
use App\Models\CartModel;

class Home extends BaseController
{
    protected $userModel;
    protected $productModel;
    protected $categoryModel;
    protected $promoModel;
    protected $cartModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
        $this->promoModel = new PromoModel();
        $this->cartModel = new CartModel();
    }

    public function index()
    {
        $products = $this->productModel->select('products.*, categories.name as category_name')
            ->join('categories', 'categories.category_id = products.category_id')
            ->where('products.status', 'active')
            ->findAll();

        $categories = $this->categoryModel->findAll();
        $promos = $this->promoModel->where('status', 'active')
            ->where('valid_until >=', date('Y-m-d H:i:s'))
            ->where('valid_from <=', date('Y-m-d H:i:s'))
            ->findAll();

        $isLoggedIn = session()->get('logged_in') ?? false;
        if (!$isLoggedIn) {
            log_message('debug', 'No active session found in Home::index');
        } else {
            log_message('debug', 'Active session found: ' . json_encode(session()->get()));
        }
        $username = $isLoggedIn ? session()->get('username') : null;
        $role = $isLoggedIn ? session()->get('role') : '';
        $userId = $isLoggedIn ? session()->get('user_id') : 0;

        $cartItems = [];
        $cartData = [];
        $cartCount = 0;
        if ($isLoggedIn && $userId > 0) {
            try {
                $cartItems = $this->cartModel->getCart($userId);
                $cartData = array_column($cartItems, 'quantity', 'product_id');
                $cartCount = array_sum(array_column($cartItems, 'quantity'));
                log_message('debug', 'Cart items for user_id ' . $userId . ': ' . json_encode($cartItems));
            } catch (\Exception $e) {
                log_message('error', 'Failed to fetch cart in Home::index: ' . $e->getMessage());
                session()->setFlashdata('error', 'Gagal mengambil data keranjang: ' . $e->getMessage());
            }
        }

        return view('landing_page', [
            'title' => 'Selamat Datang di DigiDaw',
            'products' => $products,
            'categories' => $categories,
            'promos' => $promos,
            'isLoggedIn' => $isLoggedIn,
            'username' => $username,
            'role' => $role,
            'cart' => $cartData,
            'cartItems' => $cartItems,
            'cartCount' => $cartCount
        ]);
    }
}
