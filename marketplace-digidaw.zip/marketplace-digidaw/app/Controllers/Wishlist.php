<?php
namespace App\Controllers;

use App\Models\WishlistModel;
use App\Models\NotificationModel;
use App\Models\CartModel; // Added CartModel

class Wishlist extends BaseController
{
    protected $wishlistModel;
    protected $notificationModel;
    protected $cartModel; // Added property

    public function __construct()
    {
        helper(['form', 'url']);
        $this->wishlistModel = new WishlistModel();
        $this->notificationModel = new NotificationModel();
        $this->cartModel = new CartModel(); // Initialized
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        $wishlistItems = $this->wishlistModel
            ->select('wishlists.wishlist_id, products.product_id, products.name, products.price, products.image_url, categories.name as category_name')
            ->join('products', 'wishlists.product_id = products.product_id')
            ->join('categories', 'products.category_id = categories.category_id')
            ->where('wishlists.user_id', $userId)
            ->findAll();

        $data = [
            'title' => 'Wishlist - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'wishlistItems' => $wishlistItems,
            'stats' => [
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
                'cart_count' => $this->cartModel->where('user_id', $userId)->countAllResults(), // Added cart count
            ],
        ];

        return view('wishlist/index', $data);
    }
}