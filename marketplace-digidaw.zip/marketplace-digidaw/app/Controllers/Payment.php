<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Payment extends Controller
{
    protected $session;
    protected $walletModel;
    protected $paymentModel;

    public function __construct()
    {
        $this->session = session();
        $this->walletModel = model('WalletModel');
        $this->paymentModel = model('PaymentModel');
        helper(['form', 'url']);
    }

    public function deposit()
    {
        $userId = $this->session->get('user_id');
        if (!$userId) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $paymentMethods = [
            ['id' => 1, 'name' => 'Bank Transfer'],
            ['id' => 2, 'name' => 'e-Wallet'],
            ['id' => 3, 'name' => 'Credit Card']
        ];

        $paymentAccounts = [
            ['id' => 1, 'name' => 'Bank Mandiri (1234-5678-9012 a/n Admin)'],
            ['id' => 2, 'name' => 'Dana (0851-2345-6789 a/n Admin)'],
            ['id' => 3, 'name' => 'BCA (9876-5432-1098 a/n Admin)']
        ];

        $data = [
            'title' => 'Deposit Saldo',
            'payment_methods' => $paymentMethods,
            'payment_accounts' => $paymentAccounts,
            'stats' => ['wallet_balance' => $this->session->get('wallet_balance') ?? 0],
            'step' => 1,
        ];

        return view('dashboard/deposit', $data);
    }

    public function submitDeposit()
    {
        log_message('info', 'submitDeposit called with method: ' . $this->request->getMethod());
        log_message('info', 'Received data: ' . json_encode($this->request->getPost()));

        if ($this->request->getMethod() !== 'POST') {
            log_message('error', 'Method not allowed: ' . $this->request->getMethod());
            return $this->response->setStatusCode(405)->setJSON(['success' => false, 'message' => 'Metode harus POST']);
        }

        $rules = [
            'amount' => 'required|numeric|greater_than[10000]',
            'payment_method' => 'required|in_list[1,2,3]',
            'payment_account' => 'required|in_list[1,2,3]'
        ];

        if (!$this->validate($rules)) {
            log_message('error', 'Validation failed: ' . json_encode($this->validator->getErrors()));
            return $this->response->setJSON(['success' => false, 'message' => $this->validator->getErrors()]);
        }

        $userId = $this->session->get('user_id');
        if (!$userId) {
            log_message('error', 'User not logged in');
            return $this->response->setJSON(['success' => false, 'message' => 'User tidak login']);
        }

        $amount = $this->request->getPost('amount');
        $paymentMethod = $this->request->getPost('payment_method');
        $paymentAccount = $this->request->getPost('payment_account');

        // Simpan ke wallets sebagai catatan awal
        $walletData = [
            'user_id' => $userId,
            'amount' => $amount,
            'type' => 'deposit',
            'status' => 'pending',
            'description' => 'Deposit via ' . $this->mapPaymentMethod($paymentMethod) . ' (Akun: ' . $paymentAccount . ')',
            'created_at' => date('Y-m-d H:i:s')
        ];

        log_message('info', 'Insert data to wallets: ' . json_encode($walletData));

        // Simpan ke payment_proofs untuk proses verifikasi admin
        $paymentData = [
            'order_id' => null, // Bisa diisi jika ada order terkait, atau biarkan null
            'proof_url' => '', // Placeholder, bisa diisi dengan URL bukti pembayaran nanti
            'status' => 'pending',
            'notes' => json_encode(['user_id' => $userId, 'amount' => $amount]),
            'submitted_at' => date('Y-m-d H:i:s')
        ];

        try {
            $this->walletModel->insert($walletData);
            $paymentProofId = $this->paymentModel->insert($paymentData);

            $notificationModel = new \App\Models\NotificationModel();
            $notificationModel->insert([
                'user_id' => $userId,
                'type' => 'deposit',
                'message' => 'Permintaan deposit sebesar Rp' . number_format($amount, 0, ',', '.') . ' telah diajukan. Menunggu persetujuan admin.',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            log_message('info', 'Deposit request submitted successfully, payment_proof_id: ' . $paymentProofId);
            return $this->response->setJSON(['success' => true, 'message' => 'Permintaan deposit Anda telah diajukan. Menunggu persetujuan admin.', 'redirect' => '/dashboard']);
        } catch (\Exception $e) {
            log_message('error', 'Deposit error: ' . $e->getMessage());
            return $this->response->setJSON(['success' => false, 'message' => 'Terjadi kesalahan saat mengajukan deposit: ' . $e->getMessage()]);
        }
    }

    private function mapPaymentMethod($methodId)
    {
        $methods = [
            1 => 'bank_transfer',
            2 => 'ewallet',
            3 => 'credit_card'
        ];
        return $methods[$methodId] ?? 'bank_transfer';
    }
}