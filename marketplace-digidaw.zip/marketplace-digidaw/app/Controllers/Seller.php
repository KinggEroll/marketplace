<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\ProductModel;
use App\Models\OrderModel;

class Seller extends BaseController
{
    protected $userModel;
    protected $productModel;
    protected $orderModel;

    public function __construct()
    {
        helper(['form', 'url']);
        $this->userModel = new UserModel();
        $this->productModel = new ProductModel();
        $this->orderModel = new OrderModel();
    }

    public function dashboard($filter = 'all')
    {
        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'dashboard: user_id not found in session');
            return redirect()->to('/auth/login')->with('error', 'Sesi habis. Silakan login ulang.');
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            log_message('error', 'dashboard: Invalid user or not a seller, user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Akun tidak valid atau bukan penjual.');
        }

        $isVerified = $user['verification_status'] === 'verified';
        session()->set([
            'is_enabled' => $isVerified,
            'verification_status' => $user['verification_status'] ?? 'non_verified'
        ]);

        $productQuery = $this->productModel->where(['seller_id' => (int)$userId, 'status' => 'active']);
        if ($filter === 'low-stock') {
            $productQuery->where('stock <=', 5);
        } elseif ($filter === 'new') {
            $productQuery->where('created_at >=', date('Y-m-d H:i:s', strtotime('-7 days')));
        }
        $totalProducts = $productQuery->countAllResults();
        $recentProducts = $productQuery
            ->select('product_id, name, price, stock, created_at')
            ->orderBy('created_at', 'DESC')
            ->findAll(5);

        $newOrders = $this->orderModel->where(['seller_id' => (int)$userId, 'status' => 'pending'])->countAllResults();
        $revenue = $this->orderModel->where(['seller_id' => (int)$userId, 'status' => 'completed'])
            ->selectSum('total_price')
            ->first()['total_price'] ?? 0;
        $rating = $user['seller_rating'] ?? 0;

        $recentOrders = $this->orderModel
            ->select('orders.order_id, orders.total_price, orders.status, orders.created_at, users.username as buyer_name')
            ->join('users', 'users.user_id = orders.buyer_id')
            ->where('orders.seller_id', (int)$userId)
            ->orderBy('orders.created_at', 'DESC')
            ->findAll(5);

        foreach ($recentOrders as &$order) {
            $order['items'] = $this->orderModel->getOrderDetails((int)$order['order_id']) ?: [];
        }

        $data = [
            'title' => 'Dashboard Penjual - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => esc(session()->get('username')),
            'role' => session()->get('role'),
            'isEnabled' => $isVerified,
            'verificationStatus' => $user['verification_status'] ?? 'non_verified',
            'needsVerification' => !$isVerified,
            'filter' => esc($filter),
            'totalProducts' => $totalProducts,
            'newOrders' => $newOrders,
            'revenue' => $revenue,
            'rating' => $rating,
            'recentProducts' => $recentProducts,
            'recentOrders' => $recentOrders,
            'currentTime' => date('d M Y H:i')
        ];
        return view('seller/dashboard', $data);
    }

    public function products($filter = 'all')
    {
        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'products: user_id not found in session');
            return redirect()->to('/auth/login')->with('error', 'Sesi habis. Silakan login ulang.');
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            log_message('error', 'products: Invalid user or not a seller, user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Akun tidak valid atau bukan penjual.');
        }

        $isVerified = $user['verification_status'] === 'verified';
        session()->set([
            'is_enabled' => $isVerified,
            'verification_status' => $user['verification_status'] ?? 'non_verified'
        ]);

        $productQuery = $this->productModel
            ->select('products.*, categories.name as category_name')
            ->join('categories', 'categories.category_id = products.category_id', 'left')
            ->where(['seller_id' => (int)$userId]);

        if ($filter === 'low-stock') {
            $productQuery->where('products.stock <=', 5);
        } elseif ($filter === 'new') {
            $productQuery->where('products.created_at >=', date('Y-m-d H:i:s', strtotime('-7 days')));
        }

        $perPage = 9;
        $products = $productQuery
            ->orderBy('products.created_at', 'DESC')
            ->paginate($perPage);
        $pager = $this->productModel->pager;

        $newOrders = $this->orderModel->where(['seller_id' => (int)$userId, 'status' => 'pending'])->countAllResults();

        $data = [
            'title' => 'Produk - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => esc($user['username']),
            'role' => session()->get('role'),
            'isEnabled' => $isVerified,
            'verificationStatus' => $user['verification_status'] ?? 'non_verified',
            'needsVerification' => !$isVerified,
            'filter' => esc($filter),
            'products' => $products,
            'newOrders' => $newOrders,
            'pager' => $pager
        ];
        return view('seller/products', $data);
    }

    public function verify()
    {
        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'verify: user_id not found in session');
            return redirect()->to('/auth/login')->with('error', 'Sesi habis. Silakan login ulang.');
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            log_message('error', 'verify: Invalid user or not a seller, user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Akun tidak valid atau bukan penjual.');
        }

        if ($user['verification_status'] === 'verified') {
            return redirect()->to('/seller/dashboard')->with('success', 'Akun Anda sudah diverifikasi.');
        }

        $isVerified = $user['verification_status'] === 'verified';

        $data = [
            'title' => 'Verifikasi Penjual - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => esc($user['username']),
            'role' => session()->get('role'),
            'isEnabled' => $isVerified,
            'verificationStatus' => $user['verification_status'] ?? 'non_verified',
            'needsVerification' => !$isVerified
        ];
        return view('seller/verify', $data);
    }

    public function doVerify()
    {
        try {
            // Log request receipt
            log_message('debug', 'Seller::doVerify: Request received');

            // Check if user is logged in
            $userId = session()->get('user_id');
            if (!$userId) {
                log_message('error', 'Seller::doVerify: No user_id in session');
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Silakan login terlebih dahulu.'
                ])->setStatusCode(401);
            }

            // Get the user
            $user = $this->userModel->find($userId);
            if (!$user || $user['role'] !== 'penjual') {
                log_message('error', 'Seller::doVerify: Invalid user or not a seller, user_id: ' . $userId);
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Akun tidak valid untuk verifikasi penjual.'
                ])->setStatusCode(403);
            }

            // Check if at least one photo is provided
            if (!$this->request->getFile('verification_photo') && !$this->request->getPost('selfie')) {
                log_message('error', 'Seller::doVerify: No photo provided, user_id: ' . $userId);
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Harap unggah foto verifikasi atau selfie.'
                ])->setStatusCode(400);
            }

            // Validate id_number
            $idNumber = $this->request->getPost('id_number');
            if (empty($idNumber)) {
                log_message('error', 'Seller::doVerify: No id_number provided, user_id: ' . $userId);
                return $this->response->setJSON([
                    'status' => 'error',
                    'message' => 'Nomor identitas diperlukan.'
                ])->setStatusCode(400);
            }

            // Validate the uploaded file (if provided)
            $file = $this->request->getFile('verification_photo');
            if ($file && $file->isValid()) {
                $validationRule = [
                    'verification_photo' => [
                        'label' => 'Verification Photo',
                        'rules' => 'uploaded[verification_photo]|is_image[verification_photo]|mime_in[verification_photo,image/jpeg,image/png,image/gif]|max_size[verification_photo,2048]'
                    ]
                ];

                if (!$this->validate($validationRule)) {
                    log_message('error', 'Seller::doVerify: File validation failed, user_id: ' . $userId . ', error: ' . json_encode($this->validator->getErrors()));
                    return $this->response->setJSON([
                        'status' => 'error',
                        'message' => $this->validator->getErrors()['verification_photo']
                    ])->setStatusCode(400);
                }
            }

            // Generate a unique filename
            $timestamp = time();
            $uploadPath = FCPATH . 'uploads/seller_photos/';
            $selfiePath = null;
            $documentPath = null;

            // Create the seller_photos directory if it doesn't exist
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0755, true);
                log_message('debug', 'Seller::doVerify: Created directory ' . $uploadPath);
            }

            // Handle selfie (base64-encoded)
            if ($selfie = $this->request->getPost('selfie')) {
                $selfieName = 'seller_' . $userId . '_' . $timestamp . '_selfie.jpg';
                $selfiePath = 'seller_photos/' . $selfieName;
                $imageData = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $selfie));
                if ($imageData === false) {
                    log_message('error', 'Seller::doVerify: Invalid selfie data, user_id: ' . $userId);
                    return $this->response->setJSON([
                        'status' => 'error',
                        'message' => 'Data selfie tidak valid.'
                    ])->setStatusCode(400);
                }
                file_put_contents($uploadPath . $selfieName, $imageData);
                log_message('debug', 'Seller::doVerify: Selfie saved to ' . $uploadPath . $selfieName);
            }

            // Handle verification photo (file upload)
            if ($file && $file->isValid() && !$file->hasMoved()) {
                $documentName = 'seller_' . $userId . '_' . $timestamp . '_document.' . $file->getExtension();
                $documentPath = 'seller_photos/' . $documentName;
                $file->move($uploadPath, $documentName);
                log_message('debug', 'Seller::doVerify: Document saved to ' . $uploadPath . $documentName);
            }

            // Update the user's data in the database
            $updateData = [
                'verification_photo' => $documentPath ?: ($selfiePath ?: null),
                'selfie_photo' => $selfiePath,
                'id_number' => $idNumber,
                'verification_status' => 'pending',
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if ($this->userModel->update($userId, $updateData)) {
                // Send notification to admin
                $notificationModel = new \App\Models\NotificationModel();
                $notificationData = [
                    'user_id' => $userId,
                    'admin_id' => null,
                    'type' => 'verification',
                    'message' => 'Pengguna ' . $user['username'] . ' telah mengunggah verifikasi penjual.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $notificationModel->insert($notificationData);
                log_message('debug', 'Seller::doVerify: User data updated and notification sent, user_id: ' . $userId);

                return $this->response->setJSON([
                    'status' => 'success',
                    'message' => 'Verifikasi berhasil diunggah. Menunggu persetujuan admin.'
                ]);
            }

            log_message('error', 'Seller::doVerify: Failed to update user verification data, user_id: ' . $userId);
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Gagal memperbarui data verifikasi.'
            ])->setStatusCode(500);
        } catch (\Exception $e) {
            log_message('error', 'Seller::doVerify: Failed to process verification, user_id: ' . $userId . ', error: ' . $e->getMessage());
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Gagal mengunggah verifikasi: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }
}
