<?php

namespace App\Controllers;

use App\Models\AdminModel;
use CodeIgniter\Controller;

class AdminAuth extends Controller
{
    protected $adminModel;

    public function __construct()
    {
        $this->adminModel = new AdminModel();
        helper('form'); // Memuat helper form untuk set_value()
    }

    public function login()
    {
        if (session()->get('admin_logged_in')) {
            log_message('debug', 'AdminAuth::login: Admin already logged in, redirecting to /admin/dashboard');
            return redirect()->to('/admin/dashboard')->with('success', 'You are already logged in.');
        }

        $data['title'] = 'Admin Login - DigiDaw';
        return view('admin/login', $data);
    }

    public function doLogin()
    {
        $validation = \Config\Services::validation();

        $rules = [
            'username' => 'required',
            'password' => 'required|min_length[6]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', $validation->getErrors());
        }

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Update to select 'password_hash' instead of 'password'
        $admin = $this->adminModel->where('username', $username)->first();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            session()->set([
                'admin_id' => $admin['admin_id'],
                'admin_username' => $admin['username'],
                'admin_logged_in' => true
            ]);
            return redirect()->to('/admin/dashboard')->with('success', 'Login admin berhasil!');
        }

        return redirect()->back()->withInput()->with('error', 'Username atau password salah.');
    }

    public function register()
    {
        $data['title'] = 'Admin Register - DigiDaw';
        return view('admin/register', $data);
    }

    public function doRegister()
    {
        $validation = \Config\Services::validation();

        $rules = [
            'username' => 'required|is_unique[admins.username]',
            'email' => 'required|valid_email|is_unique[admins.email]',
            'password' => 'required|min_length[6]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', $validation->getErrors());
        }

        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password_hash' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT), // Update to 'password_hash'
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($this->adminModel->insert($data)) {
            return redirect()->to('/admin/login')->with('success', 'Registrasi admin berhasil! Silakan login.');
        }

        return redirect()->back()->withInput()->with('error', 'Terjadi kesalahan saat mendaftar.');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/admin/login')->with('success', 'Logout admin berhasil!');
    }
}
