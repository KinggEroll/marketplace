<?php

namespace App\Controllers;

use App\Models\TransactionModel;
use App\Models\OrderModel;
use App\Models\NotificationModel;
use App\Models\CartModel; // Added CartModel

class Transaction extends BaseController
{
    protected $transactionModel;
    protected $orderModel;
    protected $notificationModel; // Deklarasi properti
    protected $cartModel; // Added property

    public function __construct()
    {
        helper(['form', 'url']);
        $this->transactionModel = new TransactionModel();
        $this->orderModel = new OrderModel();
        $this->notificationModel = new NotificationModel(); // Inisialisasi
        $this->cartModel = new CartModel(); // Initialized
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        $transactions = $this->transactionModel
            ->select('transactions.transaction_id, transactions.order_id, transactions.amount, transactions.status, transactions.created_at, orders.total_price')
            ->join('orders', 'transactions.order_id = orders.order_id')
            ->where('orders.buyer_id', $userId)
            ->orderBy('transactions.created_at', 'DESC')
            ->findAll();

        $data = [
            'title' => 'Riwayat Transaksi - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'transactions' => $transactions,
            'stats' => [
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
            ],
        ];

        return view('transactions/index', $data);
    }
}
