<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\OrderModel;
use App\Models\CartModel;
use App\Models\WishlistModel;
use App\Models\PromoModel;
use App\Models\WalletModel;
use App\Models\NotificationModel;
use App\Models\ProductModel;

class Dashboard extends BaseController
{
    protected $userModel;
    protected $orderModel;
    protected $cartModel;
    protected $wishlistModel;
    protected $promoModel;
    protected $walletModel;
    protected $notificationModel;
    protected $productModel;

    public function __construct()
    {
        helper(['form', 'url']);
        $this->userModel = new UserModel();
        $this->orderModel = new OrderModel();
        $this->cartModel = new CartModel();
        $this->wishlistModel = new WishlistModel();
        $this->promoModel = new PromoModel();
        $this->walletModel = new WalletModel();
        $this->notificationModel = new NotificationModel();
        $this->productModel = new ProductModel();
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'User ID not found in session.');
            return redirect()->to('/auth/login')->with('error', 'Sesi tidak valid.');
        }

        // Ambil data user
        $user = $this->userModel->asArray()->select('user_id, username, email, phone, address, balance, referral_code')->find($userId);
        if (!$user) {
            log_message('error', 'User not found for user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Pengguna tidak ditemukan.');
        }

        // Cek referral code
        $referralCode = isset($user['referral_code']) && !empty($user['referral_code']) ? $user['referral_code'] : null;

        // Data untuk grafik pengeluaran bulanan (6 bulan terakhir)
        $monthlyExpenses = [];
        $monthLabels = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = date('Y-m', strtotime("-$i months"));
            $monthName = date('M Y', strtotime("-$i months"));
            $expense = $this->walletModel
                ->select("SUM(CASE WHEN type = 'payment' THEN amount ELSE 0 END) as total")
                ->where('user_id', $userId)
                ->where('DATE_FORMAT(created_at, "%Y-%m")', $month)
                ->first();

            $monthlyExpenses[] = $expense['total'] ?? 0;
            $monthLabels[] = $monthName;
        }

        // Data untuk grafik kategori pembelian
        $categoryStats = $this->orderModel
            ->select('categories.name as category_name, COUNT(orders.order_id) as total_orders, SUM(orders.total_price) as total_spent')
            ->join('order_details', 'orders.order_id = order_details.order_id')
            ->join('products', 'order_details.product_id = products.product_id')
            ->join('categories', 'products.category_id = categories.category_id')
            ->where('orders.buyer_id', $userId)
            ->where('orders.status', 'completed')
            ->groupBy('categories.category_id')
            ->orderBy('total_spent', 'DESC')
            ->limit(5)
            ->findAll();

        // Produk trending berdasarkan view_count dan sold_count
        $trendingProducts = $this->productModel
            ->select('products.product_id, products.name, products.price, products.image_url, products.view_count, products.sold_count, categories.name as category_name')
            ->join('categories', 'products.category_id = categories.category_id')
            ->where('products.status', 'active')
            ->orderBy('(products.view_count + products.sold_count * 2)', 'DESC')
            ->limit(6)
            ->findAll();

        $data = [
            'title' => 'Dashboard Pembeli - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'user' => $user,
            'stats' => [
                'wallet_balance' => $user['balance'] ?? 0,
                'total_orders' => $this->orderModel->where('buyer_id', $userId)->countAllResults(),
                'pending_orders' => $this->orderModel->where('buyer_id', $userId)->where('status', 'pending')->countAllResults(),
                'completed_orders' => $this->orderModel->where('buyer_id', $userId)->where('status', 'completed')->countAllResults(),
                'wishlist_count' => $this->wishlistModel->where('user_id', $userId)->countAllResults(),
                'cart_count' => $this->cartModel->where('user_id', $userId)->countAllResults(),
                'active_promos' => $this->promoModel->where('status', 'active')
                    ->where('valid_until >=', date('Y-m-d H:i:s'))
                    ->countAllResults(),
                'referred_count' => $referralCode ? $this->userModel->where('referred_by', $referralCode)->countAllResults() : 0,
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
                'total_spent' => $this->orderModel->selectSum('total_price')->where('buyer_id', $userId)->where('status', 'completed')->first()['total_price'] ?? 0
            ],
            'recent_orders' => $this->orderModel
                ->select('orders.order_id, orders.total_price, orders.status, orders.created_at, order_details.product_id, products.name as product_name, products.image_url')
                ->join('order_details', 'orders.order_id = order_details.order_id')
                ->join('products', 'order_details.product_id = products.product_id')
                ->where('orders.buyer_id', $userId)
                ->orderBy('orders.created_at', 'DESC')
                ->limit(5)
                ->findAll(),
            'cart_items' => $this->cartModel
                ->select('carts.cart_id, carts.quantity, products.product_id, products.name, products.price, products.image_url')
                ->join('products', 'carts.product_id = products.product_id')
                ->where('carts.user_id', $userId)
                ->limit(4)
                ->findAll(),
            'wishlist_items' => $this->wishlistModel
                ->select('wishlists.wishlist_id, products.product_id, products.name, products.price, products.image_url')
                ->join('products', 'wishlists.product_id = products.product_id')
                ->where('wishlists.user_id', $userId)
                ->limit(4)
                ->findAll(),
            'active_promos' => $this->promoModel
                ->select('promo_id, code, description, discount_type, discount_value, min_purchase, max_discount, valid_until')
                ->where('status', 'active')
                ->where('valid_until >=', date('Y-m-d H:i:s'))
                ->limit(5)
                ->findAll(),
            'recent_transactions' => $this->walletModel
                ->select('wallet_id, amount, type, description, created_at')
                ->where('user_id', $userId)
                ->orderBy('created_at', 'DESC')
                ->limit(5)
                ->findAll(),
            'notifications' => $this->notificationModel
                ->select('notification_id, message, type, is_read, created_at')
                ->where('user_id', $userId)
                ->orderBy('created_at', 'DESC')
                ->limit(5)
                ->findAll(),
            'monthly_expenses' => $monthlyExpenses,
            'month_labels' => $monthLabels,
            'category_stats' => $categoryStats,
            'trending_products' => $trendingProducts
        ];

        return view('dashboard/index', $data);
    }

    // Nonaktifkan atau hapus fungsi deposit
    /* public function deposit()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        $user = $this->userModel->find($userId);

        if ($this->request->getMethod() === 'post') {
            $rules = [
                'amount' => 'required|numeric|greater_than[0]',
                'payment_method' => 'required|in_list[bank_transfer,ewallet,credit_card]',
                'proof' => 'uploaded[proof]|max_size[proof,2048]|ext_in[proof,jpg,jpeg,png]'
            ];

            if ($this->validate($rules)) {
                $amount = $this->request->getPost('amount');
                $paymentMethod = $this->request->getPost('payment_method');
                $proof = $this->request->getFile('proof');

                if ($proof && $proof->isValid() && !$proof->hasMoved()) {
                    $newName = $proof->getRandomName();
                    $proof->move(WRITEPATH . 'uploads', $newName);
                    $proofPath = 'uploads/' . $newName;
                } else {
                    $proofPath = null;
                }

                // Simpan ke tabel wallet sebagai transaksi deposit
                $this->walletModel->insert([
                    'user_id' => $userId,
                    'amount' => $amount,
                    'type' => 'deposit',
                    'status' => 'pending',
                    'description' => 'Deposit via ' . $paymentMethod . ($proofPath ? ' (Bukti: ' . $proofPath . ')' : ''),
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                // Tambahkan notifikasi
                $this->notificationModel->insert([
                    'user_id' => $userId,
                    'type' => 'deposit',
                    'message' => 'Permintaan deposit sebesar Rp' . number_format($amount, 0, ',', '.') . ' telah diajukan. Menunggu persetujuan admin.',
                    'created_at' => date('Y-m-d H:i:s')
                ]);

                session()->setFlashdata('success', 'Permintaan deposit berhasil diajukan. Menunggu persetujuan admin.');
                return redirect()->to('/dashboard');
            } else {
                session()->setFlashdata('error', 'Validasi gagal: ' . implode(', ', $this->validator->getErrors()));
            }
        }

        $data = [
            'title' => 'Deposit Saldo - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'user' => $user
        ];

        return view('dashboard/deposit', $data);
    } */
}