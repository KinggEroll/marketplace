<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\ReportModel;
use App\Models\AdminModel;
use App\Models\OrderModel;
use App\Models\PromoModel;
use App\Models\ComplaintModel;
use App\Models\NotificationModel;
use App\Models\WalletModel;
use App\Models\ProductModel;
use App\Models\CategoryModel;
use App\Models\PaymentModel;

class Admin extends BaseController
{
    protected $userModel;
    protected $reportModel;
    protected $adminModel;
    protected $orderModel;
    protected $promoModel;
    protected $complaintModel;
    protected $notificationModel;
    protected $walletModel;
    protected $productModel;
    protected $categoryModel;
    protected $paymentProofModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->reportModel = new ReportModel();
        $this->adminModel = new AdminModel();
        $this->orderModel = new OrderModel();
        $this->promoModel = new PromoModel();
        $this->complaintModel = new ComplaintModel();
        $this->notificationModel = new NotificationModel();
        $this->walletModel = new WalletModel();
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
        $this->paymentProofModel = new PaymentModel();
    }

    public function serveVerificationPhoto($filename)
    {
        try {
            $basePath = FCPATH . 'uploads/';
            $filePath = $basePath . $filename;

            if (strpos(realpath($filePath), realpath($basePath)) !== 0) {
                log_message('error', 'Admin::serveVerificationPhoto: Invalid file path detected: ' . $filePath);
                throw new \Exception('Invalid file path');
            }

            if (!file_exists($filePath)) {
                log_message('error', 'Admin::serveVerificationPhoto: File not found: ' . $filePath);
                throw new \Exception('File not found');
            }

            // Check both verification_photo and selfie_photo
            $seller = $this->userModel
                ->where('role', 'penjual')
                ->groupStart()
                ->where('verification_photo', $filename)
                ->orWhere('selfie_photo', $filename)
                ->groupEnd()
                ->first();

            if (!$seller) {
                log_message('error', 'Admin::serveVerificationPhoto: No matching seller found for file: ' . $filename);
                throw new \Exception('File not associated with any seller');
            }

            $mimeType = mime_content_type($filePath);
            if (!$mimeType || !in_array($mimeType, ['image/jpeg', 'image/png', 'image/gif'])) {
                log_message('error', 'Admin::serveVerificationPhoto: Invalid file type: ' . $mimeType);
                throw new \Exception('Invalid file type');
            }

            $this->response
                ->setHeader('Content-Type', $mimeType)
                ->setHeader('Content-Length', (string) filesize($filePath))
                ->setHeader('Cache-Control', 'public, max-age=3600');

            readfile($filePath);
            return $this->response;
        } catch (\Exception $e) {
            log_message('error', 'Admin::serveVerificationPhoto: Failed to serve file, filename: ' . $filename . ', error: ' . $e->getMessage());
            throw new \CodeIgniter\Exceptions\PageNotFoundException('File not found or access denied');
        }
    }

    public function dashboard()
    {
        try {
            // Comprehensive metrics for premium dashboard
            $report_count = $this->reportModel->countAllResults();
            $pending_sellers = $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults();
            $order_count = $this->orderModel->countAllResults();
            $promo_count = $this->promoModel->where('valid_until >=', date('Y-m-d'))->countAllResults();
            $user_count = $this->userModel->countAllResults();
            $active_users = $this->userModel->where('status', 'active')->countAllResults();
            $inactive_users = $this->userModel->where('status', 'inactive')->countAllResults();

            $total_revenue = $this->orderModel->where('status', 'completed')->selectSum('total_price')->get()->getRow()->total_price ?? 0;
            $monthly_revenue = $this->orderModel
                ->where('status', 'completed')
                ->where('MONTH(created_at)', date('m'))
                ->where('YEAR(created_at)', date('Y'))
                ->selectSum('total_price')
                ->get()->getRow()->total_price ?? 0;

            $open_complaints = $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults();
            $unread_notifications = $this->notificationModel->where('is_read', 0)->where('admin_id', session()->get('admin_id'))->countAllResults();
            $pending_deposits = $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults();

            $recent_reports = $this->reportModel
                ->select('reports.*, users.username as seller_name')
                ->join('users', 'users.user_id = reports.generated_by', 'left')
                ->orderBy('reports.created_at', 'DESC')
                ->findAll(10);

            $pending_sellers_list = $this->userModel
                ->select('users.*, COUNT(products.product_id) as product_count')
                ->where('role', 'penjual')
                ->where('is_enabled', 0)
                ->join('products', 'products.seller_id = users.user_id', 'left')
                ->groupBy('users.user_id')
                ->findAll();

            $recent_user_logs = $this->userModel->db->table('user_logs')
                ->select('user_logs.*, users.username, users.role')
                ->join('users', 'users.user_id = user_logs.user_id', 'left')
                ->orderBy('user_logs.created_at', 'DESC')
                ->limit(10)
                ->get()
                ->getResultArray();

            $order_statuses = [
                'pending' => $this->orderModel->where('status', 'pending')->countAllResults(),
                'paid' => $this->orderModel->where('status', 'paid')->countAllResults(),
                'delivered' => $this->orderModel->where('status', 'delivered')->countAllResults(),
                'completed' => $this->orderModel->where('status', 'completed')->countAllResults(),
                'cancelled' => $this->orderModel->where('status', 'cancelled')->countAllResults(),
            ];

            $recent_transactions = $this->orderModel->db->table('transactions')
                ->select('transactions.*, orders.order_id, orders.total_price, users.username as buyer_name, users.email as buyer_email')
                ->join('orders', 'orders.order_id = transactions.order_id', 'left')
                ->join('users', 'users.user_id = orders.buyer_id', 'left')
                ->orderBy('transactions.created_at', 'DESC')
                ->limit(10)
                ->get()
                ->getResultArray();

            $top_products = $this->productModel
                ->select('products.*, users.username as seller_name, categories.name as category_name')
                ->join('users', 'users.user_id = products.seller_id', 'left')
                ->join('categories', 'categories.category_id = products.category_id', 'left')
                ->orderBy('products.sold_count', 'DESC')
                ->findAll(10);

            $category_performance = $this->productModel
                ->select('categories.name, categories.category_id, COUNT(products.product_id) as product_count, SUM(products.sold_count) as total_sold, AVG(products.price) as avg_price')
                ->join('categories', 'categories.category_id = products.category_id', 'left')
                ->groupBy('categories.category_id')
                ->orderBy('total_sold', 'DESC')
                ->findAll();

            $recent_complaints = $this->complaintModel
                ->select('complaints.*, users.username as user_name, orders.order_id, orders.total_price')
                ->join('users', 'users.user_id = complaints.user_id', 'left')
                ->join('orders', 'orders.order_id = complaints.order_id', 'left')
                ->orderBy('complaints.created_at', 'DESC')
                ->findAll(10);

            $recent_payment_proofs = $this->paymentProofModel
                ->select('payment_proofs.*, orders.order_id, orders.total_price, users.username as buyer_name, admins.username as verified_by_name')
                ->join('orders', 'orders.order_id = payment_proofs.order_id', 'left')
                ->join('users', 'users.user_id = orders.buyer_id', 'left')
                ->join('admins', 'admins.admin_id = payment_proofs.verified_by', 'left')
                ->orderBy('payment_proofs.submitted_at', 'DESC')
                ->findAll(10);

            $sales_by_month = $this->orderModel
                ->select('MONTH(created_at) as month, YEAR(created_at) as year, COUNT(*) as total_orders, SUM(total_price) as total_revenue')
                ->where('status', 'completed')
                ->where('created_at >=', date('Y-01-01'))
                ->groupBy('YEAR(created_at), MONTH(created_at)')
                ->orderBy('year, month')
                ->findAll();

            $user_growth = $this->userModel
                ->select('DATE(created_at) as date, COUNT(*) as new_users')
                ->where('created_at >=', date('Y-m-d', strtotime('-30 days')))
                ->groupBy('DATE(created_at)')
                ->orderBy('date')
                ->findAll();

            $payment_methods = $this->orderModel
                ->select('payment_method, COUNT(*) as count')
                ->where('payment_method IS NOT NULL')
                ->groupBy('payment_method')
                ->findAll();

            $recent_seller_apps = $this->userModel
                ->select('users.*, DATE(created_at) as application_date')
                ->where('role', 'penjual')
                ->where('is_enabled', 0)
                ->orderBy('created_at', 'DESC')
                ->findAll(5);

            $data = [
                'title' => 'DigiDaw Premium Dashboard - Admin Excellence',
                'report_count' => $report_count,
                'pending_sellers' => $pending_sellers,
                'order_count' => $order_count,
                'promo_count' => $promo_count,
                'user_count' => $user_count,
                'active_users' => $active_users,
                'inactive_users' => $inactive_users,
                'total_revenue' => $total_revenue,
                'monthly_revenue' => $monthly_revenue,
                'open_complaints' => $open_complaints,
                'unread_notifications' => $unread_notifications,
                'pending_deposits' => $pending_deposits,
                'recent_reports' => $recent_reports,
                'pending_sellers_list' => $pending_sellers_list,
                'recent_user_logs' => $recent_user_logs,
                'order_statuses' => $order_statuses,
                'recent_transactions' => $recent_transactions,
                'top_products' => $top_products,
                'category_performance' => $category_performance,
                'recent_complaints' => $recent_complaints,
                'recent_payment_proofs' => $recent_payment_proofs,
                'sales_by_month' => $sales_by_month,
                'user_growth' => $user_growth,
                'payment_methods' => $payment_methods,
                'recent_seller_apps' => $recent_seller_apps,
                'latest_user' => $this->userModel->orderBy('created_at', 'DESC')->first()
            ];

            return view('admin/dashboard', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::dashboard: Failed to load dashboard data, error: ' . $e->getMessage());
            return redirect()->to('/admin/dashboard')->with('error', 'Gagal memuat dashboard: ' . $e->getMessage());
        }
    }

    public function notifications()
    {
        try {
            $adminId = session()->get('admin_id');
            log_message('debug', 'Admin::notifications: admin_id from session: ' . ($adminId ?? 'null'));

            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            // Mark notifications as read for the admin
            $this->notificationModel
                ->where('admin_id', $adminId)
                ->where('is_read', 0)
                ->set(['is_read' => 1])
                ->update();

            // Fetch notifications for the admin or system notifications (admin_id IS NULL)
            $notifications = $this->notificationModel
                ->select('notifications.*, users.username as user_name, admins.username as admin_name')
                ->join('users', 'users.user_id = notifications.user_id', 'left')
                ->join('admins', 'admins.admin_id = notifications.admin_id', 'left')
                ->groupStart()
                ->where('notifications.admin_id', $adminId)
                ->orWhere('notifications.admin_id IS NULL')
                ->groupEnd()
                ->orderBy('notifications.created_at', 'DESC')
                ->findAll();

            log_message('debug', 'Admin::notifications: Retrieved ' . count($notifications) . ' notifications');

            $data = [
                'title' => 'Manajemen Notifikasi - DigiDaw Admin',
                'notifications' => $notifications,
                'unread_notifications' => $this->notificationModel
                    ->groupStart()
                    ->where('admin_id', $adminId)
                    ->orWhere('admin_id IS NULL')
                    ->groupEnd()
                    ->where('is_read', 0)
                    ->countAllResults(),
                'pending_sellers' => $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults(),
                'pending_deposits' => $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults(),
                'open_complaints' => $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults(),
            ];

            return view('admin/notifications', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::notifications: Failed to load notifications, error: ' . $e->getMessage());
            return redirect()->to('/admin/notifications')->with('error', 'Gagal memuat notifikasi: ' . $e->getMessage());
        }
    }

    public function recentNotifications()
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return $this->response->setJSON([
                    'success' => false,
                    'error' => 'Admin tidak terautentikasi'
                ])->setStatusCode(401);
            }

            $notifications = $this->notificationModel
                ->select('notifications.*, users.username as user_name, admins.username as admin_name')
                ->join('users', 'users.user_id = notifications.user_id', 'left')
                ->join('admins', 'admins.admin_id = notifications.admin_id', 'left')
                ->groupStart()
                ->where('notifications.admin_id', $adminId)
                ->orWhere('notifications.admin_id IS NULL')
                ->groupEnd()
                ->orderBy('notifications.created_at', 'DESC')
                ->findAll(5);

            $formattedNotifications = array_map(function ($notification) {
                return [
                    'id' => $notification['notification_id'],
                    'title' => $notification['type'] === 'verification' ? 'Verifikasi Penjual' : ($notification['type'] ? ucfirst($notification['type']) : 'System'),
                    'message' => $notification['message'],
                    'is_read' => (bool)$notification['is_read'],
                    'created_at' => date('d M Y, H:i', strtotime($notification['created_at'])),
                    'user_name' => $notification['user_name'] ?? 'System',
                    'admin_name' => $notification['admin_name'] ?? null
                ];
            }, $notifications);

            return $this->response->setJSON([
                'success' => true,
                'notifications' => $formattedNotifications,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Admin::recentNotifications: Failed to fetch recent notifications, error: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'error' => 'Gagal memuat notifikasi: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    public function notificationsCount()
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return $this->response->setJSON([
                    'success' => false,
                    'error' => 'Admin tidak terautentikasi'
                ])->setStatusCode(401);
            }

            $unread_notifications = $this->notificationModel
                ->groupStart()
                ->where('admin_id', $adminId)
                ->orWhere('admin_id IS NULL')
                ->groupEnd()
                ->where('is_read', 0)
                ->countAllResults();
            $pending_sellers = $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults();
            $pending_deposits = $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults();
            $open_complaints = $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults();

            return $this->response->setJSON([
                'success' => true,
                'unread_notifications' => $unread_notifications,
                'pending_sellers' => $pending_sellers,
                'pending_deposits' => $pending_deposits,
                'open_complaints' => $open_complaints,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Admin::notificationsCount: Failed to fetch notification counts, error: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'error' => 'Gagal memuat jumlah notifikasi: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    public function sellers()
    {
        try {
            $sellers = $this->userModel
                ->select('users.*, COUNT(products.product_id) as product_count, AVG(products.sold_count) as avg_sales')
                ->where('role', 'penjual')
                ->join('products', 'products.seller_id = users.user_id', 'left')
                ->groupBy('users.user_id')
                ->findAll();

            $data = [
                'title' => 'Manajemen Penjual - DigiDaw Admin',
                'sellers' => $sellers
            ];

            return view('admin/sellers', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::sellers: Failed to load sellers data, error: ' . $e->getMessage());
            return redirect()->to('/admin/sellers')->with('error', 'Gagal memuat data penjual: ' . $e->getMessage());
        }
    }

    public function approveSeller($userId)
    {
        try {
            $user = $this->userModel->find($userId);
            if (!$user || $user['role'] !== 'penjual' || $user['is_enabled']) {
                return redirect()->to('/admin/sellers')->with('error', 'Penjual tidak valid atau sudah disetujui.');
            }

            $updateData = [
                'is_enabled' => 1,
                'verification_status' => 'verified',
                'approved_by' => session()->get('admin_id'),
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if ($this->userModel->update($userId, $updateData)) {
                $notificationData = [
                    'user_id' => $userId,
                    'admin_id' => session()->get('admin_id'),
                    'type' => 'verification',
                    'message' => 'Selamat! Akun penjual Anda telah disetujui dan diaktifkan.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->notificationModel->insert($notificationData);

                return redirect()->to('/admin/sellers')->with('success', 'Penjual berhasil disetujui dan diaktifkan.');
            }

            return redirect()->to('/admin/sellers')->with('error', 'Gagal menyetujui penjual.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::approveSeller: Failed to approve seller, userId: ' . $userId . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/sellers')->with('error', 'Gagal menyetujui penjual: ' . $e->getMessage());
        }
    }

    public function rejectSeller($userId)
    {
        try {
            $user = $this->userModel->find($userId);
            if (!$user || $user['role'] !== 'penjual' || $user['is_enabled']) {
                return redirect()->to('/admin/sellers')->with('error', 'Penjual tidak valid.');
            }

            $updateData = [
                'role' => 'pembeli',
                'is_enabled' => 1,
                'verification_status' => 'rejected',
                'verification_photo' => null,
                'approved_by' => null,
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if ($this->userModel->update($userId, $updateData)) {
                $notificationData = [
                    'user_id' => $userId,
                    'admin_id' => session()->get('admin_id'),
                    'type' => 'verification',
                    'message' => 'Maaf, permintaan menjadi penjual ditolak. Akun Anda telah diubah menjadi pembeli.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->notificationModel->insert($notificationData);

                return redirect()->to('/admin/sellers')->with('success', 'Permintaan penjual ditolak, akun diubah menjadi pembeli.');
            }

            return redirect()->to('/admin/sellers')->with('error', 'Gagal menolak permintaan penjual.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::rejectSeller: Failed to reject seller, userId: ' . $userId . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/sellers')->with('error', 'Gagal menolak permintaan penjual: ' . $e->getMessage());
        }
    }

    public function reports()
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $reports = $this->reportModel
                ->select('reports.*, users.username as seller_name')
                ->join('users', 'users.user_id = reports.generated_by', 'left')
                ->orderBy('reports.created_at', 'DESC')
                ->findAll();

            // Additional metrics for summary
            $report_count = $this->reportModel->countAllResults();
            $order_count = $this->orderModel->countAllResults();
            $total_revenue = $this->orderModel->where('status', 'completed')->selectSum('total_price')->get()->getRow()->total_price ?? 0;
            $pending_sellers = $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults();
            $pending_deposits = $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults();
            $open_complaints = $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults();
            $unread_notifications = $this->notificationModel
                ->groupStart()
                ->where('admin_id', $adminId)
                ->orWhere('admin_id IS NULL')
                ->groupEnd()
                ->where('is_read', 0)
                ->countAllResults();

            $data = [
                'title' => 'Manajemen Laporan - DigiDaw Admin',
                'reports' => $reports,
                'report_count' => $report_count,
                'order_count' => $order_count,
                'total_revenue' => $total_revenue,
                'pending_sellers' => $pending_sellers,
                'pending_deposits' => $pending_deposits,
                'open_complaints' => $open_complaints,
                'unread_notifications' => $unread_notifications,
            ];

            return view('admin/reports', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::reports: Failed to load reports, error: ' . $e->getMessage());
            $data = [
                'title' => 'Manajemen Laporan - DigiDaw Admin',
                'reports' => [],
                'report_count' => 0,
                'order_count' => 0,
                'total_revenue' => 0,
                'pending_sellers' => 0,
                'pending_deposits' => 0,
                'open_complaints' => 0,
                'unread_notifications' => 0,
                'error' => 'Gagal memuat laporan: ' . $e->getMessage()
            ];
            return view('admin/reports', $data);
        }
    }

    public function viewReport($report_id)
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $report = $this->reportModel
                ->select('reports.*, users.username as seller_name')
                ->join('users', 'users.user_id = reports.generated_by', 'left')
                ->find($report_id);

            if (!$report) {
                return redirect()->to('/admin/reports')->with('error', 'Laporan tidak ditemukan.');
            }

            $startDate = $report['start_date'];
            $endDate = $report['end_date'];
            $userId = $report['generated_by'];

            $orders = $this->orderModel
                ->select('orders.order_id, orders.total_price, orders.status, orders.created_at, users.username as buyer_name, orders.buyer_id')
                ->join('users', 'users.user_id = orders.buyer_id')
                ->where('orders.seller_id', (int)$userId)
                ->where('orders.status', 'completed')
                ->where('orders.created_at >=', $startDate)
                ->where('orders.created_at <=', $endDate . ' 23:59:59')
                ->orderBy('orders.created_at', 'DESC')
                ->findAll();

            foreach ($orders as &$r) {
                $r['items'] = $this->orderModel->getOrderDetails((int)$r['order_id']) ?: [];
            }

            $data = [
                'title' => 'Detail Laporan Penjualan - DigiDaw',
                'username' => $report['seller_name'],
                'reports' => $orders,
                'startDate' => $startDate,
                'endDate' => $endDate,
                'currentTime' => date('d M Y H:i'),
                'report_id' => $report_id,
                'unread_notifications' => $this->notificationModel
                    ->groupStart()
                    ->where('admin_id', $adminId)
                    ->orWhere('admin_id IS NULL')
                    ->groupEnd()
                    ->where('is_read', 0)
                    ->countAllResults(),
                'pending_sellers' => $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults(),
                'pending_deposits' => $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults(),
                'open_complaints' => $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults(),
            ];

            return view('admin/reports_print', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::viewReport: Failed to fetch report details, report_id: ' . $report_id . ', error: ' . $e->getMessage());
            $data = [
                'title' => 'Detail Laporan Penjualan - DigiDaw',
                'username' => 'Unknown',
                'reports' => [],
                'startDate' => date('Y-m-d'),
                'endDate' => date('Y-m-d'),
                'currentTime' => date('d M Y H:i'),
                'report_id' => $report_id,
                'unread_notifications' => 0,
                'pending_sellers' => 0,
                'pending_deposits' => 0,
                'open_complaints' => 0,
                'error' => 'Gagal memuat detail laporan: ' . $e->getMessage()
            ];
            return view('admin/reports_print', $data);
        }
    }

    public function approveReport($report_id)
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $report = $this->reportModel->find($report_id);
            if (!$report) {
                return redirect()->to('/admin/reports')->with('error', 'Laporan tidak ditemukan.');
            }

            // Since approved_by and status are not in the schema, we'll just send a notification
            $notificationData = [
                'user_id' => $report['generated_by'],
                'admin_id' => $adminId,
                'type' => 'report',
                'message' => 'Laporan Anda dengan ID #' . $report_id . ' telah disetujui.',
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->notificationModel->insert($notificationData);

            return redirect()->to('/admin/reports')->with('success', 'Laporan berhasil disetujui.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::approveReport: Failed to approve report, report_id: ' . $report_id . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/reports')->with('error', 'Gagal menyetujui laporan: ' . $e->getMessage());
        }
    }

    public function rejectReport($report_id)
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $report = $this->reportModel->find($report_id);
            if (!$report) {
                return redirect()->to('/admin/reports')->with('error', 'Laporan tidak ditemukan.');
            }

            // Since approved_by and status are not in the schema, we'll just send a notification
            $notificationData = [
                'user_id' => $report['generated_by'],
                'admin_id' => $adminId,
                'type' => 'report',
                'message' => 'Laporan Anda dengan ID #' . $report_id . ' telah ditolak.',
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->notificationModel->insert($notificationData);

            return redirect()->to('/admin/reports')->with('success', 'Laporan berhasil ditolak.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::rejectReport: Failed to reject report, report_id: ' . $report_id . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/reports')->with('error', 'Gagal menolak laporan: ' . $e->getMessage());
        }
    }

    public function orders()
    {
        try {
            $orders = $this->orderModel
                ->select('orders.*, u1.username as buyer_name, u2.username as seller_name, categories.name as category_name')
                ->join('users as u1', 'u1.user_id = orders.buyer_id', 'left')
                ->join('users as u2', 'u2.user_id = orders.seller_id', 'left')
                ->join('order_details', 'order_details.order_id = orders.order_id', 'left')
                ->join('products', 'products.product_id = order_details.product_id', 'left')
                ->join('categories', 'categories.category_id = products.category_id', 'left')
                ->groupBy('orders.order_id')
                ->orderBy('orders.created_at', 'DESC')
                ->findAll();

            $data = [
                'title' => 'Manajemen Pesanan - DigiDaw Admin',
                'orders' => $orders
            ];

            return view('admin/orders', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::orders: Failed to load orders, error: ' . $e->getMessage());
            return redirect()->to('/admin/orders')->with('error', 'Gagal memuat pesanan: ' . $e->getMessage());
        }
    }

    public function addPromo()
    {
        try {
            log_message('debug', 'Admin::addPromo: Received POST request: ' . json_encode($this->request->getPost()));
            if ($this->request->getMethod() === 'post') {
                $validationRules = [
                    'code' => 'required|min_length[3]|max_length[50]|is_unique[promos.code]',
                    'discount_value' => 'required|numeric|greater_than[0]|less_than_equal_to[100]',
                    'valid_until' => 'required|valid_date[Y-m-d]'
                ];

                if (!$this->validate($validationRules)) {
                    $errors = $this->validator->getErrors();
                    log_message('error', 'Admin::addPromo: Validation failed: ' . json_encode($errors));
                    return redirect()->to('/admin/promos')->with('error', $errors);
                }

                $data = [
                    'code' => $this->request->getPost('code'),
                    'discount_value' => (float)$this->request->getPost('discount_value'),
                    'valid_until' => $this->request->getPost('valid_until') . ' 23:59:59',
                    'status' => 'active',
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s'),
                ];

                if ($this->promoModel->insert($data)) {
                    log_message('info', 'Admin::addPromo: Promo added successfully: ' . $data['code']);
                    $notificationData = [
                        'admin_id' => null,
                        'type' => 'promo',
                        'message' => 'Promo baru telah ditambahkan: ' . $data['code'],
                        'created_at' => date('Y-m-d H:i:s'),
                    ];
                    $this->notificationModel->insert($notificationData);
                    return redirect()->to('/admin/promos')->with('success', 'Promo berhasil ditambahkan.');
                } else {
                    $errors = $this->promoModel->errors();
                    log_message('error', 'Admin::addPromo: Failed to insert promo: ' . json_encode($errors));
                    return redirect()->to('/admin/promos')->with('error', is_array($errors) ? implode(', ', $errors) : $errors);
                }
            }

            return redirect()->to('/admin/promos');
        } catch (\Exception $e) {
            log_message('error', 'Admin::addPromo: Exception: ' . $e->getMessage());
            return redirect()->to('/admin/promos')->with('error', 'Gagal menambahkan promo: ' . $e->getMessage());
        }
    }

    public function editPromo($promoId = null)
    {
        try {
            log_message('debug', 'Admin::editPromo: Received request with POST data: ' . json_encode($this->request->getPost()));
            if ($this->request->getMethod() === 'post') {
                $promoId = $this->request->getPost('promo_id');
                log_message('debug', 'Admin::editPromo: Processing promoId: ' . $promoId);

                // Verify promo exists
                $promo = $this->promoModel->find($promoId);
                if (!$promo) {
                    log_message('error', 'Admin::editPromo: Promo not found for promoId: ' . $promoId);
                    return redirect()->to('/admin/promos')->with('error', 'Promo tidak ditemukan.');
                }

                // Validation rules
                $validationRules = [
                    'promo_id' => 'required|is_natural_no_zero',
                    'code' => 'required|min_length[3]|max_length[50]|is_unique[promos.code,promo_id,' . $promoId . ']',
                    'discount_value' => 'required|numeric|greater_than[0]|less_than_equal_to[100]',
                    'valid_until' => 'required|valid_date[Y-m-d]'
                ];

                if (!$this->validate($validationRules)) {
                    $errors = $this->validator->getErrors();
                    log_message('error', 'Admin::editPromo: Validation failed for promoId ' . $promoId . ': ' . json_encode($errors));
                    return redirect()->to('/admin/promos')->with('error', $errors);
                }

                // Prepare data for update
                $data = [
                    'code' => $this->request->getPost('code'),
                    'discount_value' => (float)$this->request->getPost('discount_value'),
                    'valid_until' => $this->request->getPost('valid_until') . ' 23:59:59',
                    'updated_at' => date('Y-m-d H:i:s'),
                ];
                log_message('debug', 'Admin::editPromo: Update data: ' . json_encode($data));

                // Perform update
                $result = $this->promoModel->update($promoId, $data);
                if ($result && $this->promoModel->affectedRows() > 0) {
                    log_message('info', 'Admin::editPromo: Promo updated successfully: ' . $data['code']);
                    $notificationData = [
                        'admin_id' => null,
                        'type' => 'promo',
                        'message' => 'Promo telah diperbarui: ' . $data['code'],
                        'created_at' => date('Y-m-d H:i:s'),
                    ];
                    $this->notificationModel->insert($notificationData);
                    return redirect()->to('/admin/promos')->with('success', 'Promo berhasil diperbarui.');
                } else {
                    $errors = $this->promoModel->errors();
                    log_message('error', 'Admin::editPromo: Failed to update promoId ' . $promoId . ': ' . json_encode($errors ?: 'No rows affected'));
                    return redirect()->to('/admin/promos')->with('error', is_array($errors) ? implode(', ', $errors) : 'Gagal memperbarui promo: Tidak ada perubahan atau terjadi kesalahan.');
                }
            }

            return redirect()->to('/admin/promos');
        } catch (\Exception $e) {
            log_message('error', 'Admin::editPromo: Exception for promoId: ' . $promoId . ': ' . $e->getMessage());
            return redirect()->to('/admin/promos')->with('error', 'Gagal memperbarui promo: ' . $e->getMessage());
        }
    }

    public function deletePromo($promoId)
    {
        try {
            $promo = $this->promoModel->find($promoId);
            if (!$promo) {
                return redirect()->to('/admin/promos')->with('error', 'Promo tidak ditemukan.');
            }

            if ($this->promoModel->delete($promoId)) {
                // Notify all admins
                $notificationData = [
                    'admin_id' => null, // System notification for all admins
                    'type' => 'promo',
                    'message' => 'Promo telah dihapus: ' . $promo['code'],
                    'created_at' => date('Y-m-d H:i:s'),
                ];
                $this->notificationModel->insert($notificationData);
                return redirect()->to('/admin/promos')->with('success', 'Promo berhasil dihapus.');
            }

            return redirect()->to('/admin/promos')->with('error', 'Gagal menghapus promo.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::deletePromo: Failed to delete promo, promoId: ' . $promoId . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/promos')->with('error', 'Gagal menghapus promo: ' . $e->getMessage());
        }
    }

    public function promos()
    {
        try {
            $this->response->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
            $promos = $this->promoModel
                ->select('promos.*, COUNT(promo_usages.promo_usage_id) as usage_count')
                ->join('promo_usages', 'promo_usages.promo_id = promos.promo_id', 'left')
                ->groupBy('promos.promo_id')
                ->orderBy('promos.created_at', 'DESC')
                ->findAll();

            $data = [
                'title' => 'Manajemen Promo - DigiDaw Admin',
                'promos' => $promos,
                'unread_notifications' => $this->notificationModel
                    ->groupStart()
                    ->where('admin_id', session()->get('admin_id'))
                    ->orWhere('admin_id IS NULL')
                    ->groupEnd()
                    ->where('is_read', 0)
                    ->countAllResults(),
                'pending_sellers' => $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults(),
                'pending_deposits' => $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults(),
                'open_complaints' => $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults(),
            ];

            return view('admin/promos', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::promos: Failed to load promos, error: ' . $e->getMessage());
            return redirect()->to('/admin/promos')->with('error', 'Gagal memuat promo: ' . $e->getMessage());
        }
    }

    public function users()
    {
        try {
            $users = $this->userModel
                ->select('users.*, COUNT(orders.order_id) as total_orders, SUM(orders.total_price) as total_spent')
                ->join('orders', 'orders.buyer_id = users.user_id', 'left')
                ->where('orders.status', 'completed')
                ->groupBy('users.user_id')
                ->orderBy('users.created_at', 'DESC')
                ->findAll();

            $data = [
                'title' => 'Manajemen Pengguna - DigiDaw Admin',
                'users' => $users
            ];

            return view('admin/users', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::users: Failed to load users, error: ' . $e->getMessage());
            return redirect()->to('/admin/users')->with('error', 'Gagal memuat pengguna: ' . $e->getMessage());
        }
    }

    public function complaints()
    {
        try {
            $complaints = $this->complaintModel
                ->select('complaints.*, users.username as user_name, orders.order_id, orders.total_price, products.name as product_name')
                ->join('users', 'users.user_id = complaints.user_id', 'left')
                ->join('orders', 'orders.order_id = complaints.order_id', 'left')
                ->join('order_details', 'order_details.order_id = orders.order_id', 'left')
                ->join('products', 'products.product_id = order_details.product_id', 'left')
                ->groupBy('complaints.complaint_id')
                ->orderBy('complaints.created_at', 'DESC')
                ->findAll();

            $data = [
                'title' => 'Manajemen Keluhan - DigiDaw Admin',
                'complaints' => $complaints
            ];

            return view('admin/complaints', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::complaints: Failed to load complaints, error: ' . $e->getMessage());
            return redirect()->to('/admin/complaints')->with('error', 'Gagal memuat keluhan: ' . $e->getMessage());
        }
    }

    public function products()
    {
        try {
            $products = $this->productModel
                ->select('products.*, categories.name as category_name, users.username as seller_name')
                ->join('categories', 'categories.category_id = products.category_id', 'left')
                ->join('users', 'users.user_id = products.seller_id', 'left')
                ->findAll();

            log_message('debug', 'Admin::products: Retrieved ' . count($products) . ' products');

            $data = [
                'title' => 'Manajemen Produk - DigiDaw Admin',
                'products' => $products,
                'unread_notifications' => $this->notificationModel->where('is_read', 0)->where('admin_id', session()->get('admin_id'))->countAllResults(),
                'pending_sellers' => $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults(),
                'pending_deposits' => $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults(),
                'open_complaints' => $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults(),
                'error' => null
            ];

            return view('admin/products', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::products: Failed to load products, error: ' . $e->getMessage());
            $data = [
                'title' => 'Manajemen Produk - DigiDaw Admin',
                'products' => [],
                'unread_notifications' => 0,
                'pending_sellers' => 0,
                'pending_deposits' => 0,
                'open_complaints' => 0,
                'error' => 'Gagal memuat produk: ' . $e->getMessage()
            ];
            return view('admin/products', $data);
        }
    }

    public function deleteProduct($productId = null)
    {
        try {
            $product = $this->productModel->find($productId);
            if (!$product) {
                return redirect()->to('/admin/products')->with('error', 'Produk tidak ditemukan.');
            }

            if ($this->productModel->delete($productId)) {
                $notificationData = [
                    'user_id' => $product['seller_id'],
                    'admin_id' => session()->get('admin_id'),
                    'type' => 'product',
                    'message' => 'Produk "' . $product['name'] . '" telah dihapus oleh admin.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->notificationModel->insert($notificationData);

                return redirect()->to('/admin/products')->with('success', 'Produk berhasil dihapus.');
            }

            return redirect()->to('/admin/products')->with('error', 'Gagal menghapus produk.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::deleteProduct: Failed to delete product, productId: ' . $productId . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/products')->with('error', 'Gagal menghapus produk: ' . $e->getMessage());
        }
    }

    public function wallets()
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $wallets = $this->walletModel
                ->select('wallets.*, users.username as user_name')
                ->join('users', 'users.user_id = wallets.user_id', 'left')
                ->orderBy('wallets.created_at', 'DESC')
                ->findAll();

            $data = [
                'title' => 'Manajemen Dompet - DigiDaw Admin',
                'wallets' => $wallets,
                'unread_notifications' => $this->notificationModel
                    ->groupStart()
                    ->where('admin_id', $adminId)
                    ->orWhere('admin_id IS NULL')
                    ->groupEnd()
                    ->where('is_read', 0)
                    ->countAllResults(),
                'pending_sellers' => $this->userModel->where('role', 'penjual')->where('is_enabled', 0)->countAllResults(),
                'pending_deposits' => $this->walletModel->where('type', 'deposit')->where('status', 'pending')->countAllResults(),
                'open_complaints' => $this->complaintModel->whereIn('status', ['open', 'in_progress'])->countAllResults(),
            ];

            return view('admin/wallets', $data);
        } catch (\Exception $e) {
            log_message('error', 'Admin::wallets: Failed to load wallets, error: ' . $e->getMessage());
            $data = [
                'title' => 'Manajemen Dompet - DigiDaw Admin',
                'wallets' => [],
                'unread_notifications' => 0,
                'pending_sellers' => 0,
                'pending_deposits' => 0,
                'open_complaints' => 0,
                'error' => 'Gagal memuat transaksi dompet: ' . $e->getMessage()
            ];
            return view('admin/wallets', $data);
        }
    }

    public function approveWallet($wallet_id)
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $wallet = $this->walletModel->find($wallet_id);
            if (!$wallet) {
                return redirect()->to('/admin/wallets')->with('error', 'Transaksi dompet tidak ditemukan.');
            }

            // Update wallet status to 'completed'
            $updateData = [
                'status' => 'completed',
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if ($this->walletModel->update($wallet_id, $updateData)) {
                // Update user's balance
                $this->userModel->where('user_id', $wallet['user_id'])
                    ->set('balance', 'balance + ' . $wallet['amount'], false)
                    ->update();

                // Send notification to user
                $notificationData = [
                    'user_id' => $wallet['user_id'],
                    'admin_id' => $adminId,
                    'type' => 'wallet',
                    'message' => 'Transaksi dompet Anda (ID #' . $wallet_id . ') telah disetujui. Saldo sebesar Rp ' . number_format($wallet['amount'], 0, ',', '.') . ' telah ditambahkan.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->notificationModel->insert($notificationData);

                return redirect()->to('/admin/wallets')->with('success', 'Transaksi dompet berhasil disetujui.');
            }

            return redirect()->to('/admin/wallets')->with('error', 'Gagal menyetujui transaksi dompet.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::approveWallet: Failed to approve wallet, wallet_id: ' . $wallet_id . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/wallets')->with('error', 'Gagal menyetujui transaksi dompet: ' . $e->getMessage());
        }
    }

    public function rejectWallet($wallet_id)
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $wallet = $this->walletModel->find($wallet_id);
            if (!$wallet) {
                return redirect()->to('/admin/wallets')->with('error', 'Transaksi dompet tidak ditemukan.');
            }

            // Update wallet status to 'rejected'
            $updateData = [
                'status' => 'rejected',
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if ($this->walletModel->update($wallet_id, $updateData)) {
                // Send notification to user
                $notificationData = [
                    'user_id' => $wallet['user_id'],
                    'admin_id' => $adminId,
                    'type' => 'wallet',
                    'message' => 'Transaksi dompet Anda (ID #' . $wallet_id . ') telah ditolak.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->notificationModel->insert($notificationData);

                return redirect()->to('/admin/wallets')->with('success', 'Transaksi dompet berhasil ditolak.');
            }

            return redirect()->to('/admin/wallets')->with('error', 'Gagal menolak transaksi dompet.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::rejectWallet: Failed to reject wallet, wallet_id: ' . $wallet_id . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/wallets')->with('error', 'Gagal menolak transaksi dompet: ' . $e->getMessage());
        }
    }

    public function delete($userId)
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $user = $this->userModel->find($userId);
            if (!$user) {
                return redirect()->to('/admin/users')->with('error', 'Pengguna tidak ditemukan.');
            }

            // Delete the user
            if ($this->userModel->delete($userId)) {
                // Send notification to the user (if needed)
                $notificationData = [
                    'user_id' => $userId,
                    'admin_id' => $adminId,
                    'type' => 'account',
                    'message' => 'Akun Anda telah dihapus oleh admin.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->notificationModel->insert($notificationData);

                return redirect()->to('/admin/users')->with('success', 'Pengguna berhasil dihapus.');
            }

            return redirect()->to('/admin/users')->with('error', 'Gagal menghapus pengguna.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::delete: Failed to delete user, userId: ' . $userId . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/users')->with('error', 'Gagal menghapus pengguna: ' . $e->getMessage());
        }
    }

    public function toggle($userId)
    {
        try {
            $adminId = session()->get('admin_id');
            if (!$adminId) {
                return redirect()->to('/admin/login')->with('error', 'Silakan login terlebih dahulu.');
            }

            $user = $this->userModel->find($userId);
            if (!$user) {
                return redirect()->to('/admin/users')->with('error', 'Pengguna tidak ditemukan.');
            }

            // Toggle the is_enabled status
            $newStatus = $user['is_enabled'] ? 0 : 1;
            $updateData = [
                'is_enabled' => $newStatus,
                'updated_at' => date('Y-m-d H:i:s')
            ];

            if ($this->userModel->update($userId, $updateData)) {
                // Send notification to the user
                $notificationData = [
                    'user_id' => $userId,
                    'admin_id' => $adminId,
                    'type' => 'account',
                    'message' => 'Akun Anda telah ' . ($newStatus ? 'diaktifkan' : 'dinonaktifkan') . ' oleh admin.',
                    'created_at' => date('Y-m-d H:i:s')
                ];
                $this->notificationModel->insert($notificationData);

                return redirect()->to('/admin/users')->with('success', 'Status pengguna berhasil diubah.');
            }

            return redirect()->to('/admin/users')->with('error', 'Gagal mengubah status pengguna.');
        } catch (\Exception $e) {
            log_message('error', 'Admin::toggle: Failed to toggle user status, userId: ' . $userId . ', error: ' . $e->getMessage());
            return redirect()->to('/admin/users')->with('error', 'Gagal mengubah status pengguna: ' . $e->getMessage());
        }
    }

    public function analytics()
    {
        try {
            $analytics = [
                'revenue_trend' => $this->getRevenueTrend(),
                'user_acquisition' => $this->getUserAcquisition(),
                'product_performance' => $this->getProductPerformance(),
                'seller_performance' => $this->getSellerPerformance(),
                'category_insights' => $this->getCategoryInsights(),
            ];

            return $this->response->setJSON([
                'success' => true,
                'data' => $analytics,
                'timestamp' => date('Y-m-d H:i:s')
            ]);
        } catch (\Exception $e) {
            log_message('error', 'Admin::analytics: Failed to load analytics, error: ' . $e->getMessage());
            return $this->response->setJSON([
                'success' => false,
                'error' => 'Gagal memuat analitik: ' . $e->getMessage()
            ])->setStatusCode(500);
        }
    }

    private function getRevenueTrend()
    {
        return $this->orderModel
            ->select('DATE(created_at) as date, SUM(total_price) as revenue, COUNT(*) as orders')
            ->where('status', 'completed')
            ->where('created_at >=', date('Y-m-d', strtotime('-30 days')))
            ->groupBy('DATE(created_at)')
            ->orderBy('date')
            ->findAll();
    }

    private function getUserAcquisition()
    {
        return $this->userModel
            ->select('DATE(created_at) as date, COUNT(*) as new_users, role')
            ->where('created_at >=', date('Y-m-d', strtotime('-30 days')))
            ->groupBy('DATE(created_at), role')
            ->orderBy('date')
            ->findAll();
    }

    private function getProductPerformance()
    {
        return $this->productModel
            ->select('products.name, products.sold_count, products.view_count, categories.name as category')
            ->join('categories', 'categories.category_id = products.category_id')
            ->orderBy('products.sold_count', 'DESC')
            ->limit(10)
            ->findAll();
    }

    private function getSellerPerformance()
    {
        return $this->userModel
            ->select('users.username, COUNT(orders.order_id) as total_sales, SUM(orders.total_price) as total_revenue, AVG(orders.total_price) as avg_order_value')
            ->join('orders', 'orders.seller_id = users.user_id')
            ->where('users.role', 'penjual')
            ->where('orders.status', 'completed')
            ->groupBy('users.user_id')
            ->orderBy('total_revenue', 'DESC')
            ->limit(10)
            ->findAll();
    }

    private function getCategoryInsights()
    {
        return $this->categoryModel
            ->select('categories.name, COUNT(products.product_id) as product_count, SUM(products.sold_count) as total_sold, AVG(products.price) as avg_price')
            ->join('products', 'products.category_id = categories.category_id')
            ->groupBy('categories.category_id')
            ->orderBy('total_sold', 'DESC')
            ->findAll();
    }
}
