<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->checkRememberMe();
    }

    public function login()
    {
        $data = [
            'title' => 'Login - DigiDaw',
            'redirect' => $this->request->getGet('redirect')
        ];
        return view('auth/login', $data);
    }

    public function doLogin()
    {
        $validation = \Config\Services::validation();

        $rules = [
            'username' => 'required',
            'password' => 'required|min_length[6]'
        ];

        if (!$this->validate($rules)) {
            log_message('error', 'Validation failed: ' . json_encode($validation->getErrors()));
            return redirect()->back()->withInput()->with('error', implode(', ', $validation->getErrors()));
        }

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $rememberMe = $this->request->getPost('remember_me') === 'on';

        try {
            $user = $this->userModel->where('username', $username)->first();
            if (!$user) {
                log_message('error', 'User not found: ' . $username);
                return redirect()->back()->withInput()->with('error', 'Username tidak ditemukan.');
            }

            if (!password_verify($password, $user['password_hash'])) {
                log_message('error', 'Password verification failed for: ' . $username);
                return redirect()->back()->withInput()->with('error', 'Password salah.');
            }

            // Clear old cart
            $cartModel = new \App\Models\CartModel();
            $cartModel->where('user_id', $user['user_id'])->delete();
            log_message('debug', 'Cleared cart for user_id: ' . $user['user_id']);

            // Set session
            $sessionData = [
                'logged_in' => true,
                'user_id' => $user['user_id'],
                'username' => $user['username'],
                'email' => $user['email'],
                'role' => $user['role'],
                'is_enabled' => $user['is_enabled']
            ];
            session()->set($sessionData);
            log_message('debug', 'Session set: ' . json_encode(session()->get()));

            // Set remember me
            if ($rememberMe) {
                $token = bin2hex(random_bytes(32));
                $this->userModel->update($user['user_id'], [
                    'remember_token' => $token,
                    'remember_token_expiry' => date('Y-m-d H:i:s', strtotime('+30 days'))
                ]);
                setcookie('remember_me', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
                log_message('debug', 'Remember me token set for user_id: ' . $user['user_id']);
            }

            session()->setFlashdata('success', 'Login berhasil!');
            $redirect = $this->request->getPost('redirect') ?: ($user['role'] === 'penjual' ? '/seller/dashboard' : '/');
            return redirect()->to($redirect)->withCookies()->with('refresh', true);
        } catch (\Exception $e) {
            log_message('error', 'Login error: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'Terjadi kesalahan. Silakan coba lagi.');
        }
    }

    public function logout()
    {
        $userId = session()->get('user_id') ?? 0;
        $cartModel = new \App\Models\CartModel();
        $cartModel->where('user_id', $userId)->delete();
        log_message('debug', 'Cleared cart on logout for user_id: ' . $userId);

        if (isset($_COOKIE['remember_me'])) {
            $user = $this->userModel->where('remember_token', $_COOKIE['remember_me'])->first();
            if ($user) {
                $this->userModel->update($user['user_id'], [
                    'remember_token' => null,
                    'remember_token_expiry' => null
                ]);
            }
            setcookie('remember_me', '', time() - 3600, '/', '', true, true);
        }

        session()->destroy();
        log_message('debug', 'Session destroyed');
        return redirect()->to('/')->with('success', 'Logout berhasil!');
    }

    public function register()
    {
        $data = [
            'title' => 'Register - DigiDaw'
        ];
        return view('auth/register', $data);
    }

    public function doRegister()
    {
        $validation = \Config\Services::validation();

        $rules = [
            'username' => 'required|min_length[3]|max_length[50]|is_unique[users.username]',
            'email' => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]',
            'confirm_password' => 'required|matches[password]',
            'role' => 'required|in_list[pembeli,penjual]'
        ];

        if (!$validation->withRequest($this->request)->setRules($rules)->run()) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $data = [
            'username' => $this->request->getPost('username'),
            'email' => $this->request->getPost('email'),
            'password_hash' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role' => $this->request->getPost('role'),
            'is_enabled' => $this->request->getPost('role') === 'pembeli' ? 1 : 0,
            'created_at' => date('Y-m-d H:i:s')
        ];

        try {
            if ($this->userModel->insert($data)) {
                $message = $data['role'] === 'pembeli' ? 'Registrasi berhasil! Silakan login.' : 'Registrasi penjual berhasil! Silakan verifikasi akun Anda.';
                return redirect()->to('/auth/login')->with('success', $message);
            }
            throw new \Exception('Registration failed');
        } catch (\Exception $e) {
            log_message('error', 'Registration error: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'Terjadi kesalahan saat mendaftar.');
        }
    }

    public function checkRememberMe()
    {
        if (session()->get('logged_in')) {
            return;
        }

        $currentUri = service('uri')->getPath();
        if (in_array($currentUri, ['auth/login', 'auth/register'])) {
            return;
        }

        if (isset($_COOKIE['remember_me'])) {
            $token = $_COOKIE['remember_me'];
            $user = $this->userModel->where('remember_token', $token)
                ->where('remember_token_expiry >', date('Y-m-d H:i:s'))
                ->first();

            if ($user) {
                session()->set([
                    'logged_in' => true,
                    'user_id' => $user['user_id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'role' => $user['role'],
                    'is_enabled' => $user['is_enabled']
                ]);
                setcookie('remember_me', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
                log_message('debug', 'Remember me restored for user_id: ' . $user['user_id']);
            } else {
                setcookie('remember_me', '', time() - 3600, '/', '', true, true);
                log_message('debug', 'Invalid remember me token');
            }
        }
    }

    public function checkSession()
    {
        return $this->response->setJSON([
            'logged_in' => session()->get('logged_in') ?? false,
            'role' => session()->get('role') ?? null
        ]);
    }
}
