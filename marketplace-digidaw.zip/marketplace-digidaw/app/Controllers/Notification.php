<?php

namespace App\Controllers;

use App\Models\NotificationModel;

class Notification extends BaseController
{
    protected $notificationModel;

    public function __construct()
    {
        helper(['form', 'url']);
        $this->notificationModel = new NotificationModel();
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        $notifications = $this->notificationModel
            ->where('user_id', $userId)
            ->orderBy('created_at', 'DESC')
            ->findAll();

        // Tandai semua notifikasi sebagai dibaca
        $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->set(['is_read' => 1])->update();

        $data = [
            'title' => 'Notifikasi - DigiAw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'notifications' => $notifications,
            'stats' => [
                'notification_count' => 0, // Set ke 0 karena semua udah dibaca
            ],
        ];

        return view('notifications/index', $data);
    }
}
