<?php

namespace App\Controllers;

use App\Models\OrderModel;
use App\Models\UserModel;
use App\Models\NotificationModel;
use App\Models\CartModel;
use App\Models\TransactionModel;
use App\Models\ProductModel;

class Order extends BaseController
{
    protected $orderModel;
    protected $userModel;
    protected $notificationModel;
    protected $cartModel;
    protected $transactionModel;
    protected $productModel;

    public function __construct()
    {
        helper(['form', 'url']);
        $this->orderModel = new OrderModel();
        $this->userModel = new UserModel();
        $this->notificationModel = new NotificationModel();
        $this->cartModel = new CartModel();
        $this->transactionModel = new TransactionModel();
        $this->productModel = new ProductModel();
    }

    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'index: User ID not found in session.');
            return redirect()->to('/auth/login')->with('error', 'Sesi tidak valid.');
        }

        $user = $this->userModel->asArray()->select('user_id, username, email')->find($userId);
        if (!$user) {
            log_message('error', 'index: User not found for user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Pengguna tidak ditemukan.');
        }

        $orders = $this->orderModel
            ->select('
                orders.order_id,
                orders.total_price,
                orders.status,
                orders.payment_method,
                orders.created_at,
                order_details.product_id,
                products.name as product_name,
                buyers.username as buyer_name,
                sellers.username as seller_name
            ')
            ->join('order_details', 'orders.order_id = order_details.order_id')
            ->join('products', 'order_details.product_id = products.product_id')
            ->join('users buyers', 'orders.buyer_id = buyers.user_id')
            ->join('users sellers', 'products.seller_id = sellers.user_id')
            ->where('orders.buyer_id', $userId)
            ->orderBy('orders.created_at', 'DESC')
            ->findAll();

        foreach ($orders as &$order) {
            $order['items'] = $this->orderModel->getOrderDetails((int)$order['order_id']) ?: [];
        }

        $cartItems = $this->cartModel->where('user_id', $userId)->findAll();

        $data = [
            'title' => 'Pesanan Saya - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'user' => $user,
            'orders' => $orders,
            'stats' => [
                'total_orders' => count($orders),
                'pending_orders' => $this->orderModel->where('buyer_id', $userId)->where('status', 'pending')->countAllResults(),
                'completed_orders' => $this->orderModel->where('buyer_id', $userId)->where('status', 'completed')->countAllResults(),
                'cancelled_orders' => $this->orderModel->where('buyer_id', $userId)->where('status', 'cancelled')->countAllResults(),
                'notification_count' => $this->notificationModel->where('user_id', $userId)->where('is_read', 0)->countAllResults(),
                'cart_count' => count($cartItems),
            ],
        ];

        return view('orders/index', $data);
    }

    public function sellerIndex($filter = 'all')
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'sellerIndex: User ID not found in session.');
            return redirect()->to('/auth/login')->with('error', 'Sesi tidak valid.');
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            log_message('error', 'sellerIndex: Invalid user or not a seller, user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Akun tidak valid atau bukan penjual.');
        }

        $isVerified = $user['verification_status'] === 'verified';
        session()->set([
            'is_enabled' => $isVerified,
            'verification_status' => $user['verification_status'] ?? 'non_verified'
        ]);

        if (!$isVerified) {
            return redirect()->to('/seller/verify')->with('error', 'Akun Anda belum diverifikasi.');
        }

        $orderQuery = $this->orderModel
            ->select('orders.order_id, orders.total_price, orders.status, orders.created_at, users.username as buyer_name, orders.buyer_id')
            ->join('users', 'users.user_id = orders.buyer_id')
            ->where('orders.seller_id', (int)$userId);

        // Filter berdasarkan status
        if ($filter !== 'all') {
            if (in_array($filter, ['pending', 'paid', 'delivered', 'completed', 'cancelled'])) {
                $orderQuery->where('orders.status', $filter);
            } else {
                $filter = 'all'; // Kembali ke 'all' jika filter tidak valid
            }
        }

        $perPage = 10;
        $orders = $orderQuery->orderBy('orders.created_at', 'DESC')->paginate($perPage);
        $pager = $this->orderModel->pager;

        foreach ($orders as &$order) {
            $order['items'] = $this->orderModel->getOrderDetails((int)$order['order_id']) ?: [];
        }

        $newOrders = $this->orderModel->where(['seller_id' => (int)$userId, 'status' => 'pending'])->countAllResults();

        $data = [
            'title' => 'Pesanan - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => esc(session()->get('username')),
            'role' => session()->get('role'),
            'isEnabled' => $isVerified,
            'verificationStatus' => $user['verification_status'] ?? 'non_verified',
            'needsVerification' => !$isVerified,
            'filter' => esc($filter),
            'orders' => $orders,
            'newOrders' => $newOrders,
            'pager' => $pager
        ];

        return view('seller/orders', $data);
    }

    public function sellerDetail($orderId)
    {
        log_message('debug', 'sellerDetail: Attempting to load order_id: ' . $orderId . ', user_id: ' . session()->get('user_id'));

        // Periksa login
        if (!session()->get('logged_in')) {
            log_message('error', 'sellerDetail: User not logged in.');
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        if (!$userId) {
            log_message('error', 'sellerDetail: User ID not found in session.');
            return redirect()->to('/auth/login')->with('error', 'Sesi tidak valid.');
        }

        // Periksa user
        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            log_message('error', 'sellerDetail: Invalid user or not a seller, user_id: ' . $userId);
            return redirect()->to('/auth/login')->with('error', 'Akun tidak valid atau bukan penjual.');
        }

        // Pastikan sudah terverifikasi
        if ($user['verification_status'] !== 'verified') {
            log_message('error', 'sellerDetail: User not verified, user_id: ' . $userId . ', verification_status: ' . ($user['verification_status'] ?? 'none'));
            return redirect()->to('/seller/verify')->with('error', 'Akun Anda belum diverifikasi.');
        }

        // Ambil data pesanan
        $order = $this->orderModel
            ->select('orders.order_id, orders.total_price, orders.status, orders.payment_method, orders.created_at, users.username as buyer_name, orders.buyer_id')
            ->join('users', 'users.user_id = orders.buyer_id')
            ->where('orders.order_id', (int)$orderId)
            ->where('orders.seller_id', (int)$userId)
            ->first();

        if (!$order) {
            log_message('error', 'sellerDetail: Order not found for order_id: ' . $orderId . ', user_id: ' . $userId);
            return redirect()->to('/seller/orders')->with('error', 'Pesanan tidak ditemukan: Order ID ' . $orderId);
        }

        // Ambil detail pesanan
        $order['items'] = $this->orderModel->getOrderDetails((int)$orderId) ?: [];
        $newOrders = $this->orderModel->where(['seller_id' => (int)$userId, 'status' => 'pending'])->countAllResults();

        $data = [
            'title' => 'Detail Pesanan - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => esc(session()->get('username')),
            'role' => session()->get('role'),
            'isEnabled' => true,
            'verificationStatus' => $user['verification_status'],
            'needsVerification' => false,
            'order' => $order,
            'newOrders' => $newOrders
        ];

        log_message('debug', 'sellerDetail: Data prepared for order_id: ' . $orderId . ', user_id: ' . $userId);
        try {
            return view('seller/order_detail', $data);
        } catch (\Exception $e) {
            log_message('error', 'sellerDetail: Failed to load view for order_id: ' . $orderId . ', user_id: ' . $userId . ', error: ' . $e->getMessage());
            return redirect()->to('/seller/orders')->with('error', 'Gagal memuat halaman detail: ' . $e->getMessage());
        }
    }

    public function updateStatus($orderId)
    {
        log_message('debug', 'updateStatus: Attempting to update order_id: ' . $orderId . ', user_id: ' . session()->get('user_id'));

        if (!session()->get('logged_in')) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Silakan login terlebih dahulu.']);
        }

        $userId = session()->get('user_id');
        if (!$userId) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Sesi tidak valid.']);
        }

        $user = $this->userModel->find((int)$userId);
        if (!$user || $user['role'] !== 'penjual') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Akun tidak valid atau bukan penjual.']);
        }

        if ($user['verification_status'] !== 'verified') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Akun Anda belum diverifikasi.']);
        }

        $data = $this->request->getJSON(true);
        $newStatus = $data['status'] ?? null;

        if (!in_array($newStatus, ['paid', 'delivered', 'completed', 'cancelled'])) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Status tidak valid.']);
        }

        $order = $this->orderModel
            ->where('order_id', (int)$orderId)
            ->where('seller_id', (int)$userId)
            ->first();

        if (!$order) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Pesanan tidak ditemukan.']);
        }

        $allowedTransitions = [
            'pending' => ['paid', 'cancelled'],
            'paid' => ['delivered'],
            'delivered' => ['completed'],
        ];

        if (!in_array($newStatus, $allowedTransitions[$order['status']] ?? [])) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Transisi status tidak diizinkan.']);
        }

        $this->orderModel->update((int)$orderId, ['status' => $newStatus]);

        log_message('info', 'updateStatus: Successfully updated order_id: ' . $orderId . ' to status: ' . $newStatus);
        return $this->response->setJSON(['status' => 'success', 'message' => 'Status pesanan berhasil diperbarui.']);
    }

    public function paymentConfirmation($orderId)
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session()->get('user_id');
        $order = $this->orderModel
            ->select('orders.order_id, orders.total_price, orders.status, orders.payment_method, orders.created_at, order_details.product_id, products.name as product_name, users.username as seller_name')
            ->join('order_details', 'orders.order_id = order_details.order_id')
            ->join('products', 'order_details.product_id = products.product_id')
            ->join('users', 'products.seller_id = users.user_id')
            ->where('orders.order_id', (int)$orderId)
            ->where('orders.buyer_id', (int)$userId)
            ->first();

        if (!$order || $order['status'] !== 'pending') {
            return redirect()->to('/orders')->with('error', 'Pesanan tidak valid atau sudah diproses.');
        }

        $order['items'] = $this->orderModel->getOrderDetails((int)$orderId) ?: [];
        $user = $this->userModel->select('user_id, username, email, balance')->find((int)$userId);
        $cartItems = $this->cartModel->where('user_id', (int)$userId)->findAll();

        $data = [
            'title' => 'Konfirmasi Pembayaran - DigiDaw',
            'isLoggedIn' => session()->get('logged_in'),
            'username' => session()->get('username'),
            'role' => session()->get('role'),
            'order' => $order,
            'user' => $user,
            'stats' => [
                'notification_count' => $this->notificationModel->where('user_id', (int)$userId)->where('is_read', 0)->countAllResults(),
                'cart_count' => count($cartItems),
            ],
        ];

        return view('orders/payment_confirmation', $data);
    }

    public function pay($orderId)
    {
        if (!session()->get('logged_in')) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Silakan login terlebih dahulu.', 'csrf_token' => csrf_hash()]);
        }

        $userId = session()->get('user_id');
        $order = $this->orderModel->where('order_id', (int)$orderId)->where('buyer_id', (int)$userId)->first();

        if (!$order || $order['status'] !== 'pending') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Pesanan tidak valid atau sudah diproses.', 'csrf_token' => csrf_hash()]);
        }

        $user = $this->userModel->find((int)$userId);
        if ($user['balance'] < $order['total_price']) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Saldo tidak cukup untuk melakukan pembayaran.', 'csrf_token' => csrf_hash()]);
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $this->userModel->update((int)$userId, ['balance' => $user['balance'] - $order['total_price']]);
            $this->orderModel->update((int)$orderId, ['status' => 'completed', 'payment_method' => 'balance', 'updated_at' => date('Y-m-d H:i:s')]);

            $this->transactionModel->insert([
                'user_id' => (int)$userId,
                'order_id' => (int)$orderId,
                'amount' => $order['total_price'],
                'type' => 'payment',
                'status' => 'completed',
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $this->notificationModel->insert([
                'user_id' => (int)$userId,
                'message' => 'Pembayaran untuk pesanan #' . $orderId . ' berhasil.',
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $orderDetails = $this->orderModel
                ->select('products.seller_id')
                ->join('order_details', 'orders.order_id = order_details.order_id')
                ->join('products', 'order_details.product_id = products.product_id')
                ->where('orders.order_id', (int)$orderId)
                ->first();
            $this->notificationModel->insert([
                'user_id' => $orderDetails['seller_id'],
                'message' => 'Pesanan #' . $orderId . ' telah dibayar oleh pembeli.',
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $db->transComplete();

            if ($db->transStatus() === false) {
                throw new \Exception('Gagal memproses pembayaran.');
            }

            return $this->response->setJSON(['status' => 'success', 'message' => 'Pembayaran berhasil.', 'csrf_token' => csrf_hash()]);
        } catch (\Exception $e) {
            $db->transRollback();
            log_message('error', 'pay: Error processing payment for order_id: ' . $orderId . ' - ' . $e->getMessage());
            return $this->response->setJSON(['status' => 'error', 'message' => 'Terjadi kesalahan saat memproses pembayaran.', 'csrf_token' => csrf_hash()]);
        }
    }

    public function cancel($orderId)
    {
        if (!session()->get('logged_in')) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Silakan login terlebih dahulu.', 'csrf_token' => csrf_hash()]);
        }

        $userId = session()->get('user_id');
        $order = $this->orderModel->where('order_id', (int)$orderId)->where('buyer_id', (int)$userId)->first();

        if (!$order || $order['status'] !== 'pending') {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Pesanan tidak valid atau sudah diproses.', 'csrf_token' => csrf_hash()]);
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $this->orderModel->update((int)$orderId, ['status' => 'cancelled', 'updated_at' => date('Y-m-d H:i:s')]);

            $orderDetails = $this->orderModel
                ->select('order_details.product_id, order_details.quantity')
                ->join('order_details', 'orders.order_id = order_details.order_id')
                ->where('orders.order_id', (int)$orderId)
                ->findAll();

            foreach ($orderDetails as $detail) {
                $product = $this->productModel->find((int)$detail['product_id']);
                $this->productModel->update((int)$detail['product_id'], ['stock' => $product['stock'] + $detail['quantity']]);
            }

            $this->notificationModel->insert([
                'user_id' => (int)$userId,
                'message' => 'Pesanan #' . $orderId . ' telah dibatalkan.',
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $seller = $this->orderModel
                ->select('products.seller_id')
                ->join('order_details', 'orders.order_id = order_details.order_id')
                ->join('products', 'order_details.product_id = products.product_id')
                ->where('orders.order_id', (int)$orderId)
                ->first();
            $this->notificationModel->insert([
                'user_id' => $seller['seller_id'],
                'message' => 'Pesanan #' . $orderId . ' telah dibatalkan oleh pembeli.',
                'is_read' => 0,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            $db->transComplete();

            if ($db->transStatus() === false) {
                throw new \Exception('Gagal membatalkan pesanan.');
            }

            return $this->response->setJSON(['status' => 'success', 'message' => 'Pesanan berhasil dibatalkan.', 'csrf_token' => csrf_hash()]);
        } catch (\Exception $e) {
            $db->transRollback();
            log_message('error', 'cancel: Error cancelling order_id: ' . $orderId . ' - ' . $e->getMessage());
            return $this->response->setJSON(['status' => 'error', 'message' => 'Terjadi kesalahan saat membatalkan pesanan.', 'csrf_token' => csrf_hash()]);
        }
    }
}
