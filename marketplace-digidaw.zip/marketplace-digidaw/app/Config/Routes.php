<?php

namespace Config;

use CodeIgniter\Router\RouteCollection;

$routes = Services::routes();

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

$routes->get('/', 'Home::index');

// User Authentication Routes
$routes->group('auth', function ($routes) {
    $routes->get('login', 'Auth::login');
    $routes->post('doLogin', 'Auth::doLogin');
    $routes->get('register', 'Auth::register');
    $routes->post('doRegister', 'Auth::doRegister');
    $routes->get('logout', 'Auth::logout');
});

$routes->group('admin', function ($routes) {
    $routes->get('login', 'AdminAuth::login');
    $routes->post('doLogin', 'AdminAuth::doLogin');
    $routes->get('register', 'AdminAuth::register');
    $routes->post('doRegister', 'AdminAuth::doRegister');
    $routes->get('logout', 'AdminAuth::logout');
});

$routes->group('admin', ['filter' => 'adminAuth'], function ($routes) {
    $routes->get('dashboard', 'Admin::dashboard');
    $routes->get('sellers', 'Admin::sellers');
    $routes->get('approve_seller/(:num)', 'Admin::approveSeller/$1');
    $routes->get('reject_seller/(:num)', 'Admin::rejectSeller/$1');
    $routes->get('reports', 'Admin::reports');
    $routes->get('reports/view/(:num)', 'Admin::viewReport/$1');
    $routes->get('reports/approve/(:num)', 'Admin::approveReport/$1');
    $routes->get('reports/reject/(:num)', 'Admin::rejectReport/$1');
    $routes->get('orders', 'Admin::orders');
    $routes->get('promos', 'Admin::promos');
    $routes->get('users', 'Admin::users');
    $routes->get('users/delete/(:num)', 'Admin::delete/$1'); // Added
    $routes->get('users/toggle/(:num)', 'Admin::toggle/$1'); // Added
    $routes->get('complaints', 'Admin::complaints');
    $routes->get('notifications', 'Admin::notifications');
    $routes->get('wallets', 'Admin::wallets');
    $routes->get('wallets/approve/(:num)', 'Admin::approveWallet/$1');
    $routes->get('wallets/reject/(:num)', 'Admin::rejectWallet/$1');
    $routes->get('products', 'Admin::products');
    $routes->get('products/delete/(:num)', 'Admin::deleteProduct/$1');
    $routes->get('notifications/count', 'Admin::notificationsCount');
    $routes->get('notifications/recent', 'Admin::recentNotifications');
    $routes->get('uploads/seller_photos/(:any)', 'Admin8411::serveVerificationPhoto/$1');
    $routes->get('seller_photos/(:any)', 'Admin::serveVerificationPhoto/$1');
    $routes->post('promos/add',  'Admin::addPromo');
    $routes->post('promos/edit', 'Admin::editPromo');
});

// Cart Routes
$routes->group('cart', function ($routes) {
    $routes->get('/', 'Cart::index');
    $routes->post('add', 'Cart::add');
    $routes->get('get', 'Cart::get');
    $routes->post('updateQuantity', 'Cart::updateQuantity');
    $routes->get('checkout', 'Cart::checkout');
    $routes->post('complete', 'Cart::complete');
    $routes->post('remove', 'Cart::remove');
    $routes->post('clearCart', 'Cart::clearCart');
});

$routes->get('product/(:num)', 'Product::detail/$1');

// Authenticated User Routes
$routes->group('', ['filter' => 'auth'], function ($routes) {
    $routes->get('dashboard', 'Dashboard::index');
    $routes->get('orders', 'Order::index');
    $routes->get('orders/payment/(:num)', 'Order::paymentConfirmation/$1');
    $routes->post('orders/pay/(:num)', 'Order::pay/$1');
    $routes->post('orders/cancel/(:num)', 'Order::cancel/$1');
    $routes->get('cart', 'Cart::index');
    $routes->get('wishlist', 'Wishlist::index');
    $routes->get('notifications', 'Notification::index');
    $routes->get('referral', 'Referral::index');
    $routes->post('referral/copyCode', 'Referral::copyCode');
    $routes->get('profile/edit', 'Profile::edit');
    $routes->post('profile/update', 'Profile::update');
    $routes->get('transactions', 'Transaction::index');
    $routes->get('promos', 'Promo::index');
    $routes->get('dashboard/deposit', 'Payment::deposit');
    $routes->post('deposit/submit', 'Payment::submitDeposit');
});

// Seller Routes
$routes->group('seller', ['filter' => 'auth'], function ($routes) {
    $routes->get('dashboard', 'Seller::dashboard');
    $routes->post('doVerify', 'Seller::doVerify');
    $routes->get('verify', 'Seller::verify');
    $routes->get('tambahproduk', 'Product::create');
    $routes->get('products', 'Seller::products');
    $routes->get('products/(:segment)', 'Seller::products/$1');
    $routes->get('products/add', 'Product::create');
    $routes->post('products/store', 'Product::store');
    $routes->get('products/view/(:num)', 'Product::detail/$1');
    $routes->get('products/edit/(:num)', 'Product::edit/$1');
    $routes->post('products/update/(:num)', 'Product::update/$1');
    $routes->post('products/delete/(:num)', 'Product::delete/$1');
    $routes->get('orders', 'Order::sellerIndex');
    $routes->get('orders/(:segment)', 'Order::sellerIndex/$1');
    $routes->get('orders/(:num)', 'Order::sellerDetail/$1');
    $routes->post('orders/updateStatus/(:num)', 'Order::updateStatus/$1');
    $routes->get('reports', 'Report::index');
    $routes->get('reports/data', 'Report::getData');
    $routes->get('reports/export', 'Report::export');
    $routes->get('profile', 'Profile::edit');
});
