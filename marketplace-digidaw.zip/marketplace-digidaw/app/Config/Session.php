<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Session\Handlers\FileHandler;

class Session extends BaseConfig
{
    public string $driver = FileHandler::class;
    public string $cookieName = 'ci_session';
    public int $expiration = 7200;
    public string $savePath = WRITEPATH . 'session';
    public bool $matchIP = false;
    public int $timeToUpdate = 300;
    public bool $regenerateDestroy = false;
    public ?string $DBGroup = null;
    public int $lockRetryInterval = 100_000;
    public int $lockMaxRetries = 300;

    public function __construct()
    {
        parent::__construct();

        log_message('debug', 'Session Config - driver: ' . $this->driver . ', savePath: ' . $this->savePath);

        if (!is_dir($this->savePath)) {
            if (!mkdir($this->savePath, 0755, true)) {
                log_message('error', 'Failed to create session directory at: ' . $this->savePath);
                throw new \RuntimeException('Failed to create session directory at: ' . $this->savePath);
            }
            log_message('debug', 'Session directory created at: ' . $this->savePath);
        }

        if (!is_writable($this->savePath)) {
            if (!chmod($this->savePath, 0755)) {
                log_message('error', 'Session directory not writable: ' . $this->savePath);
                throw new \RuntimeException('Session directory not writable: ' . $this->savePath);
            }
            log_message('debug', 'Session directory permissions updated to writable at: ' . $this->savePath);
        }

        ini_set('session.cookie_samesite', 'Lax');
    }
}
