<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class SellerAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $loggedIn = session()->get('logged_in');
        $userId = session()->get('user_id');
        $role = session()->get('role');

        if (!$loggedIn || !$userId) {
            log_message('debug', 'SellerAuthFilter: User not logged in, redirecting to login');
            return redirect()->to('/auth/login')->with('error', 'Silakan login untuk melanjutkan.');
        }

        if ($role !== 'penjual') {
            log_message('debug', 'SellerAuthFilter: Access denied for user_id: ' . $userId);
            return redirect()->to('/')->with('error', 'Akses ditolak. Hanya penjual yang bisa mengakses.');
        }

        log_message('debug', 'SellerAuthFilter: Access granted for user_id: ' . $userId);
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No action after request
    }
}
