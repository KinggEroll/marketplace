<?php
namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AdminAuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        log_message('debug', 'AdminAuthFilter: Checking session for URI: ' . $request->getUri()->getPath());
        if (!session()->get('admin_logged_in') || !session()->get('admin_id')) {
            log_message('debug', 'AdminAuthFilter: No valid admin session, redirecting to /admin/login');
            return redirect()->to('/admin/login')->with('error', 'Please login as admin.');
        }
        log_message('debug', 'AdminAuthFilter: Admin authenticated, proceeding to ' . $request->getUri()->getPath());
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do nothing
    }
}