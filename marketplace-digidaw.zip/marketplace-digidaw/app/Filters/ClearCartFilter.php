<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\CartModel;

class ClearCartFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Periksa apakah sesi masih aktif
        if (!session()->get('logged_in')) {
            $userId = session()->get('user_id') ?? 0;
            if ($userId) {
                // Jika user_id masih ada tetapi logged_in false, hapus keranjang
                $cartModel = new CartModel();
                $cartModel->where('user_id', $userId)->delete();
                // Hapus user_id dari sesi agar tidak digunakan lagi
                session()->remove('user_id');
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak perlu tindakan setelah request
    }
}