<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Controllers\Auth; // Import Auth controller

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Instantiate Auth controller to use checkRememberMe
        $auth = new Auth();
        $auth->checkRememberMe();

        $loggedIn = session()->get('logged_in');
        $userId = session()->get('user_id');

        if (!$loggedIn || !$userId) {
            log_message('debug', 'AuthFilter: User not logged in, redirecting to login');
            return redirect()->to('/auth/login')->with('error', 'Silakan login untuk melanjutkan.');
        }

        log_message('debug', 'AuthFilter: User is logged in, user_id: ' . $userId);
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // No action after request
    }
}
