<?php
namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddPhoneNumberAndGameIdToCarts extends Migration
{
    public function up()
    {
        $this->forge->addColumn('carts', [
            'phone_number' => [
                'type' => 'VARCHAR',
                'constraint' => '20',
                'null' => true,
            ],
            'game_id' => [
                'type' => 'VARCHAR',
                'constraint' => '50',
                'null' => true,
            ],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('carts', 'phone_number');
        $this->forge->dropColumn('carts', 'game_id');
    }
}