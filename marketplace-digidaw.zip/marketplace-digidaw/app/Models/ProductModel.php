<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table = 'products';
    protected $primaryKey = 'product_id';
    protected $allowedFields = [
        'seller_id',
        'category_id',
        'name',
        'price',
        'stock',
        'description',
        'image_url',
        'status',
        'view_count',
        'sold_count'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    public function getActiveProducts()
    {
        $products = $this->where('status', 'active')->findAll();
        if (empty($products)) {
            log_message('warning', 'Tidak ada produk dengan status "active" di tabel products.');
        }
        return $products;
    }

    public function getProductAnalytics($sellerId)
    {
        return $this->select('name, view_count, sold_count')
            ->where('seller_id', $sellerId)
            ->where('status', 'active')
            ->findAll();
    }

    public function getProductsBySeller($sellerId)
    {
        return $this->where('seller_id', $sellerId)
            ->findAll();
    }
}
