<?php

namespace App\Models;

use CodeIgniter\Model;

class OrderModel extends Model
{
    protected $table = 'orders';
    protected $primaryKey = 'order_id';
    protected $allowedFields = ['buyer_id', 'seller_id', 'promo_id', 'total_price', 'status', 'payment_method', 'payment_status', 'created_at'];

    public function getOrderDetails($orderId)
    {
        return $this->select('orders.order_id, orders.buyer_id, orders.seller_id, orders.total_price, orders.status, orders.created_at, order_details.product_id, order_details.quantity, order_details.price, products.name as product_name, users.username as seller_name')
            ->join('order_details', 'orders.order_id = order_details.order_id', 'left')
            ->join('products', 'order_details.product_id = products.product_id', 'left')
            ->join('users', 'products.seller_id = users.user_id', 'left')
            ->where('orders.order_id', $orderId)
            ->findAll();
    }
}
