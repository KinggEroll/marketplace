<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table = 'payment_proofs';
    protected $primaryKey = 'payment_proof_id';
    protected $allowedFields = ['order_id', 'proof_url', 'status', 'verified_by', 'verified_at', 'notes', 'updated_at'];
    protected $useTimestamps = true;
    protected $createdField = 'submitted_at';
    protected $updatedField = 'updated_at';
    protected $returnType = 'array';

    public function approveDeposit($proofId, $adminId)
    {
        $db = \Config\Database::connect();
        $db->transStart();

        $request = $this->find($proofId);
        if (!$request || $request['status'] !== 'pending') {
            throw new \Exception('Permintaan deposit tidak valid atau sudah diproses');
        }

        $notes = json_decode($request['notes'], true);
        $userId = $notes['user_id'] ?? null;
        $amount = $notes['amount'] ?? 0;

        if (!$userId) {
            throw new \Exception('Data pengguna tidak ditemukan di notes');
        }

        // Tidak perlu update balance di sini, trigger akan menanganinya
        $this->update($proofId, [
            'status' => 'verified',
            'verified_by' => $adminId,
            'verified_at' => date('Y-m-d H:i:s'),
            'notes' => json_encode(array_merge($notes, ['approved_at' => date('Y-m-d H:i:s')])),
        ]);

        $db->transComplete();
        if ($db->transStatus() === false) {
            throw new \Exception('Transaksi gagal');
        }

        return true;
    }

    public function rejectDeposit($proofId, $adminId)
    {
        $db = \Config\Database::connect();
        $db->transStart();

        $request = $this->find($proofId);
        if (!$request || $request['status'] !== 'pending') {
            throw new \Exception('Permintaan deposit tidak valid atau sudah diproses');
        }

        $this->update($proofId, [
            'status' => 'rejected',
            'verified_by' => $adminId,
            'verified_at' => date('Y-m-d H:i:s'),
            'notes' => json_encode(array_merge(json_decode($request['notes'], true), ['rejected_at' => date('Y-m-d H:i:s')])),
        ]);

        $db->transComplete();
        if ($db->transStatus() === false) {
            throw new \Exception('Transaksi gagal');
        }

        return true;
    }
}