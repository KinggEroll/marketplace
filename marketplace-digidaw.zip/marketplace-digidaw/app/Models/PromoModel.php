<?php
namespace App\Models;

use CodeIgniter\Model;

class PromoModel extends Model
{
    protected $table = 'promos';
    protected $primaryKey = 'promo_id';
    protected $allowedFields = [
        'code', 'description', 'discount_type', 'discount_value',
        'min_purchase', 'max_discount', 'category_id', 'valid_from',
        'valid_until', 'status'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at'; // Tambahkan ini
}