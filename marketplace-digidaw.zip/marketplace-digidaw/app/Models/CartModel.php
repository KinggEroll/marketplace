<?php

namespace App\Models;

use CodeIgniter\Model;

class CartModel extends Model
{
    protected $table = 'carts';
    protected $primaryKey = 'cart_id';
    protected $allowedFields = ['user_id', 'product_id', 'quantity'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getCart($userId)
    {
        return $this->select('carts.*, products.name, products.price, products.stock')
            ->join('products', 'products.product_id = carts.product_id', 'left')
            ->where('carts.user_id', $userId)
            ->findAll();
    }
}
