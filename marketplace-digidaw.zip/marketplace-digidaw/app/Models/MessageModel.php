<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\Database\Exceptions\DatabaseException;

/**
 * Model untuk tabel messages.
 * @package App\Models
 */
class MessageModel extends Model
{
    protected $table = 'messages';
    protected $primaryKey = 'message_id';
    protected $allowedFields = ['order_id', 'sender_id', 'receiver_id', 'message', 'is_read', 'created_at', 'last_message_at'];
    protected $useTimestamps = false;

    /**
     * Mendapatkan daftar percakapan untuk pengguna.
     * @param int $userId
     * @return array
     */
    public function getConversations($userId)
    {
        $userId = (int)$userId;
        $userRole = session()->get('role') ?? 'pembeli';

        try {
            $builder = $this->db->table($this->table);
            $selectFields = '
            messages.order_id,
            orders.order_id,
            COALESCE(products.name, "Produk Tidak Ditemukan") AS product_name,
            COALESCE(products.image_url, "/assets/images/default-product.jpg") AS image_url,
            %s AS user_name,
            %s AS user_id,
            MAX(messages.created_at) AS last_message_time,
            COALESCE(messages.message, "") AS last_message,
            SUM(CASE WHEN messages.is_read = 0 AND messages.receiver_id = ? THEN 1 ELSE 0 END) AS unread_count
        ';

            $builder->select(sprintf(
                $selectFields,
                $userRole === 'pembeli' ? 'COALESCE(seller.username, "Penjual Tidak Ditemukan")' : 'COALESCE(buyer.username, "Pembeli Tidak Ditemukan")',
                $userRole === 'pembeli' ? 'seller.user_id' : 'buyer.user_id'
            ));
            $builder->join('orders', 'messages.order_id = orders.order_id', 'left')
                ->join('order_details', 'orders.order_id = order_details.order_id', 'left')
                ->join('products', 'order_details.product_id = products.product_id', 'left');

            if ($userRole === 'pembeli') {
                $builder->join('users AS seller', 'products.seller_id = seller.user_id', 'left')
                    ->where('orders.buyer_id', $userId);
            } else {
                $builder->join('users AS buyer', 'orders.buyer_id = buyer.user_id', 'left')
                    ->where('products.seller_id', $userId);
            }

            $builder->where('messages.receiver_id', $userId, false);
            $builder->groupBy('messages.order_id')
                ->orderBy('last_message_time', 'DESC');

            $conversations = $builder->get()->getResultArray();

            foreach ($conversations as &$conv) {
                $conv['last_message'] = esc($conv['last_message'] ?? '');
                $conv['product_name'] = esc($conv['product_name'] ?? '');
                $conv['user_name'] = esc($conv['user_name'] ?? '');
                $conv['image_url'] = esc($conv['image_url'] ?? '');
                $conv['user_id'] = (int)($conv['user_id'] ?? 0);
                $conv['unread_count'] = (int)($conv['unread_count'] ?? 0);
            }

            return $conversations;
        } catch (DatabaseException $e) {
            log_message('error', "MessageModel/getConversations: Database error, user_id: $userId, error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Mendapatkan pesan berdasarkan order_id dan user_id.
     * @param int $orderId
     * @param int $userId
     * @return array
     */
    public function getMessagesByOrder($orderId, $userId)
    {
        $orderId = (int)$orderId;
        $userId = (int)$userId;

        try {
            return $this->select('message_id, order_id, sender_id, receiver_id, message, is_read, created_at')
                ->where('order_id', $orderId)
                ->groupStart()
                ->where('sender_id', $userId)
                ->orWhere('receiver_id', $userId)
                ->groupEnd()
                ->orderBy('created_at', 'ASC')
                ->findAll();
        } catch (DatabaseException $e) {
            log_message('error', "MessageModel/getMessagesByOrder: Database error, user_id: $userId, order_id: $orderId, error: " . $e->getMessage());
            return [];
        }
    }
}
