<?php

namespace App\Models;

use CodeIgniter\Model;

class ReviewModel extends Model
{
    protected $table = 'reviews';
    protected $primaryKey = 'review_id';
    protected $allowedFields = [
        'order_id',
        'product_id',
        'rating',
        'comment'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';

    public function getRecentReviews($limit = 6)
    {
        return $this->select('reviews.*, products.name as product_name, users.username as buyer_name')
            ->join('orders', 'orders.order_id = reviews.order_id')
            ->join('products', 'products.product_id = reviews.product_id')
            ->join('users', 'users.user_id = orders.buyer_id')
            ->orderBy('reviews.created_at', 'DESC')
            ->limit($limit)
            ->findAll();
    }

    public function getProductReviews($productId)
    {
        return $this->select('reviews.*, users.username as buyer_name')
            ->join('orders', 'orders.order_id = reviews.order_id')
            ->join('users', 'users.user_id = orders.buyer_id')
            ->where('reviews.product_id', $productId)
            ->orderBy('reviews.created_at', 'DESC')
            ->findAll();
    }

    public function getAverageRating($productId)
    {
        $result = $this->selectAvg('rating')
            ->where('product_id', $productId)
            ->first();

        return round($result['rating'] ?? 0, 1);
    }
}
