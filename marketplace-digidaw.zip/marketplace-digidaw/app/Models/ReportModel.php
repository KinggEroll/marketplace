<?php

namespace App\Models;

use CodeIgniter\Model;

class ReportModel extends Model
{
    protected $table = 'reports';
    protected $primaryKey = 'report_id';
    protected $allowedFields = ['report_type', 'generated_by', 'start_date', 'end_date', 'data', 'created_at'];
    protected $useTimestamps = false;
    protected $dateFormat = 'datetime';
    protected $returnType = 'array';

    protected $validationRules = [
        'report_type' => 'required|in_list[sales_export,other]',
        'generated_by' => 'required|integer|is_valid_user', // Custom rule
        'start_date' => 'required|valid_date',
        'end_date' => 'required|valid_date',
        'data' => 'permit_empty|string',
        'created_at' => 'required|valid_date'
    ];

    protected $validationMessages = [
        'report_type' => [
            'required' => 'Tipe laporan wajib diisi.',
            'in_list' => 'Tipe laporan tidak valid.'
        ],
        'generated_by' => [
            'required' => 'ID pengguna wajib diisi.',
            'integer' => 'ID pengguna harus berupa angka.',
            'is_valid_user' => 'ID pengguna tidak valid.'
        ],
        'start_date' => [
            'required' => 'Tanggal mulai wajib diisi.',
            'valid_date' => 'Format tanggal mulai tidak valid.'
        ],
        'end_date' => [
            'required' => 'Tanggal akhir wajib diisi.',
            'valid_date' => 'Format tanggal akhir tidak valid.'
        ],
        'created_at' => [
            'required' => 'Tanggal pembuatan wajib diisi.',
            'valid_date' => 'Format tanggal pembuatan tidak valid.'
        ]
    ];

    // Custom validation method for is_valid_user
    public function validate_is_valid_user($value)
    {
        $userModel = new \App\Models\UserModel();
        return $userModel->find((int)$value) !== null;
    }

    protected function beforeInsert(array $data)
    {
        if (!isset($data['data']['created_at'])) {
            $data['data']['created_at'] = date('Y-m-d H:i:s');
        }
        return $data;
    }
}