<?php
namespace App\Models;

use CodeIgniter\Model;

class ReferralModel extends Model
{
    protected $table = 'referrals';
    protected $primaryKey = 'referral_id';
    protected $allowedFields = ['referrer_user_id', 'referred_user_id', 'referral_code', 'created_at'];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $dateFormat = 'datetime';

    public function generateReferralCode($userId)
    {
        $existing = $this->where('referrer_user_id', $userId)->first();
        if ($existing && !empty($existing['referral_code'])) {
            return $existing['referral_code'];
        }

        $code = strtoupper(substr(md5($userId . time()), 0, 8));
        $data = [
            'referrer_user_id' => $userId,
            'referral_code' => $code,
            'created_at' => date('Y-m-d H:i:s'),
        ];
        $this->insert($data);
        return $code;
    }
}