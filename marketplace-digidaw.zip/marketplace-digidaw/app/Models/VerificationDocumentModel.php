<?php

namespace App\Models;

use CodeIgniter\Model;

class VerificationDocumentModel extends Model
{
    protected $table = 'verification_documents';
    protected $primaryKey = 'verification_id';
    protected $allowedFields = ['user_id', 'document_type', 'document_url', 'status', 'submitted_at', 'reviewed_by', 'reviewed_at', 'notes'];
    protected $useTimestamps = true;
    protected $createdField = 'submitted_at';
    protected $dateFormat = 'datetime';
}