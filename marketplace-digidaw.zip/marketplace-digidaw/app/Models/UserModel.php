<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $allowedFields = [
        'username',
        'email',
        'password_hash',
        'role',
        'status',
        'verification_status',
        'balance',
        'phone',
        'address',
        'referral_code',
        'referred_by',
        'seller_rating',
        'created_at',
        'updated_at',
        'remember_token',
        'remember_token_expiry',
        'profile_picture',
        'verification_photo', // Tambah ini
        'is_enabled'         // Tambah ini
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $dateFormat = 'datetime';

    // Validasi
    protected $validationRules = [
        'email' => 'required|valid_email|is_unique[users.email]',
        'username' => 'required|is_unique[users.username]',
        'password_hash' => 'required'
    ];

    protected $validationMessages = [
        'email' => [
            'is_unique' => 'Email sudah terdaftar. Gunakan email lain.'
        ],
        'username' => [
            'is_unique' => 'Username sudah terdaftar. Gunakan username lain.'
        ]
    ];

    // Metode untuk mengambil pengguna berdasarkan email
    public function getUserByEmail($email)
    {
        return $this->select('user_id, username, email, password_hash, remember_token, remember_token_expiry')
            ->where('email', $email)
            ->first();
    }
    public function getActiveUsersCount()
    {
        return $this->where('status', 'active')
            ->where('is_enabled', 1)
            ->countAllResults();
    }

    public function getVerifiedSellersCount()
    {
        return $this->where('role', 'penjual')
            ->where('verification_status', 'verified')
            ->where('status', 'active')
            ->countAllResults();
    }

    public function getTopSellers($limit = 5)
    {
        return $this->select('users.*, COUNT(products.product_id) as total_products, AVG(products.sold_count) as avg_sales')
            ->join('products', 'products.seller_id = users.user_id', 'left')
            ->where('users.role', 'penjual')
            ->where('users.verification_status', 'verified')
            ->where('users.status', 'active')
            ->groupBy('users.user_id')
            ->orderBy('users.seller_rating', 'DESC')
            ->orderBy('avg_sales', 'DESC')
            ->limit($limit)
            ->findAll();
    }

    public function getSellerWithProducts($sellerId)
    {
        return $this->select('users.*, COUNT(products.product_id) as total_products, SUM(products.sold_count) as total_sales')
            ->join('products', 'products.seller_id = users.user_id', 'left')
            ->where('users.user_id', $sellerId)
            ->groupBy('users.user_id')
            ->first();
    }
}
