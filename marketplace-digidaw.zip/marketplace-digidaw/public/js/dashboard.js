document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('categoryChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: ['Top-Up', 'Item In-Game', 'Gift Card', 'Voucher Game', 'Others'],
            datasets: [{
                data: [5, 3, 2, 4, 5], // Dummy data, replace with actual data
                backgroundColor: ['#ff6384', '#36a2eb', '#ffce56', '#4bc0c0', '#9966ff']
            }]
        },
        options: {
            responsive: true
        }
    });
});